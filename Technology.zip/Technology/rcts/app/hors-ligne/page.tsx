import type { Metadata } from "next";
import { WifiOff } from "lucide-react";
import { ReloadButton } from "@/components/pwa/reload-button";

export const metadata: Metadata = { title: "Hors ligne" };

export default function OfflinePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-sidebar p-6 text-center text-white">
      <div className="flex size-16 items-center justify-center rounded-2xl bg-accent text-accent-foreground"><WifiOff className="size-8" aria-hidden /></div>
      <h1 className="text-2xl font-black">Pas de connexion</h1>
      <p className="max-w-sm text-sm text-blue-100">
        R.CTS a besoin d&apos;Internet pour afficher des chiffres exacts (caisse, stock, finances). Vérifiez votre connexion puis réessayez.
      </p>
      <ReloadButton />
    </main>
  );
}
