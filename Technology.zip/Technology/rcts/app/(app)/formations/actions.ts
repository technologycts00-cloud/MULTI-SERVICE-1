"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { trainingSchema } from "@/lib/validations/training";

const idSchema = z.uuid();
// La Direction (ADMIN) et le secrétariat gèrent le catalogue des formations.
const WRITERS = ["ADMIN", "SECRETAIRE"] as const;

function refresh(id?: string) {
  revalidatePath("/formations");
  if (id) revalidatePath(`/formations/${id}`);
  revalidatePath("/inscriptions/nouvelle");
}

/** Création (id = null) ou modification d'une formation. Validation refaite côté serveur. */
export async function saveTraining(id: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;

  const parsed = trainingSchema.safeParse(raw);
  if (!parsed.success) {
    return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(parsed.error) };
  }
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Formation introuvable." };

  const { supabase } = auth;
  const v = parsed.data;

  if (id === null) {
    const { data, error } = await supabase.from("trainings").insert(v).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    refresh(data.id);
    return { ok: true, id: data.id };
  }

  // La capacité et le formateur sont aussi contrôlés par des triggers en base.
  const { data, error } = await supabase.from("trainings").update(v).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Formation introuvable ou accès refusé." };
  refresh(id);
  return { ok: true, id };
}

/** Archivage (jamais de suppression) : la base refuse s'il reste des inscriptions actives. */
export async function archiveTraining(id: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Formation introuvable." };

  const { error } = await auth.supabase.from("trainings").update({ is_archived: true }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

export async function restoreTraining(id: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Formation introuvable." };

  const { error } = await auth.supabase.from("trainings").update({ is_archived: false }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

