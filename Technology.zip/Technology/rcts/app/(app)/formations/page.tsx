import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { TrainingsTable } from "@/components/formations/trainings-table";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { TRAINING_STATUS, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { listTrainings } from "@/services/trainings";

export const metadata: Metadata = { title: "Formations" };
export const dynamic = "force-dynamic";

export default async function FormationsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("formations");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const rawStatus = firstParam(sp.status);
  const status = rawStatus && rawStatus in TRAINING_STATUS ? rawStatus : undefined;
  const canWrite = profile.role === "ADMIN" || profile.role === "SECRETAIRE";
  const archived = canWrite && firstParam(sp.archives) === "1";
  const page = parsePage(firstParam(sp.page));

  const { rows, total } = await listTrainings(await createClient(), { q, status, archived, page });
  if (rows.length === 0 && page > 1) redirect("/formations");

  return (
    <div className="space-y-5">
      <PageHeader
        title={archived ? "Formations archivées" : "Formations"}
        description={`${total} formation${total > 1 ? "s" : ""}${profile.role === "FORMATEUR" ? " qui vous sont confiées" : ""}`}
        actions={canWrite && <Button asChild><Link href="/formations/nouvelle"><Plus aria-hidden /> Nouvelle formation</Link></Button>}
      />
      <ListFilters
        basePath="/formations"
        q={q}
        placeholder="Nom de la formation"
        selects={[{ name: "status", label: "Statut", value: status, options: options(TRAINING_STATUS), allLabel: "Tous les statuts" }]}
        archivedToggle={canWrite ? { checked: archived, label: "Voir les archivées" } : undefined}
      />
      <TrainingsTable rows={rows} showFinance={canWrite} />
      <Pagination page={page} total={total} basePath="/formations" params={{ q, status, archives: archived ? "1" : undefined }} />
    </div>
  );
}
