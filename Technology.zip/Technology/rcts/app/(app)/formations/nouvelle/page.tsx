import type { Metadata } from "next";
import { TrainingForm } from "@/components/formations/training-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { listTrainers } from "@/services/trainings";
import { saveTraining } from "../actions";

export const metadata: Metadata = { title: "Nouvelle formation" };
export const dynamic = "force-dynamic";

export default async function NewTrainingPage() {
  await requireRole("ADMIN", "SECRETAIRE");
  const trainers = await listTrainers(await createClient());

  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouvelle formation" back={{ href: "/formations", label: "Retour aux formations" }} />
      <TrainingForm
        trainingId={null}
        save={saveTraining}
        trainers={trainers.map((t) => ({ id: t.id, label: `${t.full_name ?? "Sans nom"} (${t.role === "ADMIN" ? "Direction" : "Formateur"})` }))}
        defaults={{
          name: "",
          description: "",
          duration_value: "",
          duration_unit: "MOIS",
          price: "",
          registration_fee: "0",
          max_students: "",
          start_date: "",
          end_date: "",
          schedule: "",
          trainer_id: "",
          status: "PLANIFIEE",
        }}
      />
    </div>
  );
}

