import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Archive, ArchiveRestore, Pencil, UserPlus } from "lucide-react";
import { z } from "zod";
import { TrainingDetailView } from "@/components/formations/training-detail";
import { ActionButton } from "@/components/shared/action-button";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getTrainingDetail } from "@/services/trainings";
import { archiveTraining, restoreTraining } from "../actions";

export const metadata: Metadata = { title: "Formation" };
export const dynamic = "force-dynamic";

export default async function TrainingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();

  const profile = await requireModule("formations");
  const canWrite = profile.role === "ADMIN" || profile.role === "SECRETAIRE";
  const detail = await getTrainingDetail(await createClient(), id);
  if (!detail) notFound();
  const { training } = detail;

  const open = !training.is_archived && (training.status === "PLANIFIEE" || training.status === "EN_COURS");

  return (
    <div className="space-y-5">
      <PageHeader title="Formation" back={{ href: "/formations", label: "Retour aux formations" }} />
      <TrainingDetailView
        detail={detail}
        showFinance={canWrite}
        canWrite={canWrite}
        actions={
          canWrite && (
            <>
              {open && (
                <Button asChild>
                  <Link href={`/inscriptions/nouvelle?training=${id}`}>
                    <UserPlus aria-hidden /> Inscrire un élève
                  </Link>
                </Button>
              )}
              <Button asChild variant="outline">
                <Link href={`/formations/${id}/modifier`}>
                  <Pencil aria-hidden /> Modifier
                </Link>
              </Button>
              {training.is_archived ? (
                <ActionButton action={restoreTraining.bind(null, id)} size="default">
                  <ArchiveRestore aria-hidden /> Restaurer
                </ActionButton>
              ) : (
                <ActionButton
                  action={archiveTraining.bind(null, id)}
                  size="default"
                  confirm={{
                    title: "Archiver cette formation ?",
                    description:
                      "Elle n'apparaîtra plus dans la liste principale ni dans les nouvelles inscriptions. L'historique des inscriptions est conservé.",
                    confirmLabel: "Archiver",
                  }}
                >
                  <Archive aria-hidden /> Archiver
                </ActionButton>
              )}
            </>
          )
        }
      />
    </div>
  );
}

