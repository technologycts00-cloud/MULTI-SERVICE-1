import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { TrainingForm } from "@/components/formations/training-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getTrainingDetail, listTrainers } from "@/services/trainings";
import { saveTraining } from "../../actions";

export const metadata: Metadata = { title: "Modifier la formation" };
export const dynamic = "force-dynamic";

export default async function EditTrainingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN", "SECRETAIRE");
  const supabase = await createClient();
  const [detail, trainers] = await Promise.all([getTrainingDetail(supabase, id), listTrainers(supabase)]);
  if (!detail) notFound();
  const t = detail.training;

  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier la formation" back={{ href: `/formations/${id}`, label: "Retour à la formation" }} />
      <TrainingForm
        trainingId={id}
        save={saveTraining}
        trainers={trainers.map((x) => ({ id: x.id, label: `${x.full_name ?? "Sans nom"} (${x.role === "ADMIN" ? "Direction" : "Formateur"})` }))}
        defaults={{
          name: t.name,
          description: t.description ?? "",
          duration_value: String(t.duration_value),
          duration_unit: t.duration_unit as "HEURES",
          price: String(t.price),
          registration_fee: String(t.registration_fee),
          max_students: t.max_students === null ? "" : String(t.max_students),
          start_date: t.start_date ?? "",
          end_date: t.end_date ?? "",
          schedule: t.schedule ?? "",
          trainer_id: t.trainer_id ?? "",
          status: t.status,
        }}
      />
    </div>
  );
}
