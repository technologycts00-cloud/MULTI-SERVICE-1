import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { Empty } from "@/components/shared/empty";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { SERVICE_ORDER_STATUS, formatDate, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listOrders } from "@/services/parties";

export const metadata: Metadata = { title: "Commandes de service" };
export const dynamic = "force-dynamic";

export default async function OrdersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("services");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const status = firstParam(sp.status) && firstParam(sp.status)! in SERVICE_ORDER_STATUS ? firstParam(sp.status) : undefined;
  const unpaid = firstParam(sp.unpaid) === "1";
  const page = parsePage(firstParam(sp.page));
  const { rows, total } = await listOrders(await createClient(), { q, status, unpaid, page });
  if (rows.length === 0 && page > 1) redirect("/services/commandes");

  return (
    <div className="space-y-5">
      <PageHeader
        title="Commandes de service"
        description={`${total} commande${total > 1 ? "s" : ""}`}
        back={{ href: "/services", label: "Retour aux services" }}
        actions={<Button asChild><Link href="/services/commandes/nouvelle"><Plus aria-hidden /> Nouvelle commande</Link></Button>}
      />
      <ListFilters
        basePath="/services/commandes"
        q={q}
        placeholder="N° de commande"
        selects={[
          { name: "status", label: "Statut", value: status, options: options(SERVICE_ORDER_STATUS), allLabel: "Tous statuts" },
          { name: "unpaid", label: "Paiement", value: unpaid ? "1" : undefined, options: [{ value: "1", label: "Avec solde à payer" }], allLabel: "Tous paiements" },
        ]}
      />
      {rows.length === 0 ? <Empty>Aucune commande trouvée.</Empty> : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">N°</th><th className="px-4 py-3">Date</th><th className="px-4 py-3">Client</th><th className="px-4 py-3">Service</th><th className="px-4 py-3 text-right">Total</th><th className="px-4 py-3 text-right">Solde</th><th className="px-4 py-3">Échéance</th><th className="px-4 py-3">Statut</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((o) => (
                  <tr key={o.id} className="hover:bg-muted/50">
                    <td className="px-4 py-3"><Link href={`/services/commandes/${o.id}`} className="font-mono text-xs font-semibold hover:text-primary">{o.order_number}</Link></td>
                    <td className="whitespace-nowrap px-4 py-3">{formatDate(o.order_date)}</td>
                    <td className="px-4 py-3">{o.customers?.name ?? "—"}</td>
                    <td className="px-4 py-3">{o.services?.name ?? "—"} <span className="text-muted-foreground">×{o.quantity}</span></td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums">{formatHTG(o.total)}</td>
                    <td className={`px-4 py-3 text-right tabular-nums ${o.balance > 0 && o.status !== "ANNULE" ? "font-semibold text-destructive" : ""}`}>{formatHTG(o.balance)}</td>
                    <td className="whitespace-nowrap px-4 py-3">{formatDate(o.due_date)}</td>
                    <td className="px-4 py-3"><StatusBadge map={SERVICE_ORDER_STATUS} value={o.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} basePath="/services/commandes" params={{ q, status, unpaid: unpaid ? "1" : undefined }} />
    </div>
  );
}
