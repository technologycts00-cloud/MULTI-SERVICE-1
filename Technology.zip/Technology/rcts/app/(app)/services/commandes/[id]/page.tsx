import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Receipt } from "lucide-react";
import { z } from "zod";
import { InvoiceButton } from "@/components/documents/invoice-button";
import { OrderStatusSelect } from "@/components/services/order-status";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS, RECORD_STATUS, SERVICE_ORDER_STATUS, formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, formatHTG } from "@/lib/utils";
import { getOrder } from "@/services/parties";
import { PayOrderForm } from "@/components/services/pay-order";
import { setOrderStatus } from "../../actions";

export const metadata: Metadata = { title: "Commande de service" };
export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireModule("services");
  const d = await getOrder(await createClient(), id);
  if (!d) notFound();
  const { order: o, responsible, payments } = d;
  const open = o.status !== "ANNULE";

  return (
    <div className="space-y-5">
      <PageHeader title={`Commande ${o.order_number}`} back={{ href: "/services/commandes", label: "Retour aux commandes" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge map={SERVICE_ORDER_STATUS} value={o.status} />
            <OrderStatusSelect value={o.status} change={setOrderStatus.bind(null, id)} />
          </div>
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div><dt className="text-xs text-muted-foreground">Client</dt><dd className="font-semibold">{o.customers ? <Link href={`/clients/${o.customers.id}`} className="hover:text-primary">{o.customers.name}</Link> : "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Service</dt><dd className="font-semibold">{o.services?.name} × {o.quantity} {o.services?.unit}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Date / échéance</dt><dd className="font-semibold">{formatDate(o.order_date)} → {formatDate(o.due_date)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Responsable</dt><dd className="font-semibold">{responsible ?? "—"}</dd></div>
          </dl>
          {o.comment && <p className="text-sm text-muted-foreground">{o.comment}</p>}
          <dl className="grid gap-4 text-sm sm:grid-cols-4">
            <div><dt className="text-xs text-muted-foreground">Prix unitaire</dt><dd className="font-semibold tabular-nums">{formatHTG(o.unit_price)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Total</dt><dd className="text-lg font-black tabular-nums">{formatHTG(o.total)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Payé</dt><dd className="font-semibold tabular-nums text-success">{formatHTG(o.amount_paid)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Solde</dt><dd className={`text-lg font-black tabular-nums ${o.balance > 0 && open ? "text-destructive" : ""}`}>{formatHTG(o.balance)}</dd></div>
          </dl>
          {open && o.balance > 0 && <PayOrderForm orderId={id} balance={o.balance} />}
          {open && <div className="flex flex-wrap gap-2"><InvoiceButton kind="SERVICE" targetId={id} /></div>}
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Paiements</CardTitle></CardHeader>
        <CardContent>
          {payments.length === 0 ? <p className="text-sm text-muted-foreground">Aucun paiement.</p> : (
            <ul className="divide-y divide-border">
              {payments.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
                  <span><span className="font-semibold tabular-nums">{formatHTG(p.amount)}</span> · {METHOD_LABELS[p.method] ?? p.method} · <span className="text-muted-foreground">{formatDateTime(p.paid_at)}</span></span>
                  <span className="flex items-center gap-3">
                    {p.status === "ANNULE" && <StatusBadge map={RECORD_STATUS} value="ANNULE" />}
                    {p.receipt_id && <Link href={`/recus/${p.receipt_id}`} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"><Receipt className="size-3.5" aria-hidden />{p.receipt_number}</Link>}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
