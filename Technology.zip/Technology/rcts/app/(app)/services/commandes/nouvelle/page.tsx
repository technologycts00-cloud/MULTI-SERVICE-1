import type { Metadata } from "next";
import { OrderForm } from "@/components/services/order-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { customerOptions, listServices, staffOptions } from "@/services/parties";
import { createServiceOrderAction } from "../../actions";

export const metadata: Metadata = { title: "Nouvelle commande de service" };
export const dynamic = "force-dynamic";

export default async function NewOrderPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireRole("ADMIN", "CAISSIER");
  const sp = await searchParams;
  const c = firstParam(sp.client);
  const db = await createClient();
  const [customers, services, staff] = await Promise.all([customerOptions(db), listServices(db, { inactive: false }), staffOptions(db)]);
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouvelle commande de service" back={{ href: "/services/commandes", label: "Retour aux commandes" }} />
      <OrderForm
        customers={customers}
        services={services.map((s) => ({ id: s.id, name: s.name, unit_price: s.unit_price, unit: s.unit }))}
        staff={staff}
        defaultCustomer={c && customers.some((x) => x.id === c) ? c : undefined}
        create={createServiceOrderAction}
      />
    </div>
  );
}
