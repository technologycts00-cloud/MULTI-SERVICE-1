import type { Metadata } from "next";
import Link from "next/link";
import { ClipboardList, Pencil, Plus } from "lucide-react";
import { Empty } from "@/components/shared/empty";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listServices } from "@/services/parties";

export const metadata: Metadata = { title: "Services" };
export const dynamic = "force-dynamic";

export default async function ServicesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("services");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const inactive = firstParam(sp.archives) === "1";
  const isAdmin = profile.role === "ADMIN";
  const rows = await listServices(await createClient(), { q, inactive });

  return (
    <div className="space-y-5">
      <PageHeader
        title={inactive ? "Services désactivés" : "Services"}
        description="Catalogue des services proposés (impression, réparation, saisie, etc.)"
        actions={
          <>
            <Button asChild variant="outline"><Link href="/services/commandes"><ClipboardList aria-hidden /> Commandes</Link></Button>
            {isAdmin && <Button asChild><Link href="/services/nouveau"><Plus aria-hidden /> Nouveau service</Link></Button>}
          </>
        }
      />
      <ListFilters basePath="/services" q={q} placeholder="Nom ou catégorie" archivedToggle={isAdmin ? { checked: inactive, label: "Voir les désactivés" } : undefined} />
      {rows.length === 0 ? <Empty>Aucun service trouvé.</Empty> : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">Service</th><th className="px-4 py-3">Catégorie</th><th className="px-4 py-3 text-right">Prix</th><th className="px-4 py-3">Unité</th><th className="px-4 py-3">Statut</th>{isAdmin && <th className="px-4 py-3" />}</tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((s) => (
                  <tr key={s.id} className="hover:bg-muted/50">
                    <td className="px-4 py-3"><div className="font-semibold">{s.name}</div>{s.description && <div className="text-xs text-muted-foreground">{s.description}</div>}</td>
                    <td className="px-4 py-3">{s.category ?? "—"}</td>
                    <td className="px-4 py-3 text-right font-semibold tabular-nums">{formatHTG(s.unit_price)}</td>
                    <td className="px-4 py-3">{s.unit}</td>
                    <td className="px-4 py-3"><Badge tone={s.is_active ? "green" : "slate"}>{s.is_active ? "Actif" : "Inactif"}</Badge></td>
                    {isAdmin && <td className="px-4 py-3 text-right"><Button asChild variant="ghost" size="sm"><Link href={`/services/${s.id}/modifier`}><Pencil aria-hidden /> Modifier</Link></Button></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
