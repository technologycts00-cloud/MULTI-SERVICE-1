import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { ServiceForm } from "@/components/services/service-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getService } from "@/services/parties";
import { saveService } from "../../actions";

export const metadata: Metadata = { title: "Modifier le service" };
export const dynamic = "force-dynamic";

export default async function EditServicePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN");
  const s = await getService(await createClient(), id);
  if (!s) notFound();
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier le service" back={{ href: "/services", label: "Retour aux services" }} />
      <ServiceForm id={id} save={saveService} defaults={{ name: s.name, category: s.category ?? "", description: s.description ?? "", unit_price: String(s.unit_price), unit: s.unit, is_active: s.is_active ? "true" : "false" }} />
    </div>
  );
}
