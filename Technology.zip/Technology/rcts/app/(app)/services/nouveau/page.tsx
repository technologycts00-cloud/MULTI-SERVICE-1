import type { Metadata } from "next";
import { ServiceForm } from "@/components/services/service-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { saveService } from "../actions";

export const metadata: Metadata = { title: "Nouveau service" };
export const dynamic = "force-dynamic";

export default async function NewServicePage() {
  await requireRole("ADMIN");
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouveau service" back={{ href: "/services", label: "Retour aux services" }} />
      <ServiceForm id={null} save={saveService} defaults={{ name: "", category: "", description: "", unit_price: "", unit: "unité", is_active: "true" }} />
    </div>
  );
}
