"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { serviceOrderSchema, serviceSchema } from "@/lib/validations/party";

const idSchema = z.uuid();

function refresh(orderId?: string) {
  for (const p of ["/services", "/services/commandes", "/clients", "/paiements", "/caisse", "/caisse/journal", "/dashboard", "/finances"]) revalidatePath(p);
  if (orderId) revalidatePath(`/services/commandes/${orderId}`);
}

export async function saveService(id: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  const p = serviceSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Service introuvable." };
  if (id === null) {
    const { data, error } = await auth.supabase.from("services").insert(p.data).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    refresh();
    return { ok: true, id: data.id };
  }
  const { data, error } = await auth.supabase.from("services").update(p.data).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Service introuvable ou accès refusé." };
  refresh();
  return { ok: true, id };
}

export async function setServiceActive(id: string, active: boolean): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Service introuvable." };
  const { error } = await auth.supabase.from("services").update({ is_active: active }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh();
  return { ok: true };
}

/** Commande de service : commande + acompte éventuel (paiement, caisse, reçu) en une transaction. */
export async function createServiceOrderAction(raw: unknown): Promise<ActionResult<{ id: string; number: string }>> {
  const auth = await authorize("ADMIN", "CAISSIER");
  if (!auth.ok) return auth;
  const p = serviceOrderSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  const { data, error } = await auth.supabase.rpc("create_service_order", {
    p_customer_id: p.data.customer_id,
    p_service_id: p.data.service_id,
    p_quantity: p.data.quantity,
    p_unit_price: p.data.unit_price,
    p_due_date: p.data.due_date,
    p_responsible_id: p.data.responsible_id,
    p_comment: p.data.comment,
    p_amount_paid: p.data.amount_paid,
    p_method: p.data.method,
    p_reference: p.data.reference,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  const r = data as { order_id: string; order_number: string };
  refresh(r.order_id);
  return { ok: true, id: r.order_id, number: r.order_number };
}

const STATUSES = ["EN_ATTENTE", "EN_COURS", "TERMINE", "LIVRE", "ANNULE"] as const;

export async function setOrderStatus(id: string, status: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN", "CAISSIER");
  if (!auth.ok) return auth;
  const s = z.enum(STATUSES).safeParse(status);
  if (!idSchema.safeParse(id).success || !s.success) return { ok: false, error: "Commande introuvable." };
  const { data, error } = await auth.supabase.from("service_orders").update({ status: s.data }).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Commande introuvable ou accès refusé." };
  refresh(id);
  return { ok: true };
}
