import { AppShell } from "@/components/layout/app-shell";
import { hiddenModules, requireProfile } from "@/lib/auth";
import { navForRole } from "@/lib/permissions";
import { createClient } from "@/lib/supabase/server";
import { logoutAction } from "../(auth)/actions";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile();
  const hidden = await hiddenModules(profile.role);
  const { data: org } = await (await createClient()).from("settings").select("key, value").eq("key", "logo_url").maybeSingle();
  const logo = typeof org?.value === "string" && org.value.startsWith("https://") ? org.value : null;

  return (
    <AppShell
      nav={navForRole(profile.role, hidden)}
      userName={profile.full_name ?? profile.email ?? "Utilisateur"}
      role={profile.role}
      logo={logo}
      logout={logoutAction}
    >
      {children}
    </AppShell>
  );
}
