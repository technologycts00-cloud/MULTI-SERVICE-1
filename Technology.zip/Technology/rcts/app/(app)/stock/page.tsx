import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AlertTriangle, Boxes, PackageX, Wallet } from "lucide-react";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { MovementForm } from "@/components/stock/movement-form";
import { MovementsTable } from "@/components/stock/movements-table";
import { ProductsTable } from "@/components/produits/products-table";
import { requireModule } from "@/lib/auth";
import { MOVEMENT_TYPES, STOCK_STATE, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listMovements, listProducts, stockSummary } from "@/services/products";
import { recordMovementAction, searchProductsAction } from "../produits/actions";

export const metadata: Metadata = { title: "Stock" };
export const dynamic = "force-dynamic";

export default async function StockPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("stock");
  const canWrite = profile.role === "ADMIN" || profile.role === "GESTIONNAIRE";
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const state = firstParam(sp.state) && firstParam(sp.state)! in STOCK_STATE ? firstParam(sp.state) : undefined;
  const type = firstParam(sp.type) && firstParam(sp.type)! in MOVEMENT_TYPES ? firstParam(sp.type) : undefined;
  const page = parsePage(firstParam(sp.page));
  const mpage = parsePage(firstParam(sp.mpage));

  const db = await createClient();
  const [summary, products, moves] = await Promise.all([
    stockSummary(db),
    listProducts(db, { q, state, status: "ACTIF", page }),
    listMovements(db, { type, page: mpage, limit: 10 }),
  ]);
  if (products.rows.length === 0 && page > 1) redirect("/stock");

  return (
    <div className="space-y-5">
      <PageHeader title="Stock" description="Le stock ne change que par des mouvements enregistrés (vente, achat, entrée, sortie, ajustement, inventaire)." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard label="En stock" value={String(summary.ok)} tone="green" icon={Boxes} />
        <KpiCard label="Stock faible" value={String(summary.low)} tone="yellow" icon={AlertTriangle} />
        <KpiCard label="En rupture" value={String(summary.out)} tone="red" icon={PackageX} />
        <KpiCard label="Valeur du stock" value={formatHTG(summary.valueCost)} hint={`à la vente : ${formatHTG(summary.valueSale)}`} tone="blue" icon={Wallet} />
      </div>

      {canWrite && <MovementForm initialProduct={null} search={searchProductsAction as never} save={recordMovementAction} />}

      <ListFilters
        basePath="/stock"
        q={q}
        placeholder="Nom ou code produit"
        selects={[{ name: "state", label: "État du stock", value: state, options: options(STOCK_STATE), allLabel: "Tous les états" }]}
      />
      <ProductsTable rows={products.rows} showCost={canWrite} />
      <Pagination page={page} total={products.total} basePath="/stock" params={{ q, state, type, mpage: mpage > 1 ? String(mpage) : undefined }} />

      <h2 className="pt-2 text-lg font-bold">Derniers mouvements</h2>
      <form method="get" action="/stock" className="flex gap-2">
        <input type="hidden" name="q" value={q ?? ""} />
        <select name="type" defaultValue={type ?? ""} aria-label="Type de mouvement" className="h-10 rounded-lg border border-border bg-white px-3 text-sm">
          <option value="">Tous les types</option>
          {options(MOVEMENT_TYPES).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <button className="h-10 rounded-lg border border-border bg-white px-4 text-sm font-semibold hover:bg-muted">Filtrer</button>
        {type && <Link href="/stock" className="inline-flex h-10 items-center text-sm text-primary">Réinitialiser</Link>}
      </form>
      <MovementsTable rows={moves.rows} />
      <Pagination page={mpage} total={moves.total} basePath="/stock" params={{ q, state, type, page: page > 1 ? String(page) : undefined }} pageParam="mpage" pageSize={10} />
    </div>
  );
}
