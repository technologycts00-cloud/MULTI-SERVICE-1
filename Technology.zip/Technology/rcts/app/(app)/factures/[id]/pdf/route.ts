import { NextResponse } from "next/server";
import { z } from "zod";
import { buildInvoicePdf } from "@/lib/pdf";
import { createClient } from "@/lib/supabase/server";
import { getInvoice } from "@/services/documents";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) return new NextResponse("Introuvable", { status: 404 });
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new NextResponse("Non autorisé", { status: 401 });

  const data = await getInvoice(supabase, id);
  if (!data) return new NextResponse("Introuvable", { status: 404 });
  return new NextResponse(buildInvoicePdf(data), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${data.invoice.invoice_number}.pdf"`,
      "Cache-Control": "private, no-store",
    },
  });
}
