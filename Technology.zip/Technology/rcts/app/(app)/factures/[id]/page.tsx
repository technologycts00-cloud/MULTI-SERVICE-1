import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { InvoiceView } from "@/components/documents/invoice-view";
import { PrintControls } from "@/components/documents/print-controls";
import { PageHeader } from "@/components/shared/page-header";
import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getInvoice } from "@/services/documents";

export const metadata: Metadata = { title: "Facture" };
export const dynamic = "force-dynamic";

export default async function InvoicePage({ params }: { params: Promise<{ id: string }> }) {
  await requireProfile();
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const data = await getInvoice(await createClient(), id);
  if (!data) notFound();
  return (
    <div className="space-y-5">
      <div className="print:hidden">
        <PageHeader title={`Facture ${data.invoice.invoice_number}`} back={{ href: "/paiements", label: "Paiements" }} />
      </div>
      <PrintControls pdfHref={`/factures/${id}/pdf`} />
      <InvoiceView data={data} />
    </div>
  );
}
