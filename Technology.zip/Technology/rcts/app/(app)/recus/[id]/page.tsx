import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { PrintControls } from "@/components/documents/print-controls";
import { ReceiptView, type ReceiptFormat } from "@/components/documents/receipt-view";
import { PageHeader } from "@/components/shared/page-header";
import { requireProfile } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { getReceipt } from "@/services/documents";

export const metadata: Metadata = { title: "Reçu" };
export const dynamic = "force-dynamic";

export default async function ReceiptPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  await requireProfile();
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const sp = await searchParams;
  const format: ReceiptFormat = firstParam(sp.format) === "ticket" ? "ticket" : "a5";
  const autoPrint = firstParam(sp.print) === "1";

  const data = await getReceipt(await createClient(), id);
  if (!data) notFound();

  return (
    <div className="space-y-5">
      <div className="print:hidden">
        <PageHeader title={`Reçu ${data.receipt.receipt_number}`} back={{ href: "/paiements", label: "Paiements" }} />
      </div>
      <PrintControls
        autoPrint={autoPrint}
        pdfHref={`/recus/${id}/pdf?format=${format}`}
        formats={[
          { href: `/recus/${id}?format=a5`, label: "Format A5", active: format === "a5" },
          { href: `/recus/${id}?format=ticket`, label: "Ticket 80 mm", active: format === "ticket" },
        ]}
      />
      <ReceiptView data={data} format={format} />
    </div>
  );
}
