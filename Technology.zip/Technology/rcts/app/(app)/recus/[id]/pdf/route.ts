import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { buildReceiptPdf } from "@/lib/pdf";
import { createClient } from "@/lib/supabase/server";
import { getReceipt } from "@/services/documents";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) return new NextResponse("Introuvable", { status: 404 });
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new NextResponse("Non autorisé", { status: 401 });

  const data = await getReceipt(supabase, id);
  if (!data) return new NextResponse("Introuvable", { status: 404 });
  const format = req.nextUrl.searchParams.get("format") === "ticket" ? "ticket" : "a5";
  const pdf = buildReceiptPdf(data, format);
  return new NextResponse(pdf, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${data.receipt.receipt_number}.pdf"`,
      "Cache-Control": "private, no-store",
    },
  });
}
