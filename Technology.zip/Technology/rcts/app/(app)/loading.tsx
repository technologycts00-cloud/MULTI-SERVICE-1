export default function Loading() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3" role="status" aria-live="polite">
      <div className="size-10 animate-spin rounded-full border-4 border-primary/20 border-t-primary" aria-hidden />
      <p className="text-sm text-muted-foreground">Chargement…</p>
    </div>
  );
}
