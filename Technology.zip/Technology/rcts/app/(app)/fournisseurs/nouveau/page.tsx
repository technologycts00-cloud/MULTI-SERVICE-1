import type { Metadata } from "next";
import { SupplierForm } from "@/components/fournisseurs/supplier-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { saveSupplier } from "../actions";

export const metadata: Metadata = { title: "Nouveau fournisseur" };
export const dynamic = "force-dynamic";

export default async function NewSupplierPage() {
  await requireRole("ADMIN", "GESTIONNAIRE");
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouveau fournisseur" back={{ href: "/fournisseurs", label: "Retour aux fournisseurs" }} />
      <SupplierForm id={null} save={saveSupplier} defaults={{ name: "", company: "", phone: "", email: "", address: "", products_supplied: "", notes: "" }} />
    </div>
  );
}
