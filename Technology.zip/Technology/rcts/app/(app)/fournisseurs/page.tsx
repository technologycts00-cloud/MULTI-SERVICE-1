import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { PackagePlus, Plus } from "lucide-react";
import { Empty } from "@/components/shared/empty";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listSuppliers } from "@/services/parties";

export const metadata: Metadata = { title: "Fournisseurs" };
export const dynamic = "force-dynamic";

export default async function SuppliersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("fournisseurs");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const archived = firstParam(sp.archives) === "1";
  const debt = firstParam(sp.debt) === "1";
  const page = parsePage(firstParam(sp.page));
  const { rows, total } = await listSuppliers(await createClient(), { q, archived, debt, page });
  if (rows.length === 0 && page > 1) redirect("/fournisseurs");

  return (
    <div className="space-y-5">
      <PageHeader
        title={archived ? "Fournisseurs archivés" : "Fournisseurs"}
        description={`${total} fournisseur${total > 1 ? "s" : ""}`}
        actions={
          <>
            <Button asChild variant="outline"><Link href="/fournisseurs/achats/nouveau"><PackagePlus aria-hidden /> Nouvel achat</Link></Button>
            <Button asChild><Link href="/fournisseurs/nouveau"><Plus aria-hidden /> Nouveau fournisseur</Link></Button>
          </>
        }
      />
      <ListFilters
        basePath="/fournisseurs"
        q={q}
        placeholder="Nom, entreprise, téléphone ou produits"
        selects={[{ name: "debt", label: "Dette", value: debt ? "1" : undefined, options: [{ value: "1", label: "Avec dette" }], allLabel: "Toutes situations" }]}
        archivedToggle={{ checked: archived, label: "Voir les archivés" }}
      />
      {rows.length === 0 ? <Empty>Aucun fournisseur trouvé.</Empty> : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">Fournisseur</th><th className="px-4 py-3">Entreprise</th><th className="px-4 py-3">Téléphone</th><th className="px-4 py-3 text-right">Total acheté</th><th className="px-4 py-3 text-right">Dette</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((s) => (
                  <tr key={s.id} className="hover:bg-muted/50">
                    <td className="px-4 py-3 font-semibold"><Link href={`/fournisseurs/${s.id}`} className="hover:text-primary">{s.name}</Link></td>
                    <td className="px-4 py-3">{s.company ?? "—"}</td>
                    <td className="px-4 py-3">{s.phone ?? "—"}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{formatHTG(s.total_purchased)}</td>
                    <td className={`px-4 py-3 text-right tabular-nums ${s.amount_due > 0 ? "font-semibold text-destructive" : ""}`}>{formatHTG(s.amount_due)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} basePath="/fournisseurs" params={{ q, debt: debt ? "1" : undefined, archives: archived ? "1" : undefined }} />
    </div>
  );
}
