import type { Metadata } from "next";
import { PurchaseForm } from "@/components/fournisseurs/purchase-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { productCostOptions } from "@/services/parties";
import { listSupplierOptions } from "@/services/products";
import { createPurchaseAction } from "../../actions";

export const metadata: Metadata = { title: "Nouvel achat" };
export const dynamic = "force-dynamic";

export default async function NewPurchasePage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireRole("ADMIN", "GESTIONNAIRE");
  const sp = await searchParams;
  const f = firstParam(sp.fournisseur);
  const db = await createClient();
  const [suppliers, products] = await Promise.all([listSupplierOptions(db), productCostOptions(db)]);
  return (
    <div className="max-w-4xl space-y-5">
      <PageHeader title="Nouvel achat fournisseur" description="Le stock des produits est augmenté automatiquement." back={{ href: "/fournisseurs", label: "Retour aux fournisseurs" }} />
      <PurchaseForm suppliers={suppliers} products={products} defaultSupplier={f && suppliers.some((s) => s.id === f) ? f : undefined} create={createPurchaseAction} />
    </div>
  );
}
