import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { PaySupplierForm } from "@/components/fournisseurs/pay-supplier";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS, RECORD_STATUS, formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, formatHTG } from "@/lib/utils";
import { getPurchase } from "@/services/parties";
import { paySupplierAction } from "../../actions";

export const metadata: Metadata = { title: "Achat fournisseur" };
export const dynamic = "force-dynamic";

export default async function PurchasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireModule("fournisseurs");
  const d = await getPurchase(await createClient(), id);
  if (!d) notFound();
  const { purchase: p, items, payments } = d;

  return (
    <div className="space-y-5">
      <PageHeader title={`Achat ${p.purchase_number}`} back={{ href: p.suppliers ? `/fournisseurs/${p.suppliers.id}` : "/fournisseurs", label: "Retour au fournisseur" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2"><StatusBadge map={RECORD_STATUS} value={p.status} /><span className="text-sm text-muted-foreground">{formatDate(p.purchase_date)}</span></div>
          <dl className="grid gap-4 text-sm sm:grid-cols-4">
            <div><dt className="text-xs text-muted-foreground">Fournisseur</dt><dd className="font-semibold">{p.suppliers ? <Link href={`/fournisseurs/${p.suppliers.id}`} className="hover:text-primary">{p.suppliers.name}</Link> : "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Total</dt><dd className="text-lg font-black tabular-nums">{formatHTG(p.total_amount)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Payé</dt><dd className="font-semibold tabular-nums text-success">{formatHTG(p.amount_paid)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Reste à payer</dt><dd className={`text-lg font-black tabular-nums ${p.balance > 0 ? "text-destructive" : ""}`}>{formatHTG(p.balance)}</dd></div>
          </dl>
          {p.notes && <p className="text-sm text-muted-foreground">{p.notes}</p>}
          {p.status === "VALIDE" && p.balance > 0 && <PaySupplierForm purchaseId={id} balance={p.balance} pay={paySupplierAction} />}
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Produits</CardTitle></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[420px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">Produit</th><th className="px-4 py-3 text-right">Qté</th><th className="px-4 py-3 text-right">Coût unitaire</th><th className="px-4 py-3 text-right">Sous-total</th></tr></thead>
              <tbody className="divide-y divide-border">
                {items.map((i) => (<tr key={i.id}><td className="px-4 py-3">{i.products?.name} <span className="font-mono text-xs text-muted-foreground">{i.products?.code}</span></td><td className="px-4 py-3 text-right tabular-nums">{i.quantity}</td><td className="px-4 py-3 text-right tabular-nums">{formatHTG(i.unit_cost)}</td><td className="px-4 py-3 text-right font-semibold tabular-nums">{formatHTG(i.line_total)}</td></tr>))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Paiements au fournisseur</CardTitle></CardHeader>
        <CardContent>
          {payments.length === 0 ? <p className="text-sm text-muted-foreground">Aucun paiement.</p> : (
            <ul className="divide-y divide-border text-sm">
              {payments.map((x) => (<li key={x.id} className="flex flex-wrap items-center justify-between gap-2 py-2"><span><span className="font-semibold tabular-nums">{formatHTG(x.amount)}</span> · {METHOD_LABELS[x.method] ?? x.method}{x.reference ? ` · ${x.reference}` : ""} · <span className="text-muted-foreground">{formatDateTime(x.paid_at)}</span></span><span className="font-mono text-xs text-muted-foreground">{x.payment_number}</span></li>))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
