import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { SupplierForm } from "@/components/fournisseurs/supplier-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getSupplier } from "@/services/parties";
import { saveSupplier } from "../../actions";

export const metadata: Metadata = { title: "Modifier le fournisseur" };
export const dynamic = "force-dynamic";

export default async function EditSupplierPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN", "GESTIONNAIRE");
  const d = await getSupplier(await createClient(), id);
  if (!d) notFound();
  const s = d.supplier;
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier le fournisseur" back={{ href: `/fournisseurs/${id}`, label: "Retour au fournisseur" }} />
      <SupplierForm id={id} save={saveSupplier} defaults={{ name: s.name, company: s.company ?? "", phone: s.phone ?? "", email: s.email ?? "", address: s.address ?? "", products_supplied: s.products_supplied ?? "", notes: s.notes ?? "" }} />
    </div>
  );
}
