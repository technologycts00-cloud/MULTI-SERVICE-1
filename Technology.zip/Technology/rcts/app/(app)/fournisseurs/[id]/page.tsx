import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Archive, ArchiveRestore, PackagePlus, Pencil } from "lucide-react";
import { z } from "zod";
import { ActionButton } from "@/components/shared/action-button";
import { Stat } from "@/components/shared/empty";
import { PageHeader } from "@/components/shared/page-header";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { RECORD_STATUS, formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { getSupplier } from "@/services/parties";
import { setSupplierArchived } from "../actions";

export const metadata: Metadata = { title: "Fournisseur" };
export const dynamic = "force-dynamic";

export default async function SupplierPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireModule("fournisseurs");
  const d = await getSupplier(await createClient(), id);
  if (!d) notFound();
  const { supplier: s, totals, purchases } = d;

  return (
    <div className="space-y-5">
      <PageHeader title="Fournisseur" back={{ href: "/fournisseurs", label: "Retour aux fournisseurs" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black">{s.name}</h2>
            {s.company && <span className="text-sm text-muted-foreground">{s.company}</span>}
            {s.is_archived && <Badge>Archivé</Badge>}
          </div>
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div><dt className="text-xs text-muted-foreground">Téléphone</dt><dd className="font-semibold">{s.phone ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">E-mail</dt><dd className="font-semibold">{s.email ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Adresse</dt><dd className="font-semibold">{s.address ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Produits fournis</dt><dd className="font-semibold">{s.products_supplied ?? "—"}</dd></div>
          </dl>
          {s.notes && <p className="text-sm text-muted-foreground">{s.notes}</p>}
          <div className="flex flex-wrap items-center gap-2">
            {!s.is_archived && <Button asChild><Link href={`/fournisseurs/achats/nouveau?fournisseur=${id}`}><PackagePlus aria-hidden /> Nouvel achat</Link></Button>}
            <Button asChild variant="outline"><Link href={`/fournisseurs/${id}/modifier`}><Pencil aria-hidden /> Modifier</Link></Button>
            {s.is_archived ? (
              <ActionButton size="default" action={setSupplierArchived.bind(null, id, false)}><ArchiveRestore aria-hidden /> Restaurer</ActionButton>
            ) : (
              <ActionButton size="default" action={setSupplierArchived.bind(null, id, true)} confirm={{ title: "Archiver ce fournisseur ?", description: "Il n'apparaîtra plus dans les listes de sélection. L'historique des achats est conservé.", confirmLabel: "Archiver" }}><Archive aria-hidden /> Archiver</ActionButton>
            )}
          </div>
        </CardContent>
      </Card>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Total acheté" value={formatHTG(totals.purchased)} />
        <Stat label="Total payé" value={formatHTG(totals.paid)} tone="green" />
        <Stat label="Dette envers ce fournisseur" value={formatHTG(totals.due)} tone={totals.due > 0 ? "red" : undefined} />
      </div>
      <Card>
        <CardHeader><CardTitle>Achats</CardTitle></CardHeader>
        <CardContent className="p-0">
          {purchases.length === 0 ? <p className="p-6 text-sm text-muted-foreground">Aucun achat enregistré.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[520px] text-sm">
                <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">N°</th><th className="px-4 py-3">Date</th><th className="px-4 py-3 text-right">Total</th><th className="px-4 py-3 text-right">Payé</th><th className="px-4 py-3 text-right">Reste</th><th className="px-4 py-3">Statut</th></tr></thead>
                <tbody className="divide-y divide-border">
                  {purchases.map((p) => (
                    <tr key={p.id} className="hover:bg-muted/50">
                      <td className="px-4 py-3"><Link href={`/fournisseurs/achats/${p.id}`} className="font-mono text-xs font-semibold hover:text-primary">{p.purchase_number}</Link></td>
                      <td className="px-4 py-3">{formatDate(p.purchase_date)}</td>
                      <td className="px-4 py-3 text-right font-semibold tabular-nums">{formatHTG(p.total_amount)}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{formatHTG(p.amount_paid)}</td>
                      <td className={`px-4 py-3 text-right tabular-nums ${p.balance > 0 ? "font-semibold text-destructive" : ""}`}>{formatHTG(p.balance)}</td>
                      <td className="px-4 py-3"><StatusBadge map={RECORD_STATUS} value={p.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
