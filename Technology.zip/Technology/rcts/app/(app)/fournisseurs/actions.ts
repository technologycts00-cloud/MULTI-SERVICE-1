"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { purchaseSchema, supplierPaymentSchema, supplierSchema } from "@/lib/validations/party";

const WRITERS = ["ADMIN", "GESTIONNAIRE"] as const;
const idSchema = z.uuid();

function refresh(supplierId?: string) {
  for (const p of ["/fournisseurs", "/produits", "/stock", "/caisse", "/caisse/journal", "/dashboard", "/finances"]) revalidatePath(p);
  if (supplierId) revalidatePath(`/fournisseurs/${supplierId}`);
}

export async function saveSupplier(id: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const p = supplierSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Fournisseur introuvable." };
  if (id === null) {
    const { data, error } = await auth.supabase.from("suppliers").insert(p.data).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    refresh();
    return { ok: true, id: data.id };
  }
  const { data, error } = await auth.supabase.from("suppliers").update(p.data).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Fournisseur introuvable ou accès refusé." };
  refresh(id);
  return { ok: true, id };
}

export async function setSupplierArchived(id: string, archived: boolean): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Fournisseur introuvable." };
  const { error } = await auth.supabase.from("suppliers").update({ is_archived: archived }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

/** Achat fournisseur : achat + lignes + entrées de stock + paiement éventuel (caisse) en une transaction. */
export async function createPurchaseAction(raw: unknown): Promise<ActionResult<{ id: string; number: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const p = purchaseSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message ?? "Achat invalide.", fieldErrors: zodFieldErrors(p.error) };
  const { data, error } = await auth.supabase.rpc("create_purchase", {
    p_supplier_id: p.data.supplier_id,
    p_items: p.data.items.map((i) => ({ product_id: i.product_id, quantity: i.quantity, unit_cost: i.unit_cost })),
    p_amount_paid: p.data.amount_paid,
    p_method: p.data.method,
    p_reference: p.data.reference,
    p_notes: p.data.notes,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  const r = data as { purchase_id: string; purchase_number: string };
  refresh(p.data.supplier_id);
  return { ok: true, id: r.purchase_id, number: r.purchase_number };
}

export async function paySupplierAction(raw: unknown): Promise<ActionResult<{ balance: number }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const p = supplierPaymentSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message ?? "Paiement invalide.", fieldErrors: zodFieldErrors(p.error) };
  const { data, error } = await auth.supabase.rpc("pay_supplier", {
    p_purchase_id: p.data.purchase_id, p_amount: p.data.amount, p_method: p.data.method, p_reference: p.data.reference,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh();
  revalidatePath(`/fournisseurs/achats/${p.data.purchase_id}`);
  return { ok: true, balance: Number((data as { balance: number }).balance) };
}
