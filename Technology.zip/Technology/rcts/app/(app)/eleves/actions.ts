"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { studentSchema } from "@/lib/validations/student";

const idSchema = z.uuid();
const WRITERS = ["ADMIN", "SECRETAIRE"] as const;

function refresh(id?: string) {
  revalidatePath("/eleves");
  if (id) revalidatePath(`/eleves/${id}`);
  revalidatePath("/dashboard");
}

/** Création (id = null) ou modification d'un élève. Toute la validation est refaite côté serveur. */
export async function saveStudent(id: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;

  const parsed = studentSchema.safeParse(raw);
  if (!parsed.success) {
    return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(parsed.error) };
  }
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Élève introuvable." };

  const { supabase } = auth;
  const v = parsed.data;

  // Doublon probable : même nom, même prénom, même date de naissance
  if (v.birth_date) {
    let dup = supabase
      .from("students")
      .select("student_code")
      .ilike("first_name", v.first_name)
      .ilike("last_name", v.last_name)
      .eq("birth_date", v.birth_date)
      .limit(1);
    if (id) dup = dup.neq("id", id);
    const { data } = await dup;
    if (data && data.length > 0) {
      return {
        ok: false,
        error: `Un élève avec le même nom et la même date de naissance existe déjà (${data[0].student_code}).`,
      };
    }
  }

  if (id === null) {
    const { data, error } = await supabase.from("students").insert(v).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    refresh(data.id);
    return { ok: true, id: data.id };
  }

  const { data, error } = await supabase.from("students").update(v).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Élève introuvable ou accès refusé." };
  refresh(id);
  return { ok: true, id };
}

/** Archivage (jamais de suppression) : refusé s'il reste des inscriptions actives. */
export async function archiveStudent(id: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Élève introuvable." };

  const { supabase } = auth;
  const { count } = await supabase
    .from("enrollments")
    .select("id", { count: "exact", head: true })
    .eq("student_id", id)
    .eq("status", "ACTIVE");
  if (count && count > 0) {
    return {
      ok: false,
      error: "Cet élève a des inscriptions actives : terminez-les ou annulez-les avant de l'archiver.",
    };
  }

  const { error } = await supabase.from("students").update({ is_archived: true }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

export async function restoreStudent(id: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Élève introuvable." };

  const { error } = await auth.supabase.from("students").update({ is_archived: false }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

// --------------------------------------------------------------------------- Photo

const MAX_PHOTO = 2 * 1024 * 1024;

/** Vérifie le contenu réel du fichier (ne pas se fier au type MIME envoyé par le navigateur). */
function sniffImage(b: Uint8Array): { ext: string; mime: string } | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: "jpg", mime: "image/jpeg" };
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return { ext: "png", mime: "image/png" };
  if (
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
  ) {
    return { ext: "webp", mime: "image/webp" };
  }
  return null;
}

export async function uploadStudentPhoto(id: string, formData: FormData): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Élève introuvable." };

  const file = formData.get("photo");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choisissez une photo." };
  if (file.size > MAX_PHOTO) return { ok: false, error: "La photo dépasse 2 Mo : choisissez une image plus légère." };

  const bytes = new Uint8Array(await file.arrayBuffer());
  const kind = sniffImage(bytes);
  if (!kind) return { ok: false, error: "Format non accepté : utilisez une photo JPEG, PNG ou WebP." };

  const { supabase } = auth;
  const { data: student } = await supabase.from("students").select("photo_url").eq("id", id).maybeSingle();
  if (!student) return { ok: false, error: "Élève introuvable ou accès refusé." };

  const path = `${id}/${Date.now()}.${kind.ext}`;
  const { error: upErr } = await supabase.storage
    .from("student-photos")
    .upload(path, bytes, { contentType: kind.mime, upsert: false });
  if (upErr) {
    return {
      ok: false,
      error: "Envoi impossible. Vérifiez que la migration 0008 a été exécutée dans Supabase (bucket « student-photos »).",
    };
  }

  const { error } = await supabase.from("students").update({ photo_url: path }).eq("id", id);
  if (error) {
    await supabase.storage.from("student-photos").remove([path]);
    return { ok: false, error: dbErrorMessage(error) };
  }
  if (student.photo_url) await supabase.storage.from("student-photos").remove([student.photo_url]);
  refresh(id);
  return { ok: true };
}

export async function removeStudentPhoto(id: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Élève introuvable." };

  const { supabase } = auth;
  const { data: student } = await supabase.from("students").select("photo_url").eq("id", id).maybeSingle();
  if (!student) return { ok: false, error: "Élève introuvable ou accès refusé." };

  const { error } = await supabase.from("students").update({ photo_url: null }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (student.photo_url) await supabase.storage.from("student-photos").remove([student.photo_url]);
  refresh(id);
  return { ok: true };
}

