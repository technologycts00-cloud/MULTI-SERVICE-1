import type { Metadata } from "next";
import { StudentForm } from "@/components/eleves/student-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { todayHaiti } from "@/lib/utils";
import { saveStudent } from "../actions";

export const metadata: Metadata = { title: "Nouvel élève" };

export default async function NewStudentPage() {
  await requireRole("ADMIN", "SECRETAIRE");
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouvel élève" back={{ href: "/eleves", label: "Retour aux élèves" }} description="L'ID étudiant est attribué automatiquement." />
      <StudentForm
        studentId={null}
        save={saveStudent}
        defaults={{
          first_name: "",
          last_name: "",
          gender: "",
          birth_date: "",
          phone: "",
          email: "",
          address: "",
          enrolled_on: todayHaiti(),
          status: "ACTIF",
          notes: "",
        }}
      />
    </div>
  );
}

