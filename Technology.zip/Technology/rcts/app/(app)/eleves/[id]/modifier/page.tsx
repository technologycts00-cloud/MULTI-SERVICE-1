import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { StudentForm } from "@/components/eleves/student-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { saveStudent } from "../../actions";

export const metadata: Metadata = { title: "Modifier l'élève" };
export const dynamic = "force-dynamic";

export default async function EditStudentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN", "SECRETAIRE");
  const { data: s } = await (await createClient()).from("students").select("*").eq("id", id).maybeSingle();
  if (!s) notFound();

  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier l'élève" description={s.student_code} back={{ href: `/eleves/${id}`, label: "Retour à la fiche" }} />
      <StudentForm
        studentId={id}
        save={saveStudent}
        defaults={{
          first_name: s.first_name,
          last_name: s.last_name,
          gender: s.gender ?? "",
          birth_date: s.birth_date ?? "",
          phone: s.phone ?? "",
          email: s.email ?? "",
          address: s.address ?? "",
          enrolled_on: s.enrolled_on,
          status: s.status,
          notes: s.notes ?? "",
        }}
      />
    </div>
  );
}
