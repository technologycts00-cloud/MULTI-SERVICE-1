import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArchiveRestore, Archive, Pencil, UserCheck } from "lucide-react";
import { z } from "zod";
import { PhotoUploader } from "@/components/eleves/photo-uploader";
import { StudentProfile } from "@/components/eleves/student-profile";
import { PageHeader } from "@/components/shared/page-header";
import { ActionButton } from "@/components/shared/action-button";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getStudentDetail, signedPhotoUrl } from "@/services/students";
import { archiveStudent, removeStudentPhoto, restoreStudent, uploadStudentPhoto } from "../actions";

export const metadata: Metadata = { title: "Fiche élève" };
export const dynamic = "force-dynamic";

export default async function StudentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();

  const profile = await requireModule("eleves");
  const canWrite = profile.role === "ADMIN" || profile.role === "SECRETAIRE";
  const supabase = await createClient();

  const detail = await getStudentDetail(supabase, id, canWrite);
  if (!detail) notFound();
  const { student } = detail;
  const photoUrl = await signedPhotoUrl(supabase, student.photo_url);

  return (
    <div className="space-y-5">
      <PageHeader title="Fiche élève" back={{ href: "/eleves", label: "Retour aux élèves" }} />
      <StudentProfile
        student={student}
        photoUrl={photoUrl}
        enrollments={detail.enrollments}
        payments={detail.payments}
        receipts={detail.receipts}
        certificates={detail.certificates}
        photoControls={
          canWrite && (
            <PhotoUploader
              hasPhoto={!!student.photo_url}
              upload={uploadStudentPhoto.bind(null, id)}
              remove={removeStudentPhoto.bind(null, id)}
            />
          )
        }
        actions={
          canWrite && (
            <>
              {!student.is_archived && student.status !== "SUSPENDU" && (
                <Button asChild>
                  <Link href={`/inscriptions/nouvelle?student=${id}`}>
                    <UserCheck aria-hidden /> Inscrire à une formation
                  </Link>
                </Button>
              )}
              <Button asChild variant="outline">
                <Link href={`/eleves/${id}/modifier`}>
                  <Pencil aria-hidden /> Modifier
                </Link>
              </Button>
              {student.is_archived ? (
                <ActionButton action={restoreStudent.bind(null, id)} size="default">
                  <ArchiveRestore aria-hidden /> Restaurer
                </ActionButton>
              ) : (
                <ActionButton
                  action={archiveStudent.bind(null, id)}
                  size="default"
                  variant="outline"
                  confirm={{
                    title: "Archiver cet élève ?",
                    description:
                      "L'élève disparaît de la liste principale mais son historique (inscriptions, paiements, reçus) est conservé. Vous pourrez le restaurer.",
                    confirmLabel: "Archiver",
                  }}
                >
                  <Archive aria-hidden /> Archiver
                </ActionButton>
              )}
            </>
          )
        }
      />
    </div>
  );
}

