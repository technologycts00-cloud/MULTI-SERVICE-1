import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { UserPlus } from "lucide-react";
import { StudentsTable } from "@/components/eleves/students-table";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { STUDENT_STATUS, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { listStudents } from "@/services/students";

export const metadata: Metadata = { title: "Élèves" };
export const dynamic = "force-dynamic";

export default async function ElevesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const profile = await requireModule("eleves");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const rawStatus = firstParam(sp.status);
  const status = rawStatus && rawStatus in STUDENT_STATUS ? rawStatus : undefined;
  const canWrite = profile.role === "ADMIN" || profile.role === "SECRETAIRE";
  const archived = canWrite && firstParam(sp.archives) === "1";
  const page = parsePage(firstParam(sp.page));

  const supabase = await createClient();
  const { rows, total, balances } = await listStudents(supabase, { q, status, archived, page }, canWrite);

  if (rows.length === 0 && page > 1) {
    const back = new URLSearchParams();
    if (q) back.set("q", q);
    if (status) back.set("status", status);
    if (archived) back.set("archives", "1");
    redirect(back.size ? `/eleves?${back}` : "/eleves");
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title={archived ? "Élèves archivés" : "Élèves"}
        description={`${total} élève${total > 1 ? "s" : ""}${profile.role === "FORMATEUR" ? " dans vos formations" : ""}`}
        actions={
          canWrite && (
            <Button asChild>
              <Link href="/eleves/nouveau">
                <UserPlus aria-hidden /> Nouvel élève
              </Link>
            </Button>
          )
        }
      />
      <ListFilters
        basePath="/eleves"
        q={q}
        placeholder="Nom, prénom, ID étudiant ou téléphone"
        selects={[{ name: "status", label: "Statut", value: status, options: options(STUDENT_STATUS), allLabel: "Tous les statuts" }]}
        archivedToggle={canWrite ? { checked: archived, label: "Voir les archivés" } : undefined}
      />
      <StudentsTable rows={rows} balances={balances} />
      <Pagination page={page} total={total} basePath="/eleves" params={{ q, status, archives: archived ? "1" : undefined }} />
    </div>
  );
}

