import type { Metadata } from "next";
import { Badge } from "@/components/ui/badge";
import { Empty } from "@/components/shared/empty";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { requireModule } from "@/lib/auth";
import { pageRange, parsePage, firstParam, sanitizeSearch } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, haitiDayStartISO, nextDay } from "@/lib/utils";

export const metadata: Metadata = { title: "Journal d'audit" };
export const dynamic = "force-dynamic";

const MODULES: Record<string, string> = {
  profiles: "Utilisateurs", students: "Élèves", trainings: "Formations", enrollments: "Inscriptions", certificates: "Certificats",
  payments: "Paiements", receipts: "Reçus", invoices: "Factures", customers: "Clients", suppliers: "Fournisseurs",
  services: "Services", service_orders: "Commandes de service", products: "Produits", stock_movements: "Mouvements de stock",
  sales: "Ventes", expenses: "Dépenses", cash_transactions: "Caisse", purchases: "Achats", supplier_payments: "Paiements fournisseurs",
  settings: "Paramètres", users_roles: "Permissions", product_categories: "Catégories de produits", expense_categories: "Catégories de dépenses",
};
const ACTIONS: Record<string, { label: string; tone: "green" | "blue" | "red" }> = {
  INSERT: { label: "Création", tone: "green" }, UPDATE: { label: "Modification", tone: "blue" }, DELETE: { label: "Suppression", tone: "red" },
};
const HIDDEN_KEYS = new Set(["updated_at", "created_at"]);

type Json = Record<string, unknown> | null;
function changes(action: string, oldV: Json, newV: Json): { key: string; from?: string; to?: string }[] {
  const show = (v: unknown) => (v === null || v === undefined ? "—" : typeof v === "object" ? JSON.stringify(v) : String(v));
  if (action === "UPDATE" && oldV && newV) {
    return Object.keys(newV).filter((k) => !HIDDEN_KEYS.has(k) && JSON.stringify(oldV[k]) !== JSON.stringify(newV[k])).map((k) => ({ key: k, from: show(oldV[k]), to: show(newV[k]) }));
  }
  const src = (action === "DELETE" ? oldV : newV) ?? {};
  return Object.entries(src).filter(([k, v]) => !HIDDEN_KEYS.has(k) && v !== null && v !== "").map(([k, v]) => ({ key: k, to: show(v) }));
}

export default async function AuditPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("utilisateurs");
  const sp = await searchParams;
  const mod = firstParam(sp.module) && firstParam(sp.module)! in MODULES ? firstParam(sp.module) : undefined;
  const action = firstParam(sp.action) && firstParam(sp.action)! in ACTIONS ? firstParam(sp.action) : undefined;
  const user = sanitizeSearch(firstParam(sp.user));
  const dateOk = (v?: string) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);
  const from = dateOk(firstParam(sp.from));
  const to = dateOk(firstParam(sp.to));
  const page = parsePage(firstParam(sp.page));
  const { from: rf, to: rt } = pageRange(page);

  let query = (await createClient())
    .from("audit_logs")
    .select("id, user_email, action, module, record_id, old_value, new_value, created_at", { count: "exact" })
    .order("id", { ascending: false })
    .range(rf, rt);
  if (mod) query = query.eq("module", mod);
  if (action) query = query.eq("action", action);
  if (user) query = query.ilike("user_email", `%${user}%`);
  if (from) query = query.gte("created_at", haitiDayStartISO(from));
  if (to) query = query.lt("created_at", haitiDayStartISO(nextDay(to)));
  const { data, count } = await query;
  const rows = data ?? [];

  return (
    <div className="space-y-5">
      <PageHeader title="Journal d'audit" description={`${count ?? 0} événement${(count ?? 0) > 1 ? "s" : ""} — immuable : personne ne peut le modifier ni le supprimer`} back={{ href: "/utilisateurs", label: "Retour aux utilisateurs" }} />
      <form method="get" className="grid gap-3 rounded-xl border border-border bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-6 lg:items-end">
        <label className="text-xs text-muted-foreground">Module
          <Select name="module" defaultValue={mod ?? ""}><option value="">Tous</option>{Object.entries(MODULES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
        </label>
        <label className="text-xs text-muted-foreground">Action
          <Select name="action" defaultValue={action ?? ""}><option value="">Toutes</option>{Object.entries(ACTIONS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</Select>
        </label>
        <label className="text-xs text-muted-foreground">Utilisateur (e-mail)<Input name="user" defaultValue={user ?? ""} /></label>
        <label className="text-xs text-muted-foreground">Du<Input type="date" name="from" defaultValue={from} /></label>
        <label className="text-xs text-muted-foreground">Au<Input type="date" name="to" defaultValue={to} /></label>
        <Button type="submit">Filtrer</Button>
      </form>
      {rows.length === 0 ? <Empty>Aucun événement.</Empty> : (
        <ul className="space-y-2">
          {rows.map((r) => {
            const ch = changes(r.action, r.old_value as Json, r.new_value as Json);
            return (
              <li key={r.id} className="rounded-xl border border-border bg-white p-3 text-sm shadow-sm">
                <details>
                  <summary className="flex cursor-pointer flex-wrap items-center gap-x-3 gap-y-1">
                    <Badge tone={ACTIONS[r.action]?.tone ?? "slate"}>{ACTIONS[r.action]?.label ?? r.action}</Badge>
                    <span className="font-semibold">{MODULES[r.module] ?? r.module}</span>
                    <span className="text-muted-foreground">{r.user_email ?? "Système"}</span>
                    <span className="ml-auto whitespace-nowrap text-xs text-muted-foreground">{formatDateTime(r.created_at)}</span>
                  </summary>
                  <div className="mt-3 overflow-x-auto">
                    <p className="mb-2 text-xs text-muted-foreground">Enregistrement : <span className="font-mono">{r.record_id ?? "—"}</span></p>
                    <table className="w-full min-w-[420px] text-xs">
                      <thead className="text-left uppercase text-muted-foreground"><tr><th className="py-1 pr-3">Champ</th>{r.action === "UPDATE" && <th className="py-1 pr-3">Avant</th>}<th className="py-1">{r.action === "UPDATE" ? "Après" : "Valeur"}</th></tr></thead>
                      <tbody className="divide-y divide-border">
                        {ch.map((c) => (
                          <tr key={c.key}><td className="py-1 pr-3 font-mono">{c.key}</td>{r.action === "UPDATE" && <td className="py-1 pr-3 break-all text-destructive">{c.from}</td>}<td className="py-1 break-all">{c.to}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </details>
              </li>
            );
          })}
        </ul>
      )}
      <Pagination page={page} total={count ?? 0} basePath="/utilisateurs/journal" params={{ module: mod, action, user, from, to }} />
    </div>
  );
}
