import type { Metadata } from "next";
import { PageHeader } from "@/components/shared/page-header";
import { AccessMatrix, type MatrixRole } from "@/components/utilisateurs/access-matrix";
import { requireModule } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/labels";
import { NAV_ITEMS, ROLE_MODULES } from "@/lib/permissions";
import { createClient } from "@/lib/supabase/server";
import { ROLES } from "@/types";
import { setModuleAccess } from "../actions";

export const metadata: Metadata = { title: "Permissions" };
export const dynamic = "force-dynamic";

export default async function PermissionsPage() {
  await requireModule("utilisateurs");
  const { data } = await (await createClient()).from("users_roles").select("role, module, can_view");
  const view = new Map((data ?? []).map((r) => [`${r.role}:${r.module}`, r.can_view]));
  const roles: MatrixRole[] = ROLES.filter((r) => r !== "ADMIN").map((role) => ({
    role,
    label: ROLE_LABELS[role],
    modules: ROLE_MODULES[role].map((key) => ({
      key,
      label: NAV_ITEMS.find((i) => i.key === key)!.label,
      view: view.get(`${role}:${key}`) ?? true,
      locked: key === "dashboard",
    })),
  }));
  return (
    <div className="space-y-5">
      <PageHeader
        title="Permissions par rôle"
        description="Masquez un module pour un rôle. Les droits d'écriture restent protégés par la base de données : cette matrice ne peut que restreindre, jamais élargir."
        back={{ href: "/utilisateurs", label: "Retour aux utilisateurs" }}
      />
      <AccessMatrix roles={roles} save={setModuleAccess} />
    </div>
  );
}
