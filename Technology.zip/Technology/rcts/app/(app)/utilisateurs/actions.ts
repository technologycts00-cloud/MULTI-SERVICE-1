"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { NAV_ITEMS, ROLE_MODULES, type ModuleKey } from "@/lib/permissions";
import { createAdminClient } from "@/lib/supabase/admin";
import { createUserSchema, updateUserSchema } from "@/lib/validations/admin";
import { ROLES, type Role } from "@/types";

const idSchema = z.uuid();

/** Création d'un compte : seul le serveur (clé SERVICE_ROLE) peut le faire, après contrôle du rôle ADMIN. */
export async function createUser(raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  const p = createUserSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };

  let admin;
  try {
    admin = createAdminClient();
  } catch {
    return { ok: false, error: "La création de comptes n'est pas configurée sur le serveur (clé de service manquante)." };
  }
  const { data, error } = await admin.auth.admin.createUser({
    email: p.data.email,
    password: p.data.password,
    email_confirm: true,
    user_metadata: { full_name: p.data.full_name },
  });
  if (error || !data.user) {
    const dup = /already|registered|exists/i.test(error?.message ?? "");
    return { ok: false, error: dup ? "Cette adresse e-mail est déjà utilisée." : "Impossible de créer le compte pour le moment.", fieldErrors: dup ? { email: "Adresse déjà utilisée" } : undefined };
  }
  // Le profil naît en SECRETAIRE ; le rôle choisi est appliqué par la fonction réservée à l'ADMIN.
  const { error: roleError } = await auth.supabase.rpc("admin_update_user", {
    p_user: data.user.id, p_full_name: p.data.full_name, p_role: p.data.role, p_active: true,
  });
  if (roleError) {
    await admin.auth.admin.deleteUser(data.user.id); // pas de compte à moitié créé
    return { ok: false, error: dbErrorMessage(roleError) };
  }
  revalidatePath("/utilisateurs");
  return { ok: true, id: data.user.id };
}

export async function updateUser(id: string, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Utilisateur introuvable." };
  const p = updateUserSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  const { error } = await auth.supabase.rpc("admin_update_user", {
    p_user: id, p_full_name: p.data.full_name, p_role: p.data.role, p_active: p.data.is_active,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/utilisateurs");
  revalidatePath(`/utilisateurs/${id}`);
  return { ok: true, id };
}

/** Envoie un lien de réinitialisation du mot de passe à l'utilisateur (l'ADMIN ne voit jamais le mot de passe). */
export async function sendResetLink(id: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Utilisateur introuvable." };
  const { data } = await auth.supabase.from("profiles").select("email").eq("id", id).maybeSingle();
  if (!data?.email) return { ok: false, error: "Utilisateur introuvable." };
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const { error } = await auth.supabase.auth.resetPasswordForEmail(data.email, { redirectTo: `${site}/auth/callback?next=/reset-password` });
  if (error) return { ok: false, error: "Envoi impossible pour le moment. Réessayez plus tard." };
  return { ok: true };
}

/** Matrice de permissions : l'ADMIN peut seulement RETIRER l'accès d'un module à un rôle (plafond = RLS). */
export async function setModuleAccess(role: string, module: string, canView: boolean): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!(ROLES as readonly string[]).includes(role) || role === "ADMIN") return { ok: false, error: "Rôle non modifiable." };
  const key = module as ModuleKey;
  if (!NAV_ITEMS.some((i) => i.key === key) || !ROLE_MODULES[role as Role].includes(key)) return { ok: false, error: "Module hors des droits de ce rôle." };
  if (key === "dashboard") return { ok: false, error: "Le Dashboard reste toujours accessible." };
  const { error } = await auth.supabase
    .from("users_roles")
    .upsert({ role: role as Role, module, can_view: canView, can_create: canView, can_edit: canView, can_delete: false }, { onConflict: "role,module" });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/utilisateurs/permissions");
  return { ok: true };
}
