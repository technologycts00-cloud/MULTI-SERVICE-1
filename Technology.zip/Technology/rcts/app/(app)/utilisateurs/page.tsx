import type { Metadata } from "next";
import Link from "next/link";
import { History, Plus, ShieldCheck } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Utilisateurs" };
export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const me = await requireModule("utilisateurs");
  const { data } = await (await createClient()).from("profiles").select("id, full_name, email, role, is_active, created_at").order("created_at");
  const users = data ?? [];
  return (
    <div className="space-y-5">
      <PageHeader
        title="Utilisateurs"
        description={`${users.length} compte${users.length > 1 ? "s" : ""}`}
        actions={
          <>
            <Button asChild variant="outline"><Link href="/utilisateurs/journal"><History aria-hidden /> Journal d&apos;audit</Link></Button>
            <Button asChild variant="outline"><Link href="/utilisateurs/permissions"><ShieldCheck aria-hidden /> Permissions</Link></Button>
            <Button asChild><Link href="/utilisateurs/nouveau"><Plus aria-hidden /> Nouvel utilisateur</Link></Button>
          </>
        }
      />
      <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr><th className="px-4 py-3">Nom</th><th className="px-4 py-3">E-mail</th><th className="px-4 py-3">Rôle</th><th className="px-4 py-3">Statut</th></tr>
            </thead>
            <tbody className="divide-y divide-border">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-muted/50">
                  <td className="px-4 py-3 font-semibold"><Link href={`/utilisateurs/${u.id}`} className="hover:text-primary">{u.full_name ?? "—"}</Link>{u.id === me.id && <span className="ml-2 text-xs font-normal text-muted-foreground">(vous)</span>}</td>
                  <td className="px-4 py-3">{u.email}</td>
                  <td className="px-4 py-3">{ROLE_LABELS[u.role] ?? u.role}</td>
                  <td className="px-4 py-3"><Badge tone={u.is_active ? "green" : "red"}>{u.is_active ? "Actif" : "Désactivé"}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
