import type { Metadata } from "next";
import { PageHeader } from "@/components/shared/page-header";
import { CreateUserForm } from "@/components/utilisateurs/user-forms";
import { requireModule } from "@/lib/auth";
import { createUser } from "../actions";

export const metadata: Metadata = { title: "Nouvel utilisateur" };
export const dynamic = "force-dynamic";

export default async function NewUserPage() {
  await requireModule("utilisateurs");
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouvel utilisateur" back={{ href: "/utilisateurs", label: "Retour aux utilisateurs" }} />
      <CreateUserForm save={createUser} />
    </div>
  );
}
