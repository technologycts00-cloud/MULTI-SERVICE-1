import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { MailCheck } from "lucide-react";
import { ActionButton } from "@/components/shared/action-button";
import { PageHeader } from "@/components/shared/page-header";
import { EditUserForm } from "@/components/utilisateurs/user-forms";
import { requireModule } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import type { Role } from "@/types";
import { sendResetLink, updateUser } from "../actions";

export const metadata: Metadata = { title: "Utilisateur" };
export const dynamic = "force-dynamic";

export default async function EditUserPage({ params }: { params: Promise<{ id: string }> }) {
  const me = await requireModule("utilisateurs");
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const { data: u } = await (await createClient()).from("profiles").select("id, full_name, email, role, is_active").eq("id", id).maybeSingle();
  if (!u) notFound();
  const isSelf = u.id === me.id;
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title={u.full_name ?? u.email ?? "Utilisateur"} description={u.email ?? undefined} back={{ href: "/utilisateurs", label: "Retour aux utilisateurs" }} />
      <EditUserForm id={u.id} isSelf={isSelf} save={updateUser} defaults={{ full_name: u.full_name ?? "", role: u.role as Role, is_active: u.is_active ? "true" : "false" }} />
      <div className="rounded-xl border border-border bg-white p-4 shadow-sm">
        <h2 className="mb-1 font-bold">Mot de passe</h2>
        <p className="mb-3 text-sm text-muted-foreground">L&apos;utilisateur reçoit un lien par e-mail pour choisir un nouveau mot de passe.</p>
        <ActionButton action={sendResetLink.bind(null, u.id)} confirm={{ title: "Envoyer le lien ?", description: `Un e-mail de réinitialisation sera envoyé à ${u.email}.`, confirmLabel: "Envoyer" }}>
          <MailCheck aria-hidden /> Envoyer un lien de réinitialisation
        </ActionButton>
      </div>
    </div>
  );
}
