"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { money } from "@/lib/validations/common";
import { ENROLLMENT_STATUSES, enrollmentSchema } from "@/lib/validations/enrollment";
import { searchEnrollableStudents, type StudentOption } from "@/services/students";

const idSchema = z.uuid();
const WRITERS = ["ADMIN", "SECRETAIRE"] as const;

function refresh(enrollmentId?: string, studentId?: string, trainingId?: string) {
  revalidatePath("/inscriptions");
  if (enrollmentId) revalidatePath(`/inscriptions/${enrollmentId}`);
  if (studentId) revalidatePath(`/eleves/${studentId}`);
  if (trainingId) revalidatePath(`/formations/${trainingId}`);
  revalidatePath("/formations");
  revalidatePath("/dashboard");
}

/**
 * Processus complet : élève → formation → inscription → (paiement → reçu).
 * Tout se fait dans UNE transaction côté base (fonction enroll_student) : si une étape échoue,
 * rien n'est enregistré.
 */
export async function createEnrollment(
  raw: unknown,
): Promise<ActionResult<{ id: string; receipt_number: string | null }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;

  const parsed = enrollmentSchema.safeParse(raw);
  if (!parsed.success) {
    return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(parsed.error) };
  }
  const v = parsed.data;

  // Seule la Direction encaisse depuis ce formulaire ; le secrétariat inscrit, la caisse encaisse.
  if (v.amount_paid > 0 && auth.profile.role !== "ADMIN") {
    return { ok: false, error: "Le paiement d'une inscription est encaissé par la caisse (module Paiements)." };
  }

  const { data, error } = await auth.supabase.rpc("enroll_student", {
    p_student_id: v.student_id,
    p_training_id: v.training_id,
    p_discount: v.discount,
    p_amount_paid: v.amount_paid,
    p_method: v.method,
    p_reference: v.reference,
    p_notes: v.notes,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };

  const res = data as { enrollment_id: string; payment: { receipt_number?: string } | null };
  refresh(res.enrollment_id, v.student_id, v.training_id);
  return { ok: true, id: res.enrollment_id, receipt_number: res.payment?.receipt_number ?? null };
}

/** Terminer, abandonner, annuler ou réactiver. Les règles (paiements, certificat, capacité) sont dans la base. */
export async function setEnrollmentStatus(id: string, status: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Inscription introuvable." };
  const parsed = z.enum(ENROLLMENT_STATUSES).safeParse(status);
  if (!parsed.success) return { ok: false, error: "Statut invalide." };

  const { data, error } = await auth.supabase
    .from("enrollments")
    .update({ status: parsed.data })
    .eq("id", id)
    .select("student_id, training_id")
    .maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Inscription introuvable ou accès refusé." };
  refresh(id, data.student_id, data.training_id);
  return { ok: true };
}

/** Modification de la réduction : ADMIN uniquement (contrôlé aussi par un trigger en base). */
export async function updateEnrollmentDiscount(id: string, discountText: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Inscription introuvable." };

  const parsed = money("Réduction").safeParse(discountText);
  if (!parsed.success) return { ok: false, error: "Réduction invalide." };
  const discount = parsed.data;

  const { supabase } = auth;
  const { data: e } = await supabase
    .from("enrollments")
    .select("training_price, registration_fee, amount_paid, student_id, training_id")
    .eq("id", id)
    .maybeSingle();
  if (!e) return { ok: false, error: "Inscription introuvable ou accès refusé." };

  const max = Number(e.training_price) + Number(e.registration_fee) - Number(e.amount_paid);
  if (discount > max) {
    return {
      ok: false,
      error: `La réduction ne peut pas dépasser ${max.toLocaleString("fr-FR")} HTG (le total dû ne peut pas passer sous le montant déjà payé).`,
    };
  }

  const { error } = await supabase.from("enrollments").update({ discount }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id, e.student_id, e.training_id);
  return { ok: true };
}

export async function issueCertificate(id: string): Promise<ActionResult<{ certificate_number: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Inscription introuvable." };

  const { data, error } = await auth.supabase.rpc("issue_certificate", { p_enrollment_id: id });
  if (error) return { ok: false, error: dbErrorMessage(error) };

  const { data: e } = await auth.supabase.from("enrollments").select("student_id, training_id").eq("id", id).maybeSingle();
  refresh(id, e?.student_id, e?.training_id);
  return { ok: true, certificate_number: (data as { certificate_number: string }).certificate_number };
}

/** Recherche d'élèves pour le formulaire d'inscription (liste déroulante interactive). */
export async function searchStudentsAction(q: string): Promise<ActionResult<{ items: StudentOption[] }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (typeof q !== "string" || q.trim().length < 2) return { ok: true, items: [] };
  try {
    return { ok: true, items: await searchEnrollableStudents(auth.supabase, q.slice(0, 60)) };
  } catch {
    return { ok: false, error: "Recherche impossible pour le moment." };
  }
}

