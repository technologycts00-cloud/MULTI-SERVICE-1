import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { EnrollmentsTable } from "@/components/inscriptions/enrollments-table";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { requireRole } from "@/lib/auth";
import { ENROLLMENT_STATUS, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { listEnrollments } from "@/services/enrollments";
import { listOpenTrainings } from "@/services/trainings";

export const metadata: Metadata = { title: "Inscriptions" };
export const dynamic = "force-dynamic";

export default async function InscriptionsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireRole("ADMIN", "SECRETAIRE");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const rawStatus = firstParam(sp.status);
  const status = rawStatus && rawStatus in ENROLLMENT_STATUS ? rawStatus : undefined;
  const payment = firstParam(sp.payment) === "impaye" ? "impaye" : undefined;
  const rawTraining = firstParam(sp.training);
  const training = rawTraining && /^[0-9a-f-]{36}$/i.test(rawTraining) ? rawTraining : undefined;
  const page = parsePage(firstParam(sp.page));

  const supabase = await createClient();
  const [{ rows, total }, trainings] = await Promise.all([
    listEnrollments(supabase, { q, status, training, payment, page }),
    listOpenTrainings(supabase),
  ]);
  if (rows.length === 0 && page > 1) redirect("/inscriptions");

  return (
    <div className="space-y-5">
      <PageHeader
        title="Inscriptions"
        description={`${total} inscription${total > 1 ? "s" : ""}`}
        actions={<Button asChild><Link href="/inscriptions/nouvelle"><Plus aria-hidden /> Nouvelle inscription</Link></Button>}
      />
      <ListFilters
        basePath="/inscriptions"
        q={q}
        placeholder="Élève, ID étudiant ou N° d'inscription"
        selects={[
          { name: "status", label: "Statut", value: status, options: options(ENROLLMENT_STATUS), allLabel: "Tous les statuts" },
          { name: "training", label: "Formation", value: training, options: trainings.map((t) => ({ value: t.id, label: t.name })), allLabel: "Toutes les formations" },
          { name: "payment", label: "Paiement", value: payment, options: [{ value: "impaye", label: "Solde à payer" }], allLabel: "Tous paiements" },
        ]}
      />
      <EnrollmentsTable rows={rows} />
      <Pagination page={page} total={total} basePath="/inscriptions" params={{ q, status, training, payment }} />
    </div>
  );
}
