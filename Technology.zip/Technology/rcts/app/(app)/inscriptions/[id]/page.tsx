import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Award, Ban, CheckCircle2, LogOut, RotateCcw } from "lucide-react";
import { z } from "zod";
import { DiscountEditor } from "@/components/inscriptions/discount-editor";
import { EnrollmentDetailView } from "@/components/inscriptions/enrollment-detail";
import { ActionButton } from "@/components/shared/action-button";
import { PageHeader } from "@/components/shared/page-header";
import { requireModule } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getEnrollmentDetail } from "@/services/enrollments";
import { issueCertificate, setEnrollmentStatus, updateEnrollmentDiscount } from "../actions";

export const metadata: Metadata = { title: "Inscription" };
export const dynamic = "force-dynamic";

export default async function EnrollmentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();

  const profile = await requireModule("inscriptions");
  const isAdmin = profile.role === "ADMIN";
  const canWrite = isAdmin || profile.role === "SECRETAIRE";

  const detail = await getEnrollmentDetail(await createClient(), id, canWrite);
  if (!detail) notFound();
  const { enrollment: e, certificate } = detail;
  const paid = Number(e.amount_paid) > 0;
  const balance = Number(e.balance ?? 0);

  return (
    <div className="space-y-5">
      <PageHeader title="Inscription" back={{ href: "/inscriptions", label: "Retour aux inscriptions" }} />
      <EnrollmentDetailView
        detail={detail}
        discountControl={
          isAdmin && e.status !== "ANNULEE" ? (
            <DiscountEditor current={Number(e.discount)} save={updateEnrollmentDiscount.bind(null, id)} />
          ) : undefined
        }
        actions={
          canWrite && (
            <>
              {e.status === "ACTIVE" && (
                <>
                  <ActionButton
                    size="default"
                    variant="success"
                    action={setEnrollmentStatus.bind(null, id, "TERMINEE")}
                    confirm={{
                      title: "Marquer la formation comme terminée ?",
                      description: "L'élève a terminé cette formation. Un certificat pourra ensuite être délivré une fois le solde réglé.",
                      confirmLabel: "Terminée",
                    }}
                  >
                    <CheckCircle2 aria-hidden /> Marquer terminée
                  </ActionButton>
                  <ActionButton
                    size="default"
                    action={setEnrollmentStatus.bind(null, id, "ABANDONNEE")}
                    confirm={{
                      title: "Enregistrer un abandon ?",
                      description: "L'inscription est conservée avec son historique de paiements, et la place est libérée. Vous pourrez la réactiver si une place reste disponible.",
                      confirmLabel: "Abandon",
                    }}
                  >
                    <LogOut aria-hidden /> Abandon
                  </ActionButton>
                </>
              )}
              {e.status === "ABANDONNEE" && (
                <ActionButton size="default" action={setEnrollmentStatus.bind(null, id, "ACTIVE")}>
                  <RotateCcw aria-hidden /> Réactiver
                </ActionButton>
              )}
              {e.status === "TERMINEE" && !certificate && balance <= 0 && (
                <ActionButton size="default" variant="default" action={issueCertificate.bind(null, id)}>
                  <Award aria-hidden /> Délivrer le certificat
                </ActionButton>
              )}
              {(e.status === "ACTIVE" || e.status === "ABANDONNEE") &&
                (paid ? (
                  <p className="text-xs text-muted-foreground">
                    Cette inscription a des paiements : pour l&apos;annuler, la Direction doit d&apos;abord annuler les paiements.
                  </p>
                ) : (
                  <ActionButton
                    size="default"
                    variant="destructive"
                    action={setEnrollmentStatus.bind(null, id, "ANNULEE")}
                    confirm={{
                      title: "Annuler cette inscription ?",
                      description: "Une inscription annulée est définitive : il faudra créer une nouvelle inscription pour réinscrire l'élève.",
                      confirmLabel: "Annuler l'inscription",
                    }}
                  >
                    <Ban aria-hidden /> Annuler l&apos;inscription
                  </ActionButton>
                ))}
            </>
          )
        }
      />
    </div>
  );
}

