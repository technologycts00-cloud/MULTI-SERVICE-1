import type { Metadata } from "next";
import Link from "next/link";
import { z } from "zod";
import { EnrollmentForm } from "@/components/inscriptions/enrollment-form";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { requireRole } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { getStudentOption } from "@/services/students";
import { listOpenTrainings } from "@/services/trainings";
import { createEnrollment, searchStudentsAction } from "../actions";

export const metadata: Metadata = { title: "Nouvelle inscription" };
export const dynamic = "force-dynamic";

export default async function NewEnrollmentPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const profile = await requireRole("ADMIN", "SECRETAIRE");
  const sp = await searchParams;
  const supabase = await createClient();

  const trainings = await listOpenTrainings(supabase);

  const studentParam = firstParam(sp.student);
  const initialStudent =
    studentParam && z.uuid().safeParse(studentParam).success ? await getStudentOption(supabase, studentParam) : null;
  const trainingParam = firstParam(sp.training);
  const initialTrainingId = trainings.some((t) => t.id === trainingParam && t.places_left !== 0) ? (trainingParam as string) : "";

  return (
    <div className="max-w-5xl space-y-5">
      <PageHeader
        title="Nouvelle inscription"
        description="Élève → formation → inscription → paiement → reçu"
        back={{ href: "/inscriptions", label: "Retour aux inscriptions" }}
      />
      {trainings.length === 0 ? (
        <div className="space-y-3 rounded-xl border border-dashed border-border bg-white p-8 text-center">
          <p className="text-sm text-muted-foreground">
            Aucune formation n&apos;accepte d&apos;inscriptions pour le moment (il faut une formation planifiée ou en cours).
          </p>
          <Button asChild>
            <Link href="/formations/nouvelle">Créer une formation</Link>
          </Button>
        </div>
      ) : (
        <EnrollmentForm
          trainings={trainings}
          initialStudent={initialStudent}
          initialTrainingId={initialTrainingId}
          canCollect={profile.role === "ADMIN"}
          save={createEnrollment}
          search={searchStudentsAction}
        />
      )}
    </div>
  );
}

