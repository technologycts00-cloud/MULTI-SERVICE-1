import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Receipt } from "lucide-react";
import { z } from "zod";
import { PageHeader } from "@/components/shared/page-header";
import { InvoiceButton } from "@/components/documents/invoice-button";
import { VoidWithReason } from "@/components/shared/void-with-reason";
import { StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS, PAYMENT_STATUS, RECORD_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import { getSaleDetail } from "@/services/sales";
import { voidSaleAction } from "../actions";

export const metadata: Metadata = { title: "Vente" };
export const dynamic = "force-dynamic";

export default async function SalePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const profile = await requireModule("ventes");
  const d = await getSaleDetail(await createClient(), id);
  if (!d) notFound();
  const { sale: s, items, payments } = d;

  return (
    <div className="space-y-5">
      <PageHeader title={`Vente ${s.sale_number}`} back={{ href: "/ventes", label: "Retour aux ventes" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge map={RECORD_STATUS} value={s.status} />
            <StatusBadge map={PAYMENT_STATUS} value={s.payment_status} />
            <span className="text-sm text-muted-foreground">{formatDateTime(s.sale_date)}</span>
          </div>
          <dl className="grid gap-4 text-sm sm:grid-cols-3">
            <div><dt className="text-xs text-muted-foreground">Client</dt><dd className="font-semibold">{s.customers?.name ?? "Client comptoir"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Vendeur</dt><dd className="font-semibold">{s.seller_name ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Mode de paiement</dt><dd className="font-semibold">{METHOD_LABELS[s.payment_method] ?? s.payment_method}</dd></div>
          </dl>
          {s.void_reason && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">Vente annulée : {s.void_reason}</p>}
          <div className="flex flex-wrap items-center gap-2">
            {s.status === "VALIDE" && <InvoiceButton kind="VENTE" targetId={id} />}
            {profile.role === "ADMIN" && s.status === "VALIDE" && (
              <VoidWithReason action={voidSaleAction.bind(null, id)} title="Annuler cette vente ?" description="Les paiements sont annulés, le stock est réintégré et la caisse corrigée. La vente reste visible dans l'historique." label="Annuler la vente" />
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-5 lg:grid-cols-[1fr_20rem]">
        <Card>
          <CardHeader><CardTitle>Articles</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[420px] text-sm">
                <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">Article</th><th className="px-4 py-3 text-right">Qté</th><th className="px-4 py-3 text-right">P.U.</th><th className="px-4 py-3 text-right">Sous-total</th></tr></thead>
                <tbody className="divide-y divide-border">
                  {items.map((i) => (
                    <tr key={i.id}><td className="px-4 py-3">{i.description}</td><td className="px-4 py-3 text-right tabular-nums">{i.quantity}</td><td className="px-4 py-3 text-right tabular-nums">{formatHTG(i.unit_price)}</td><td className="px-4 py-3 text-right font-semibold tabular-nums">{formatHTG(i.line_total)}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
        <Card className="h-fit">
          <CardHeader><CardTitle>Montants</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Sous-total</span><span className="tabular-nums">{formatHTG(s.subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Réduction</span><span className="tabular-nums">− {formatHTG(s.discount)}</span></div>
            <div className="flex justify-between font-bold"><span>Total</span><span className="tabular-nums">{formatHTG(s.total)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Payé</span><span className="tabular-nums text-success">{formatHTG(s.amount_paid)}</span></div>
            <div className={cn("flex justify-between font-bold", s.balance > 0 && s.status === "VALIDE" ? "text-destructive" : "")}><span>Solde</span><span className="tabular-nums">{formatHTG(s.balance)}</span></div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Paiements</CardTitle></CardHeader>
        <CardContent>
          {payments.length === 0 ? <p className="text-sm text-muted-foreground">Aucun paiement.</p> : (
            <ul className="divide-y divide-border">
              {payments.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
                  <span><span className="font-semibold tabular-nums">{formatHTG(p.amount)}</span> · {METHOD_LABELS[p.method] ?? p.method} · <span className="text-muted-foreground">{formatDateTime(p.paid_at)}</span></span>
                  <span className="flex items-center gap-3">
                    {p.status === "ANNULE" && <StatusBadge map={RECORD_STATUS} value="ANNULE" />}
                    {p.receipt_id && <Link href={`/recus/${p.receipt_id}`} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"><Receipt className="size-3.5" aria-hidden />{p.receipt_number}</Link>}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
