import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ShoppingCart } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS, PAYMENT_STATUS, RECORD_STATUS, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import { listSales } from "@/services/sales";

export const metadata: Metadata = { title: "Ventes" };
export const dynamic = "force-dynamic";
const dateOnly = (v: string | undefined) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);

export default async function VentesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("ventes");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const status = firstParam(sp.status) && firstParam(sp.status)! in RECORD_STATUS ? firstParam(sp.status) : undefined;
  const payment = ["PAYEE", "PARTIELLE", "IMPAYEE"].includes(firstParam(sp.payment) ?? "") ? firstParam(sp.payment) : undefined;
  const from = dateOnly(firstParam(sp.from));
  const to = dateOnly(firstParam(sp.to));
  const page = parsePage(firstParam(sp.page));

  const { rows, total } = await listSales(await createClient(), { q, status, payment, from, to, page });
  if (rows.length === 0 && page > 1) redirect("/ventes");

  return (
    <div className="space-y-5">
      <PageHeader title="Ventes" description={`${total} vente${total > 1 ? "s" : ""}`} actions={<Button asChild><Link href="/caisse"><ShoppingCart aria-hidden /> Nouvelle vente (caisse)</Link></Button>} />
      <form method="get" action="/ventes" className="grid gap-3 rounded-xl border border-border bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
        <Input name="q" defaultValue={q ?? ""} placeholder="N° de vente" aria-label="Rechercher" className="sm:col-span-2" />
        <Select name="status" defaultValue={status ?? ""} aria-label="Statut"><option value="">Tous statuts</option>{options(RECORD_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
        <Select name="payment" defaultValue={payment ?? ""} aria-label="Paiement"><option value="">Tous paiements</option>{["PAYEE", "PARTIELLE", "IMPAYEE"].map((v) => <option key={v} value={v}>{PAYMENT_STATUS[v].label}</option>)}</Select>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">Du <Input type="date" name="from" defaultValue={from ?? ""} className="h-9" /></label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">Au <Input type="date" name="to" defaultValue={to ?? ""} className="h-9" /></label>
        <div className="flex gap-2 lg:col-span-6"><Button type="submit">Filtrer</Button><Button asChild variant="outline"><Link href="/ventes">Effacer</Link></Button></div>
      </form>
      {rows.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucune vente trouvée.</div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">N°</th><th className="px-4 py-3">Date</th><th className="px-4 py-3">Client</th><th className="px-4 py-3 text-right">Total</th><th className="px-4 py-3 text-right">Payé</th><th className="px-4 py-3 text-right">Solde</th><th className="px-4 py-3">Mode</th><th className="px-4 py-3">Paiement</th><th className="px-4 py-3">Statut</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((s) => (
                  <tr key={s.id} className={cn("hover:bg-muted/50", s.status === "ANNULE" && "text-muted-foreground")}>
                    <td className="px-4 py-3"><Link href={`/ventes/${s.id}`} className="font-mono text-xs font-semibold hover:text-primary">{s.sale_number}</Link></td>
                    <td className="whitespace-nowrap px-4 py-3">{formatDateTime(s.sale_date)}</td>
                    <td className="px-4 py-3">{s.customers?.name ?? "Client comptoir"}</td>
                    <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", s.status === "ANNULE" && "line-through")}>{formatHTG(s.total)}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{formatHTG(s.amount_paid)}</td>
                    <td className={cn("px-4 py-3 text-right tabular-nums", s.balance > 0 && s.status === "VALIDE" && "font-semibold text-destructive")}>{formatHTG(s.balance)}</td>
                    <td className="px-4 py-3">{METHOD_LABELS[s.payment_method] ?? s.payment_method}</td>
                    <td className="px-4 py-3"><StatusBadge map={PAYMENT_STATUS} value={s.payment_status} /></td>
                    <td className="px-4 py-3"><StatusBadge map={RECORD_STATUS} value={s.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} basePath="/ventes" params={{ q, status, payment, from, to }} />
    </div>
  );
}
