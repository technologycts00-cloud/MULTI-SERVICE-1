"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, type ActionResult } from "@/lib/action-result";

/** Annulation d'une vente (ADMIN) : paiements annulés, stock réintégré, caisse corrigée — en une transaction. */
export async function voidSaleAction(id: string, reason: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!z.uuid().safeParse(id).success) return { ok: false, error: "Vente introuvable." };
  const r = reason?.trim() ?? "";
  if (r.length < 3) return { ok: false, error: "Indiquez le motif de l'annulation." };
  if (r.length > 300) return { ok: false, error: "Motif trop long (300 caractères maximum)." };
  const { error } = await auth.supabase.rpc("void_sale", { p_sale_id: id, p_reason: r });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  for (const p of ["/ventes", `/ventes/${id}`, "/caisse", "/caisse/journal", "/stock", "/produits", "/paiements", "/dashboard", "/finances"]) revalidatePath(p);
  return { ok: true };
}
