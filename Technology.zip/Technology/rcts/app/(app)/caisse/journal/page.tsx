import type { Metadata } from "next";
import { ArrowDownCircle, ArrowUpCircle, Scale } from "lucide-react";
import { CashFilters, parseCashParams } from "@/components/caisse/cash-filters";
import { CashTable } from "@/components/caisse/cash-table";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { requireModule } from "@/lib/auth";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listCash } from "@/services/payments";

export const metadata: Metadata = { title: "Journal de caisse" };
export const dynamic = "force-dynamic";

export default async function JournalPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("caisse");
  const sp = await searchParams;
  const p = parseCashParams((k) => firstParam(sp[k]));
  const page = parsePage(firstParam(sp.page));
  const { rows, total, sumIn, sumOut } = await listCash(await createClient(), { ...p, page });

  return (
    <div className="space-y-5">
      <PageHeader title="Journal de caisse" description={`${total} opération${total > 1 ? "s" : ""} — les opérations annulées restent visibles`} back={{ href: "/caisse", label: "Retour à la caisse" }} />
      <div className="grid gap-3 sm:grid-cols-3">
        <KpiCard label="Entrées (sélection)" value={formatHTG(sumIn)} tone="green" icon={ArrowDownCircle} />
        <KpiCard label="Sorties (sélection)" value={formatHTG(sumOut)} tone="red" icon={ArrowUpCircle} />
        <KpiCard label="Solde (sélection)" value={formatHTG(sumIn - sumOut)} tone={sumIn - sumOut >= 0 ? "blue" : "red"} icon={Scale} />
      </div>
      <CashFilters basePath="/caisse/journal" p={p} />
      <CashTable rows={rows} />
      <Pagination page={page} total={total} basePath="/caisse/journal" params={{ ...p }} />
    </div>
  );
}
