"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { PAYMENT_METHODS, money, optionalText, optionalUuid } from "@/lib/validations/common";
import { posCatalog, searchCustomers, type CatalogItem, type CustomerOption } from "@/services/payments";

const WRITERS = ["ADMIN", "CAISSIER"] as const;

export async function searchCatalogAction(q: string): Promise<ActionResult<{ items: CatalogItem[] }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  try {
    return { ok: true, items: await posCatalog(auth.supabase, String(q ?? "").slice(0, 60)) };
  } catch {
    return { ok: false, error: "Recherche impossible pour le moment." };
  }
}

export async function searchCustomersAction(q: string): Promise<ActionResult<{ items: CustomerOption[] }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (typeof q !== "string" || q.trim().length < 2) return { ok: true, items: [] };
  try {
    return { ok: true, items: await searchCustomers(auth.supabase, q.slice(0, 60)) };
  } catch {
    return { ok: false, error: "Recherche impossible pour le moment." };
  }
}

const saleSchema = z.object({
  customer_id: optionalUuid,
  items: z
    .array(
      z.object({
        type: z.enum(["product", "service"]),
        id: z.uuid(),
        quantity: z.number().int().min(1).max(100000),
        // Le prix des produits vient TOUJOURS de la base ; seul un service peut avoir un prix saisi.
        unit_price: z.number().min(0).max(999999999).optional(),
      }),
    )
    .min(1, "Le panier est vide")
    .max(100),
  discount: money("Réduction"),
  amount_tendered: money("Montant payé"),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
  notes: optionalText(300),
});

export interface SaleResult {
  sale_id: string;
  sale_number: string;
  total: number;
  change: number;
  balance: number;
  receipt_id: string | null;
  receipt_number: string | null;
}

/** Enregistre la vente : vente + lignes + stock + paiement + caisse + reçu, en UNE transaction. */
export async function createSaleAction(raw: unknown): Promise<ActionResult<SaleResult>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const parsed = saleSchema.safeParse(raw);
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message ?? "Vente invalide.", fieldErrors: zodFieldErrors(parsed.error) };
  }
  const v = parsed.data;
  const items = v.items.map((i) =>
    i.type === "product"
      ? { product_id: i.id, quantity: i.quantity }
      : { service_id: i.id, quantity: i.quantity, ...(i.unit_price !== undefined ? { unit_price: i.unit_price } : {}) },
  );

  const { data, error } = await auth.supabase.rpc("create_sale", {
    p_customer_id: v.customer_id,
    p_items: items,
    p_discount: v.discount,
    p_amount_tendered: v.amount_tendered,
    p_method: v.method,
    p_reference: v.reference,
    p_notes: v.notes,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };

  const r = data as {
    sale_id: string;
    sale_number: string;
    total: number;
    change: number;
    balance: number;
    payment: { receipt_id?: string; receipt_number?: string } | null;
  };
  for (const p of ["/caisse", "/caisse/journal", "/dashboard", "/ventes", "/stock", "/produits", "/paiements", "/finances"]) revalidatePath(p);
  return {
    ok: true,
    sale_id: r.sale_id,
    sale_number: r.sale_number,
    total: Number(r.total),
    change: Number(r.change),
    balance: Number(r.balance),
    receipt_id: r.payment?.receipt_id ?? null,
    receipt_number: r.payment?.receipt_number ?? null,
  };
}
