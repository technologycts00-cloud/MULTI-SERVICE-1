import type { Metadata } from "next";
import Link from "next/link";
import { ArrowDownCircle, ArrowUpCircle, BookOpen, Receipt, Wallet } from "lucide-react";
import { Pos } from "@/components/caisse/pos";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";
import { createClient } from "@/lib/supabase/server";
import { cashOverview, posCatalog } from "@/services/payments";
import { createSaleAction, searchCatalogAction, searchCustomersAction } from "./actions";

export const metadata: Metadata = { title: "Caisse" };
export const dynamic = "force-dynamic";

export default async function CaissePage() {
  await requireModule("caisse");
  const supabase = await createClient();
  const [overview, catalog] = await Promise.all([cashOverview(supabase), posCatalog(supabase)]);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Caisse"
        description="Vente au comptoir : produits, services, reçu immédiat"
        actions={<Button asChild variant="outline"><Link href="/caisse/journal"><BookOpen aria-hidden /> Journal de caisse</Link></Button>}
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard label="Espèces en caisse" value={formatHTG(overview.cash_on_hand)} tone="blue" icon={Wallet} />
        <KpiCard label="Entrées du jour" value={formatHTG(overview.today_in)} tone="green" icon={ArrowDownCircle} />
        <KpiCard label="Sorties du jour" value={formatHTG(overview.today_out)} tone="red" icon={ArrowUpCircle} />
        <KpiCard label="Ventes du jour" value={String(overview.today_sales)} tone="blue" icon={Receipt} hint={overview.by_method.map((m) => `${METHOD_LABELS[m.method] ?? m.method} ${formatHTG(m.total)}`).join(" · ") || undefined} />
      </div>
      <Pos initialCatalog={catalog} searchCatalog={searchCatalogAction} searchCustomers={searchCustomersAction} save={createSaleAction} />
    </div>
  );
}
