import type { Metadata } from "next";
import Link from "next/link";
import { Calculator, FileSpreadsheet, FileText, Sheet } from "lucide-react";
import { PrintButton } from "@/components/rapports/print-button";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { Empty } from "@/components/shared/empty";
import { PageHeader } from "@/components/shared/page-header";
import { PeriodFilter } from "@/components/shared/period-filter";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { resolvePeriod } from "@/lib/period";
import { REPORT_TYPES, fetchReport, formatCell, isReportKey, periodLabel, reportsForRole } from "@/lib/reports";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { cn } from "@/lib/utils";

export const metadata: Metadata = { title: "Rapports" };
export const dynamic = "force-dynamic";

export default async function ReportsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("rapports");
  const sp = await searchParams;
  const allowed = reportsForRole(profile.role);
  const asked = firstParam(sp.type);
  const type = isReportKey(asked) && allowed.some((r) => r.key === asked) ? asked : allowed[0]?.key;
  const period = resolvePeriod((k) => firstParam(sp[k]));
  const all = firstParam(sp.periode) === "all";
  const from = all ? undefined : period.from;
  const to = all ? undefined : period.to;

  if (!type) return <Empty>Aucun rapport n&apos;est disponible pour votre rôle.</Empty>;
  const report = await fetchReport(await createClient(), type, from, to);
  const qs = new URLSearchParams({ type, ...(from ? { from } : {}), ...(to ? { to } : {}) });

  return (
    <div className="space-y-5">
      <PageHeader
        title="Rapports"
        description={`${report.title} — ${periodLabel(report.period)}`}
        actions={
          <div className="no-print flex flex-wrap gap-2">
            <PrintButton />
            <Button asChild variant="outline"><a href={`/rapports/export?${qs}&format=pdf`}><FileText aria-hidden /> PDF</a></Button>
            <Button asChild variant="outline"><a href={`/rapports/export?${qs}&format=xlsx`}><FileSpreadsheet aria-hidden /> Excel</a></Button>
            <Button asChild variant="outline"><a href={`/rapports/export?${qs}&format=csv`}><Sheet aria-hidden /> CSV</a></Button>
          </div>
        }
      />
      <div className="no-print flex flex-wrap gap-2" role="tablist" aria-label="Type de rapport">
        {REPORT_TYPES.filter((r) => allowed.some((a) => a.key === r.key)).map((r) => (
          <Link
            key={r.key}
            role="tab"
            aria-selected={r.key === type}
            href={`/rapports?${new URLSearchParams({ type: r.key, ...(all ? { periode: "all" } : { periode: period.preset, from: period.from, to: period.to }) })}`}
            className={cn("rounded-lg border px-3 py-2 text-sm font-semibold", r.key === type ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:bg-muted")}
          >
            {r.label}
          </Link>
        ))}
      </div>
      <PeriodFilter basePath="/rapports" period={period} extra={{ type }} />
      <div className="no-print">
        <Link href={`/rapports?type=${type}&periode=all`} className={cn("text-sm text-primary hover:underline", all && "font-bold")}>Toutes les périodes</Link>
      </div>

      <div className="print-area space-y-4">
        <div className="hidden print:block">
          <h2 className="text-lg font-black">R.CTS — R.COMPLEX TECHNOLOGY SERVICES</h2>
          <p className="text-sm">{report.title} · {periodLabel(report.period)}</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {report.summary.map((s) => (
            <KpiCard key={s.label} label={s.label} value={formatCell(s.value, s.type)} tone="blue" icon={Calculator} />
          ))}
        </div>
        {report.truncated && (
          <p className="rounded-lg border border-yellow-300 bg-yellow-50 p-3 text-sm">Seules les 5 000 premières lignes sont affichées et exportées ; le résumé porte sur toute la période. Réduisez la période pour tout voir.</p>
        )}
        {report.rows.length === 0 ? (
          <Empty>Aucune donnée sur cette période.</Empty>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-border bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead className="bg-muted text-left text-xs uppercase text-muted-foreground">
                <tr>
                  {report.columns.map((c) => (
                    <th key={c.key} scope="col" className={cn("px-3 py-2 font-semibold", (c.type === "money" || c.type === "int") && "text-right")}>{c.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {report.rows.map((row, i) => (
                  <tr key={i}>
                    {report.columns.map((c) => (
                      <td key={c.key} className={cn("px-3 py-2", (c.type === "money" || c.type === "int") && "text-right tabular-nums", c.type === "datetime" && "whitespace-nowrap")}>
                        {formatCell(row[c.key], c.type)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
