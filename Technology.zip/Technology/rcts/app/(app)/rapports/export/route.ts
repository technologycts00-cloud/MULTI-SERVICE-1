import { NextResponse, type NextRequest } from "next/server";
import { buildReportPdf, buildReportXlsx } from "@/lib/report-files";
import { buildCsv, fetchReport, isReportKey, reportsForRole } from "@/lib/reports";
import { createClient } from "@/lib/supabase/server";
import type { OrgInfo } from "@/services/documents";
import type { Role } from "@/types";

export const dynamic = "force-dynamic";

const DATE = /^\d{4}-\d{2}-\d{2}$/;

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const type = sp.get("type");
  const format = sp.get("format");
  const from = sp.get("from") ?? undefined;
  const to = sp.get("to") ?? undefined;
  if (!isReportKey(type) || !["pdf", "xlsx", "csv"].includes(format ?? "")) return new NextResponse("Requête invalide", { status: 400 });
  if ((from && !DATE.test(from)) || (to && !DATE.test(to))) return new NextResponse("Dates invalides", { status: 400 });

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new NextResponse("Non autorisé", { status: 401 });
  const { data: profile } = await supabase.from("profiles").select("full_name, email, role, is_active").eq("id", user.id).single();
  if (!profile?.is_active || !reportsForRole(profile.role as Role).some((r) => r.key === type)) return new NextResponse("Accès refusé", { status: 403 });

  let report;
  try {
    report = await fetchReport(supabase, type, from, to);
  } catch (e) {
    return new NextResponse((e as Error).message, { status: 400 });
  }
  const { data: s } = await supabase.from("settings").select("key, value").in("key", ["org_name", "org_legal_name", "phone", "email", "address"]);
  const org: OrgInfo = Object.fromEntries((s ?? []).map((x) => [x.key, x.value as string]));
  const by = profile.full_name ?? profile.email ?? "—";
  const name = `rapport-${type}-${from ?? "debut"}_${to ?? "fin"}`;
  const noStore = { "Cache-Control": "private, no-store" };

  if (format === "csv") {
    return new NextResponse(buildCsv(report), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${name}.csv"`, ...noStore } });
  }
  if (format === "xlsx") {
    const buf = await buildReportXlsx(report, org, by);
    return new NextResponse(new Uint8Array(buf), { headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Content-Disposition": `attachment; filename="${name}.xlsx"`, ...noStore } });
  }
  return new NextResponse(buildReportPdf(report, org, by), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="${name}.pdf"`, ...noStore } });
}
