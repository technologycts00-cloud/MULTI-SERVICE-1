import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { Empty } from "@/components/shared/empty";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { CUSTOMER_TYPE, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { listCustomers } from "@/services/parties";

export const metadata: Metadata = { title: "Clients" };
export const dynamic = "force-dynamic";

export default async function ClientsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("clients");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const type = firstParam(sp.type) && firstParam(sp.type)! in CUSTOMER_TYPE ? firstParam(sp.type) : undefined;
  const archived = firstParam(sp.archives) === "1";
  const debt = firstParam(sp.debt) === "1";
  const page = parsePage(firstParam(sp.page));
  const { rows, total } = await listCustomers(await createClient(), { q, type, archived, debt, page });
  if (rows.length === 0 && page > 1) redirect("/clients");

  return (
    <div className="space-y-5">
      <PageHeader
        title={archived ? "Clients archivés" : "Clients"}
        description={`${total} client${total > 1 ? "s" : ""}`}
        actions={<Button asChild><Link href="/clients/nouveau"><Plus aria-hidden /> Nouveau client</Link></Button>}
      />
      <ListFilters
        basePath="/clients"
        q={q}
        placeholder="Nom, téléphone ou e-mail"
        selects={[
          { name: "type", label: "Type", value: type, options: options(CUSTOMER_TYPE), allLabel: "Tous types" },
          { name: "debt", label: "Solde", value: debt ? "1" : undefined, options: [{ value: "1", label: "Avec solde à payer" }], allLabel: "Tous soldes" },
        ]}
        archivedToggle={{ checked: archived, label: "Voir les archivés" }}
      />
      {rows.length === 0 ? <Empty>Aucun client trouvé.</Empty> : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">Client</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Téléphone</th><th className="px-4 py-3 text-right">Total achats</th><th className="px-4 py-3 text-right">Solde dû</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((c) => (
                  <tr key={c.id} className="hover:bg-muted/50">
                    <td className="px-4 py-3 font-semibold"><Link href={`/clients/${c.id}`} className="hover:text-primary">{c.name}</Link></td>
                    <td className="px-4 py-3"><StatusBadge map={CUSTOMER_TYPE} value={c.customer_type} /></td>
                    <td className="px-4 py-3">{c.phone ?? "—"}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{formatHTG(c.total)}</td>
                    <td className={`px-4 py-3 text-right tabular-nums ${c.balance > 0 ? "font-semibold text-destructive" : ""}`}>{formatHTG(c.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} basePath="/clients" params={{ q, type, debt: debt ? "1" : undefined, archives: archived ? "1" : undefined }} />
    </div>
  );
}
