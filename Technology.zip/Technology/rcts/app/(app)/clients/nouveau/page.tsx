import type { Metadata } from "next";
import { CustomerForm } from "@/components/clients/customer-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireModule } from "@/lib/auth";
import { saveCustomer } from "../actions";

export const metadata: Metadata = { title: "Nouveau client" };
export const dynamic = "force-dynamic";

export default async function NewCustomerPage() {
  await requireModule("clients");
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouveau client" back={{ href: "/clients", label: "Retour aux clients" }} />
      <CustomerForm id={null} save={saveCustomer} defaults={{ name: "", phone: "", email: "", address: "", customer_type: "PARTICULIER", notes: "" }} />
    </div>
  );
}
