import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { CustomerForm } from "@/components/clients/customer-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireModule } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getCustomer } from "@/services/parties";
import { saveCustomer } from "../../actions";

export const metadata: Metadata = { title: "Modifier le client" };
export const dynamic = "force-dynamic";

export default async function EditCustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireModule("clients");
  const d = await getCustomer(await createClient(), id);
  if (!d) notFound();
  const c = d.customer;
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier le client" back={{ href: `/clients/${id}`, label: "Retour au client" }} />
      <CustomerForm
        id={id}
        save={saveCustomer}
        defaults={{ name: c.name, phone: c.phone ?? "", email: c.email ?? "", address: c.address ?? "", customer_type: c.customer_type as "PARTICULIER", notes: c.notes ?? "" }}
      />
    </div>
  );
}
