import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Archive, ArchiveRestore, Pencil, Plus } from "lucide-react";
import { z } from "zod";
import { ActionButton } from "@/components/shared/action-button";
import { Stat } from "@/components/shared/empty";
import { PageHeader } from "@/components/shared/page-header";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { CUSTOMER_TYPE, RECORD_STATUS, SERVICE_ORDER_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, formatHTG } from "@/lib/utils";
import { formatDate } from "@/lib/labels";
import { getCustomer } from "@/services/parties";
import { setCustomerArchived } from "../actions";

export const metadata: Metadata = { title: "Client" };
export const dynamic = "force-dynamic";

export default async function CustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireModule("clients");
  const d = await getCustomer(await createClient(), id);
  if (!d) notFound();
  const { customer: c, totals, sales, orders } = d;

  return (
    <div className="space-y-5">
      <PageHeader title="Client" back={{ href: "/clients", label: "Retour aux clients" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black">{c.name}</h2>
            <StatusBadge map={CUSTOMER_TYPE} value={c.customer_type} />
            {c.is_archived && <Badge>Archivé</Badge>}
          </div>
          <dl className="grid gap-4 text-sm sm:grid-cols-3">
            <div><dt className="text-xs text-muted-foreground">Téléphone</dt><dd className="font-semibold">{c.phone ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">E-mail</dt><dd className="font-semibold">{c.email ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Adresse</dt><dd className="font-semibold">{c.address ?? "—"}</dd></div>
          </dl>
          {c.notes && <p className="text-sm text-muted-foreground">{c.notes}</p>}
          <div className="flex flex-wrap items-center gap-2">
            <Button asChild><Link href={`/services/commandes/nouvelle?client=${id}`}><Plus aria-hidden /> Commande de service</Link></Button>
            <Button asChild variant="outline"><Link href={`/clients/${id}/modifier`}><Pencil aria-hidden /> Modifier</Link></Button>
            {c.is_archived ? (
              <ActionButton size="default" action={setCustomerArchived.bind(null, id, false)}><ArchiveRestore aria-hidden /> Restaurer</ActionButton>
            ) : (
              <ActionButton size="default" action={setCustomerArchived.bind(null, id, true)} confirm={{ title: "Archiver ce client ?", description: "Il n'apparaîtra plus dans les listes de sélection. Son historique est conservé.", confirmLabel: "Archiver" }}><Archive aria-hidden /> Archiver</ActionButton>
            )}
          </div>
        </CardContent>
      </Card>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Total des achats et services" value={formatHTG(totals.total)} />
        <Stat label="Total payé" value={formatHTG(totals.paid)} tone="green" />
        <Stat label="Solde à payer" value={formatHTG(totals.balance)} tone={totals.balance > 0 ? "red" : undefined} />
      </div>
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Ventes</CardTitle></CardHeader>
          <CardContent>
            {sales.length === 0 ? <p className="text-sm text-muted-foreground">Aucune vente.</p> : (
              <ul className="divide-y divide-border text-sm">
                {sales.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                    <span><Link href={`/ventes/${s.id}`} className="font-mono text-xs font-semibold hover:text-primary">{s.sale_number}</Link> <span className="text-muted-foreground">· {formatDateTime(s.sale_date)}</span></span>
                    <span className="flex items-center gap-2"><span className="tabular-nums font-semibold">{formatHTG(s.total)}</span>{s.status === "ANNULE" ? <StatusBadge map={RECORD_STATUS} value="ANNULE" /> : s.balance > 0 && <span className="text-xs font-semibold text-destructive">Solde {formatHTG(s.balance)}</span>}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Commandes de service</CardTitle></CardHeader>
          <CardContent>
            {orders.length === 0 ? <p className="text-sm text-muted-foreground">Aucune commande.</p> : (
              <ul className="divide-y divide-border text-sm">
                {orders.map((o) => (
                  <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                    <span><Link href={`/services/commandes/${o.id}`} className="font-mono text-xs font-semibold hover:text-primary">{o.order_number}</Link> <span className="text-muted-foreground">· {o.services?.name} · {formatDate(o.order_date)}</span></span>
                    <span className="flex items-center gap-2"><span className="tabular-nums font-semibold">{formatHTG(o.total)}</span><StatusBadge map={SERVICE_ORDER_STATUS} value={o.status} />{o.balance > 0 && o.status !== "ANNULE" && <span className="text-xs font-semibold text-destructive">Solde {formatHTG(o.balance)}</span>}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
