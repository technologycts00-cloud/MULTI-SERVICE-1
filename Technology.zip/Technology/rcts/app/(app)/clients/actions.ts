"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { customerSchema } from "@/lib/validations/party";

const WRITERS = ["ADMIN", "CAISSIER"] as const;
const idSchema = z.uuid();

export async function saveCustomer(id: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const p = customerSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Client introuvable." };
  if (id === null) {
    const { data, error } = await auth.supabase.from("customers").insert(p.data).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    revalidatePath("/clients");
    return { ok: true, id: data.id };
  }
  const { data, error } = await auth.supabase.from("customers").update(p.data).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Client introuvable ou accès refusé." };
  revalidatePath("/clients");
  revalidatePath(`/clients/${id}`);
  return { ok: true, id };
}

/** Archivage (jamais de suppression : l'historique des ventes et services est conservé). */
export async function setCustomerArchived(id: string, archived: boolean): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Client introuvable." };
  const { error } = await auth.supabase.from("customers").update({ is_archived: archived }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/clients");
  revalidatePath(`/clients/${id}`);
  return { ok: true };
}
