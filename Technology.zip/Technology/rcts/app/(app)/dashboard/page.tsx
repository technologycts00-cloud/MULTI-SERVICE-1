import type { Metadata } from "next";
import { AlertTriangle } from "lucide-react";
import { DashboardView } from "@/components/dashboard/dashboard-view";
import { requireProfile } from "@/lib/auth";
import { getDashboardStats } from "@/lib/dashboard";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic"; // chiffres toujours à jour

export default async function DashboardPage() {
  const [profile, result] = await Promise.all([requireProfile(), getDashboardStats()]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">Bonjour, {profile.full_name ?? "bienvenue"}</h1>
        <p className="text-sm text-muted-foreground">
          Tableau de bord · connecté en tant que {profile.role}
        </p>
      </div>

      {result.ok ? (
        <DashboardView stats={result.data} />
      ) : (
        <div role="alert" className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-destructive">
          <AlertTriangle className="mt-0.5 size-5 shrink-0" aria-hidden />
          <p>{result.message}</p>
        </div>
      )}
    </div>
  );
}
