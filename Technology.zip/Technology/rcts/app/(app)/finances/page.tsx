import type { Metadata } from "next";
import Link from "next/link";
import { ArrowDownCircle, ArrowUpCircle, Banknote, BookText, HandCoins, Landmark, Scale } from "lucide-react";
import { MonthlyChart } from "@/components/dashboard/charts";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { PageHeader } from "@/components/shared/page-header";
import { PeriodFilter } from "@/components/shared/period-filter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { CASH_CATEGORY, METHOD_LABELS } from "@/lib/labels";
import { resolvePeriod } from "@/lib/period";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { financeSummary } from "@/services/finance";

export const metadata: Metadata = { title: "Finances" };
export const dynamic = "force-dynamic";

function Breakdown({ title, rows, total }: { title: string; rows: { label: string; total: number }[]; total: number }) {
  return (
    <Card>
      <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
      <CardContent>
        {rows.length === 0 ? <p className="text-sm text-muted-foreground">Aucune opération sur la période.</p> : (
          <ul className="space-y-2 text-sm">
            {rows.map((r) => (
              <li key={r.label}>
                <div className="flex justify-between"><span>{r.label}</span><span className="font-semibold tabular-nums">{formatHTG(r.total)}</span></div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden><div className="h-full rounded-full bg-primary" style={{ width: `${total > 0 ? Math.max(2, (r.total / total) * 100) : 0}%` }} /></div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

export default async function FinancesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("finances");
  const sp = await searchParams;
  const period = resolvePeriod((k) => firstParam(sp[k]));
  const f = await financeSummary(await createClient(), period.from, period.to);
  const monthly = [...f.monthly].sort((a, b) => a.month.localeCompare(b.month));

  return (
    <div className="space-y-5">
      <PageHeader
        title="Finances"
        description={`Période : ${period.label}`}
        actions={<Button asChild variant="outline"><Link href={`/finances/journal?from=${period.from}&to=${period.to}`}><BookText aria-hidden /> Journal financier</Link></Button>}
      />
      <PeriodFilter basePath="/finances" period={period} />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <KpiCard label="Recettes" value={formatHTG(f.income)} tone="green" icon={ArrowDownCircle} hint="Formations, ventes, services, autres" />
        <KpiCard label="Dépenses" value={formatHTG(f.expenses)} tone="red" icon={ArrowUpCircle} hint="Dépenses et achats fournisseurs" />
        <KpiCard label="Solde (recettes − dépenses)" value={formatHTG(f.balance)} tone={f.balance >= 0 ? "blue" : "red"} icon={Scale} />
        <KpiCard label="Créances (à encaisser)" value={formatHTG(f.receivables.total)} tone="yellow" icon={HandCoins} hint={`${f.receivables.count} dossier${f.receivables.count > 1 ? "s" : ""} avec solde — toutes périodes`} />
        <KpiCard label="Dettes fournisseurs" value={formatHTG(f.payables.total)} tone={f.payables.total > 0 ? "red" : "slate"} icon={Landmark} hint={`${f.payables.count} achat${f.payables.count > 1 ? "s" : ""} à payer — toutes périodes`} />
        <KpiCard label="Espèces en caisse" value={formatHTG(f.cash_on_hand)} tone="blue" icon={Banknote} hint="Solde actuel" />
      </div>
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <MonthlyChart title="Recettes par mois" description="Sur la période" data={monthly.map((m) => ({ month: m.month, value: m.income }))} color="revenue" kind="money" valueHeader="Recettes" />
        <MonthlyChart title="Dépenses par mois" description="Sur la période" data={monthly.map((m) => ({ month: m.month, value: m.expenses }))} color="expenses" kind="money" valueHeader="Dépenses" />
      </div>
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Breakdown title="Recettes par catégorie" total={f.income} rows={f.income_by_category.map((r) => ({ label: CASH_CATEGORY[r.category] ?? r.category, total: r.total }))} />
        <Breakdown title="Recettes par mode de paiement" total={f.income} rows={f.income_by_method.map((r) => ({ label: METHOD_LABELS[r.method] ?? r.method, total: r.total }))} />
        <Breakdown title="Dépenses par catégorie" total={f.expenses} rows={f.expenses_by_category.map((r) => ({ label: r.category, total: r.total }))} />
      </div>
      <Card>
        <CardHeader><CardTitle>Détail des créances</CardTitle></CardHeader>
        <CardContent>
          <dl className="grid gap-3 text-sm sm:grid-cols-3">
            <div><dt className="text-xs text-muted-foreground">Formations (inscriptions)</dt><dd className="font-semibold tabular-nums">{formatHTG(f.receivables.formations)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Ventes à crédit</dt><dd className="font-semibold tabular-nums">{formatHTG(f.receivables.ventes)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Services</dt><dd className="font-semibold tabular-nums">{formatHTG(f.receivables.services)}</dd></div>
          </dl>
          <p className="mt-3 text-xs text-muted-foreground">Les encaissements se font depuis la page <Link href="/paiements" className="text-primary hover:underline">Paiements</Link>.</p>
        </CardContent>
      </Card>
    </div>
  );
}
