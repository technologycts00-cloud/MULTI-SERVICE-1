import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Plus } from "lucide-react";
import { CategoryAdder } from "@/components/produits/category-adder";
import { ProductsTable } from "@/components/produits/products-table";
import { ListFilters } from "@/components/shared/list-filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { requireModule } from "@/lib/auth";
import { STOCK_STATE, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { listCategories, listProducts } from "@/services/products";
import { addCategory } from "./actions";

export const metadata: Metadata = { title: "Produits" };
export const dynamic = "force-dynamic";

export default async function ProduitsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("produits");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const state = firstParam(sp.state) && firstParam(sp.state)! in STOCK_STATE ? firstParam(sp.state) : undefined;
  const cat = firstParam(sp.category);
  const category = cat && /^[0-9a-f-]{36}$/i.test(cat) ? cat : undefined;
  const inactive = firstParam(sp.archives) === "1";
  const page = parsePage(firstParam(sp.page));
  const canWrite = profile.role === "ADMIN" || profile.role === "GESTIONNAIRE";

  const supabase = await createClient();
  const [{ rows, total }, categories] = await Promise.all([
    listProducts(supabase, { q, category, state, status: inactive ? "INACTIF" : "ACTIF", page }),
    listCategories(supabase),
  ]);
  if (rows.length === 0 && page > 1) redirect("/produits");

  return (
    <div className="space-y-5">
      <PageHeader
        title={inactive ? "Produits désactivés" : "Produits"}
        description={`${total} produit${total > 1 ? "s" : ""}`}
        actions={canWrite && <Button asChild><Link href="/produits/nouveau"><Plus aria-hidden /> Nouveau produit</Link></Button>}
      />
      <ListFilters
        basePath="/produits"
        q={q}
        placeholder="Nom ou code produit"
        selects={[
          { name: "category", label: "Catégorie", value: category, options: categories.map((c) => ({ value: c.id, label: c.name })), allLabel: "Toutes catégories" },
          { name: "state", label: "Stock", value: state, options: options(STOCK_STATE), allLabel: "Tous les stocks" },
        ]}
        archivedToggle={canWrite ? { checked: inactive, label: "Voir les désactivés" } : undefined}
      />
      <ProductsTable rows={rows} showCost={canWrite} />
      <Pagination page={page} total={total} basePath="/produits" params={{ q, category, state, archives: inactive ? "1" : undefined }} />
      {canWrite && <CategoryAdder add={addCategory} />}
    </div>
  );
}
