"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { movementSchema, productSchema } from "@/lib/validations/product";
import { requiredText } from "@/lib/validations/common";
import { searchProductOptions } from "@/services/products";

const WRITERS = ["ADMIN", "GESTIONNAIRE"] as const;
const idSchema = z.uuid();

function refresh(id?: string) {
  for (const p of ["/produits", "/stock", "/caisse", "/dashboard"]) revalidatePath(p);
  if (id) revalidatePath(`/produits/${id}`);
}

export async function saveProduct(id: string | null, raw: unknown): Promise<ActionResult<{ id: string; warning?: string }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const parsed = productSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(parsed.error) };
  if (id !== null && !idSchema.safeParse(id).success) return { ok: false, error: "Produit introuvable." };
  const { initial_stock, ...v } = parsed.data;
  const { supabase } = auth;

  if (id === null) {
    const { data, error } = await supabase.from("products").insert({ ...v, current_stock: 0 }).select("id").single();
    if (error) return { ok: false, error: dbErrorMessage(error) };
    let warning: string | undefined;
    if (initial_stock > 0) {
      const mv = await supabase.rpc("record_stock_movement", {
        p_product_id: data.id, p_type: "ENTREE", p_quantity: initial_stock, p_reason: "Stock initial", p_reference: null,
      });
      if (mv.error) warning = "Produit créé, mais le stock initial n'a pas pu être enregistré : ajoutez-le dans Stock.";
    }
    refresh(data.id);
    return { ok: true, id: data.id, warning };
  }

  const { data, error } = await supabase.from("products").update(v).eq("id", id).select("id").maybeSingle();
  if (error) return { ok: false, error: dbErrorMessage(error) };
  if (!data) return { ok: false, error: "Produit introuvable ou accès refusé." };
  refresh(id);
  return { ok: true, id };
}

/** Désactivation (jamais de suppression : l'historique des ventes et du stock est conservé). */
export async function setProductStatus(id: string, status: "ACTIF" | "INACTIF"): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (!idSchema.safeParse(id).success) return { ok: false, error: "Produit introuvable." };
  const { error } = await auth.supabase.from("products").update({ status }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(id);
  return { ok: true };
}

export async function addCategory(name: string): Promise<ActionResult> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const n = requiredText("Nom", 60).safeParse(name);
  if (!n.success) return { ok: false, error: n.error.issues[0]?.message ?? "Nom invalide" };
  const { error } = await auth.supabase.from("product_categories").insert({ name: n.data });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh();
  return { ok: true };
}

/** Mouvement de stock manuel (entrée, sortie, ajustement, inventaire) : seule voie pour modifier le stock. */
export async function recordMovementAction(raw: unknown): Promise<ActionResult<{ stock_after: number | null }>> {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  const p = movementSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message ?? "Mouvement invalide.", fieldErrors: zodFieldErrors(p.error) };
  const { data, error } = await auth.supabase.rpc("record_stock_movement", {
    p_product_id: p.data.product_id, p_type: p.data.type, p_quantity: p.data.quantity, p_reason: p.data.reason, p_reference: p.data.reference,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh(p.data.product_id);
  const r = data as { changed: boolean; stock_after?: number; current_stock?: number };
  return { ok: true, stock_after: r.stock_after ?? r.current_stock ?? null };
}

export async function searchProductsAction(q: string) {
  const auth = await authorize(...WRITERS);
  if (!auth.ok) return auth;
  if (typeof q !== "string" || q.trim().length < 2) return { ok: true as const, items: [] };
  try {
    return { ok: true as const, items: await searchProductOptions(auth.supabase, q.slice(0, 60)) };
  } catch {
    return { ok: false as const, error: "Recherche impossible." };
  }
}
