import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Pencil, PowerOff, Power, Plus } from "lucide-react";
import { z } from "zod";
import { MovementsTable } from "@/components/stock/movements-table";
import { ActionButton } from "@/components/shared/action-button";
import { PageHeader } from "@/components/shared/page-header";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireModule } from "@/lib/auth";
import { PRODUCT_STATUS, STOCK_STATE } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatHTG } from "@/lib/utils";
import { getProduct, listMovements } from "@/services/products";
import { setProductStatus } from "../actions";

export const metadata: Metadata = { title: "Produit" };
export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  const profile = await requireModule("produits");
  const canWrite = profile.role === "ADMIN" || profile.role === "GESTIONNAIRE";
  const db = await createClient();
  const p = await getProduct(db, id);
  if (!p) notFound();
  const moves = canWrite ? await listMovements(db, { productId: id, page: 1, limit: 20 }) : null;

  return (
    <div className="space-y-5">
      <PageHeader title="Produit" back={{ href: "/produits", label: "Retour aux produits" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black">{p.name}</h2>
            <span className="font-mono text-xs text-muted-foreground">{p.code}</span>
            <StatusBadge map={STOCK_STATE} value={p.stock_state} />
            <StatusBadge map={PRODUCT_STATUS} value={p.status} />
          </div>
          {p.description && <p className="text-sm text-muted-foreground">{p.description}</p>}
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div><dt className="text-xs text-muted-foreground">Catégorie</dt><dd className="font-semibold">{p.product_categories?.name ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Fournisseur</dt><dd className="font-semibold">{p.suppliers?.name ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Prix de vente</dt><dd className="font-semibold">{formatHTG(Number(p.sale_price))}</dd></div>
            {canWrite && <div><dt className="text-xs text-muted-foreground">Prix d&apos;achat</dt><dd className="font-semibold">{formatHTG(Number(p.purchase_price))}</dd></div>}
            <div><dt className="text-xs text-muted-foreground">Stock actuel</dt><dd className="text-lg font-black">{p.current_stock}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Stock minimum</dt><dd className="font-semibold">{p.min_stock}</dd></div>
          </dl>
          {canWrite && (
            <div className="flex flex-wrap items-center gap-2">
              <Button asChild variant="outline"><Link href={`/stock?q=${encodeURIComponent(p.code)}`}><Plus aria-hidden /> Mouvement de stock</Link></Button>
              <Button asChild variant="outline"><Link href={`/produits/${id}/modifier`}><Pencil aria-hidden /> Modifier</Link></Button>
              {p.status === "ACTIF" ? (
                <ActionButton size="default" action={setProductStatus.bind(null, id, "INACTIF")} confirm={{ title: "Désactiver ce produit ?", description: "Il n'apparaîtra plus à la caisse. L'historique des ventes et du stock est conservé.", confirmLabel: "Désactiver" }}><PowerOff aria-hidden /> Désactiver</ActionButton>
              ) : (
                <ActionButton size="default" action={setProductStatus.bind(null, id, "ACTIF")}><Power aria-hidden /> Réactiver</ActionButton>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      {moves && (
        <Card>
          <CardHeader><CardTitle>Historique des mouvements</CardTitle></CardHeader>
          <CardContent className="p-0"><MovementsTable rows={moves.rows} showProduct={false} /></CardContent>
        </Card>
      )}
    </div>
  );
}
