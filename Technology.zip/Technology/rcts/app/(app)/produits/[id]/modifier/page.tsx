import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { z } from "zod";
import { ProductForm } from "@/components/produits/product-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { getProduct, listCategories, listSupplierOptions } from "@/services/products";
import { saveProduct } from "../../actions";

export const metadata: Metadata = { title: "Modifier le produit" };
export const dynamic = "force-dynamic";

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN", "GESTIONNAIRE");
  const db = await createClient();
  const [p, categories, suppliers] = await Promise.all([getProduct(db, id), listCategories(db), listSupplierOptions(db)]);
  if (!p) notFound();
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Modifier le produit" description={p.code} back={{ href: `/produits/${id}`, label: "Retour au produit" }} />
      <ProductForm
        productId={id}
        save={saveProduct}
        categories={categories}
        suppliers={suppliers}
        defaults={{
          name: p.name,
          category_id: p.category_id ?? "",
          description: p.description ?? "",
          purchase_price: String(p.purchase_price),
          sale_price: String(p.sale_price),
          min_stock: String(p.min_stock),
          supplier_id: p.supplier_id ?? "",
          status: p.status,
          initial_stock: "0",
        }}
      />
    </div>
  );
}
