import type { Metadata } from "next";
import { ProductForm } from "@/components/produits/product-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { listCategories, listSupplierOptions } from "@/services/products";
import { saveProduct } from "../actions";

export const metadata: Metadata = { title: "Nouveau produit" };
export const dynamic = "force-dynamic";

export default async function NewProductPage() {
  await requireRole("ADMIN", "GESTIONNAIRE");
  const db = await createClient();
  const [categories, suppliers] = await Promise.all([listCategories(db), listSupplierOptions(db)]);
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouveau produit" description="Le code produit est attribué automatiquement." back={{ href: "/produits", label: "Retour aux produits" }} />
      <ProductForm
        productId={null}
        save={saveProduct}
        categories={categories}
        suppliers={suppliers}
        defaults={{ name: "", category_id: "", description: "", purchase_price: "0", sale_price: "", min_stock: "0", supplier_id: "", status: "ACTIF", initial_stock: "0" }}
      />
    </div>
  );
}
