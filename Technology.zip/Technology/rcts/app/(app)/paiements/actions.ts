"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { PAYMENT_METHODS, money, optionalText } from "@/lib/validations/common";

const payInput = z.object({
  kind: z.enum(["INSCRIPTION", "VENTE", "SERVICE"]),
  target_id: z.uuid(),
  amount: money("Montant", { allowZero: false }),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
});

function refresh() {
  for (const p of ["/paiements", "/caisse", "/caisse/journal", "/dashboard", "/inscriptions", "/ventes", "/services", "/finances"]) revalidatePath(p);
}

/** Encaissement d'un solde (inscription, vente à crédit, commande de service) : paiement + caisse + reçu en une transaction. */
export async function recordPaymentAction(raw: unknown): Promise<ActionResult<{ receipt_id: string; receipt_number: string; balance: number }>> {
  const auth = await authorize("ADMIN", "CAISSIER");
  if (!auth.ok) return auth;
  const p = payInput.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };

  const { data, error } = await auth.supabase.rpc("record_payment", {
    p_kind: p.data.kind,
    p_target_id: p.data.target_id,
    p_amount: p.data.amount,
    p_method: p.data.method,
    p_reference: p.data.reference,
    p_description: null,
  });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  const r = data as { receipt_id: string; receipt_number: string; balance: number };
  refresh();
  return { ok: true, receipt_id: r.receipt_id, receipt_number: r.receipt_number, balance: Number(r.balance) };
}

/** Annulation d'un paiement (jamais de suppression) : ADMIN, motif obligatoire, caisse corrigée par la base. */
export async function voidPaymentAction(paymentId: string, reason: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!z.uuid().safeParse(paymentId).success) return { ok: false, error: "Paiement introuvable." };
  const r = reason?.trim() ?? "";
  if (r.length < 3) return { ok: false, error: "Indiquez le motif de l'annulation." };
  if (r.length > 300) return { ok: false, error: "Motif trop long (300 caractères maximum)." };

  const { error } = await auth.supabase.rpc("void_payment", { p_payment_id: paymentId, p_reason: r });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh();
  return { ok: true };
}

/** Émet (ou retrouve) la facture d'une inscription, d'une vente ou d'une commande de service. */
export async function issueInvoiceAction(kind: string, targetId: string): Promise<ActionResult<{ invoice_id: string }>> {
  const auth = await authorize("ADMIN", "CAISSIER", "SECRETAIRE");
  if (!auth.ok) return auth;
  const k = z.enum(["INSCRIPTION", "VENTE", "SERVICE"]).safeParse(kind);
  if (!k.success || !z.uuid().safeParse(targetId).success) return { ok: false, error: "Élément introuvable." };

  const { data, error } = await auth.supabase.rpc("issue_invoice", { p_kind: k.data, p_target_id: targetId, p_due_date: null, p_notes: null });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/paiements");
  return { ok: true, invoice_id: (data as { invoice_id: string }).invoice_id };
}
