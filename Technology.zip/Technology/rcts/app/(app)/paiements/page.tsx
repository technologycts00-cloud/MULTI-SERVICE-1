import type { Metadata } from "next";
import Link from "next/link";
import { Search } from "lucide-react";
import { PaymentsTable } from "@/components/paiements/payments-table";
import { Receivables } from "@/components/paiements/receivables";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { requireModule } from "@/lib/auth";
import { METHOD_LABELS, PAYMENT_KIND, RECORD_STATUS, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { listPayments, listReceivables } from "@/services/payments";

export const metadata: Metadata = { title: "Paiements" };
export const dynamic = "force-dynamic";

const pick = (v: string | undefined, allowed: string[]) => (v && allowed.includes(v) ? v : undefined);
const dateOnly = (v: string | undefined) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);

export default async function PaiementsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const profile = await requireModule("paiements");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const kind = pick(firstParam(sp.kind), Object.keys(PAYMENT_KIND));
  const method = pick(firstParam(sp.method), Object.keys(METHOD_LABELS));
  const status = pick(firstParam(sp.status), Object.keys(RECORD_STATUS));
  const from = dateOnly(firstParam(sp.from));
  const to = dateOnly(firstParam(sp.to));
  const page = parsePage(firstParam(sp.page));
  const canCollect = profile.role === "ADMIN" || profile.role === "CAISSIER";

  const supabase = await createClient();
  const [{ rows, total }, receivables] = await Promise.all([
    listPayments(supabase, { q, kind, method, status, from, to, page }),
    canCollect ? listReceivables(supabase, q) : Promise.resolve([]),
  ]);

  return (
    <div className="space-y-5">
      <PageHeader title="Paiements" description={`${total} paiement${total > 1 ? "s" : ""} — chaque paiement génère un reçu`} />

      {canCollect && (
        <Card>
          <CardHeader>
            <CardTitle>Soldes à encaisser</CardTitle>
            <CardDescription>Inscriptions, ventes à crédit et commandes de service non soldées.</CardDescription>
          </CardHeader>
          <CardContent><Receivables items={receivables} /></CardContent>
        </Card>
      )}

      <form method="get" action="/paiements" className="grid gap-3 rounded-xl border border-border bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
        <div className="relative sm:col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input name="q" defaultValue={q ?? ""} placeholder="Payeur, N° paiement, reçu, référence" className="pl-9" aria-label="Rechercher" />
        </div>
        <Select name="kind" defaultValue={kind ?? ""} aria-label="Type">
          <option value="">Tous les types</option>
          {options(PAYMENT_KIND).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
        <Select name="method" defaultValue={method ?? ""} aria-label="Mode de paiement">
          <option value="">Tous les modes</option>
          {options(METHOD_LABELS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
        <Select name="status" defaultValue={status ?? ""} aria-label="Statut">
          <option value="">Tous statuts</option>
          {options(RECORD_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
        <div className="flex gap-2">
          <Button type="submit" className="flex-1">Filtrer</Button>
          <Button asChild variant="outline"><Link href="/paiements">Effacer</Link></Button>
        </div>
        <label className="flex items-center gap-2 text-xs text-muted-foreground sm:col-span-1">Du <Input type="date" name="from" defaultValue={from ?? ""} className="h-9" /></label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground sm:col-span-1">Au <Input type="date" name="to" defaultValue={to ?? ""} className="h-9" /></label>
      </form>

      <PaymentsTable rows={rows} canVoid={profile.role === "ADMIN"} />
      <Pagination page={page} total={total} basePath="/paiements" params={{ q, kind, method, status, from, to }} />
    </div>
  );
}
