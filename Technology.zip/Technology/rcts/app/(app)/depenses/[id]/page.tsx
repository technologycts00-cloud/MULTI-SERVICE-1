import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Paperclip } from "lucide-react";
import { z } from "zod";
import { PageHeader } from "@/components/shared/page-header";
import { VoidWithReason } from "@/components/shared/void-with-reason";
import { StatusBadge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { requireRole } from "@/lib/auth";
import { METHOD_LABELS, RECORD_STATUS, formatDate } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime, formatHTG } from "@/lib/utils";
import { getExpense } from "@/services/expenses";
import { voidExpenseAction } from "../actions";

export const metadata: Metadata = { title: "Dépense" };
export const dynamic = "force-dynamic";

export default async function ExpensePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.uuid().safeParse(id).success) notFound();
  await requireRole("ADMIN");
  const db = await createClient();
  const d = await getExpense(db, id);
  if (!d) notFound();
  const { expense: e, responsible, voidedBy } = d;
  let receiptLink: string | null = null;
  if (e.receipt_url) {
    const { data } = await db.storage.from("expense-receipts").createSignedUrl(e.receipt_url, 300);
    receiptLink = data?.signedUrl ?? null;
  }

  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title={`Dépense ${e.expense_number}`} back={{ href: "/depenses", label: "Retour aux dépenses" }} />
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2"><StatusBadge map={RECORD_STATUS} value={e.status} /><span className="text-sm text-muted-foreground">{formatDate(e.expense_date)}</span></div>
          <p className="text-lg font-semibold">{e.description}</p>
          <dl className="grid gap-4 text-sm sm:grid-cols-2">
            <div><dt className="text-xs text-muted-foreground">Montant</dt><dd className="text-2xl font-black tabular-nums">{formatHTG(e.amount)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Catégorie</dt><dd className="font-semibold">{e.expense_categories?.name ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Mode de paiement</dt><dd className="font-semibold">{METHOD_LABELS[e.method] ?? e.method}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Responsable</dt><dd className="font-semibold">{responsible ?? "—"}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Enregistrée le</dt><dd className="font-semibold">{formatDateTime(e.created_at)}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Justificatif</dt><dd className="font-semibold">{receiptLink ? <a href={receiptLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-primary hover:underline"><Paperclip className="size-4" aria-hidden />Ouvrir</a> : e.receipt_url ? "Indisponible" : "Aucun"}</dd></div>
          </dl>
          {e.status === "ANNULE" && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">Dépense annulée{voidedBy ? ` par ${voidedBy}` : ""}{e.voided_at ? ` le ${formatDateTime(e.voided_at)}` : ""} : {e.void_reason}</p>}
          {e.status === "VALIDE" && (
            <VoidWithReason action={voidExpenseAction.bind(null, id)} title="Annuler cette dépense ?" description="La sortie de caisse est annulée et le solde corrigé. La dépense reste visible dans l'historique." label="Annuler la dépense" />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
