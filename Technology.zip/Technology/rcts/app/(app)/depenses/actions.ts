"use server";

import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, type ActionResult } from "@/lib/action-result";
import { PAYMENT_METHODS, money, requiredDate, requiredText } from "@/lib/validations/common";

const BUCKET = "expense-receipts";
const MAX_FILE = 5 * 1024 * 1024;

/** Type réel du fichier d'après ses premiers octets (le type MIME envoyé par le navigateur n'est pas fiable). */
function sniff(b: Uint8Array): { ext: string; mime: string } | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: "jpg", mime: "image/jpeg" };
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return { ext: "png", mime: "image/png" };
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return { ext: "webp", mime: "image/webp" };
  if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return { ext: "pdf", mime: "application/pdf" };
  return null;
}

const expenseSchema = z.object({
  category_id: z.uuid({ error: "Choisissez une catégorie" }),
  description: requiredText("Description", 200),
  amount: money("Montant", { allowZero: false }),
  method: z.enum(PAYMENT_METHODS),
  expense_date: requiredDate("Date"),
});

function refresh() {
  for (const p of ["/depenses", "/finances", "/finances/journal", "/caisse", "/caisse/journal", "/dashboard"]) revalidatePath(p);
}

/** Dépense : ADMIN uniquement. Écrit la dépense + la sortie de caisse en une transaction (RPC), puis envoie le justificatif. */
export async function createExpenseAction(formData: FormData): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  const parsed = expenseSchema.safeParse({
    category_id: String(formData.get("category_id") ?? ""),
    description: String(formData.get("description") ?? ""),
    amount: String(formData.get("amount") ?? ""),
    method: String(formData.get("method") ?? ""),
    expense_date: String(formData.get("expense_date") ?? ""),
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const i of parsed.error.issues) fieldErrors[String(i.path[0])] ??= i.message;
    return { ok: false, error: "Certains champs sont invalides.", fieldErrors };
  }
  const file = formData.get("receipt");
  let path: string | null = null;
  const { supabase } = auth;
  if (file instanceof File && file.size > 0) {
    if (file.size > MAX_FILE) return { ok: false, error: "Le justificatif dépasse 5 Mo.", fieldErrors: { receipt: "Fichier trop lourd (5 Mo maximum)" } };
    const bytes = new Uint8Array(await file.arrayBuffer());
    const kind = sniff(bytes);
    if (!kind) return { ok: false, error: "Justificatif non accepté : utilisez une image JPEG, PNG, WebP ou un PDF.", fieldErrors: { receipt: "Format non accepté" } };
    path = `${new Date().getUTCFullYear()}/${randomUUID()}.${kind.ext}`;
    const up = await supabase.storage.from(BUCKET).upload(path, bytes, { contentType: kind.mime, upsert: false });
    if (up.error) return { ok: false, error: "Envoi du justificatif impossible. Vérifiez que la migration 0011 a été exécutée (bucket « expense-receipts »)." };
  }

  const { data, error } = await supabase.rpc("record_expense", {
    p_category_id: parsed.data.category_id,
    p_description: parsed.data.description,
    p_amount: parsed.data.amount,
    p_method: parsed.data.method,
    p_expense_date: parsed.data.expense_date,
    p_responsible_id: auth.profile.id,
    p_receipt_url: path,
  });
  if (error) {
    if (path) await supabase.storage.from(BUCKET).remove([path]);
    return { ok: false, error: dbErrorMessage(error) };
  }
  refresh();
  return { ok: true, id: (data as { expense_id: string }).expense_id };
}

export async function voidExpenseAction(id: string, reason: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!z.uuid().safeParse(id).success) return { ok: false, error: "Dépense introuvable." };
  const r = reason?.trim() ?? "";
  if (r.length < 3) return { ok: false, error: "Indiquez le motif de l'annulation." };
  if (r.length > 300) return { ok: false, error: "Motif trop long (300 caractères maximum)." };
  const { error } = await auth.supabase.rpc("void_expense", { p_expense_id: id, p_reason: r });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  refresh();
  revalidatePath(`/depenses/${id}`);
  return { ok: true };
}

export async function addExpenseCategory(name: string): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  const n = requiredText("Nom", 60).safeParse(name);
  if (!n.success) return { ok: false, error: n.error.issues[0]?.message ?? "Nom invalide" };
  const { error } = await auth.supabase.from("expense_categories").insert({ name: n.data });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/depenses");
  return { ok: true };
}

export async function setExpenseCategoryActive(id: string, active: boolean): Promise<ActionResult> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  if (!z.uuid().safeParse(id).success) return { ok: false, error: "Catégorie introuvable." };
  const { error } = await auth.supabase.from("expense_categories").update({ is_active: active }).eq("id", id);
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/depenses");
  return { ok: true };
}
