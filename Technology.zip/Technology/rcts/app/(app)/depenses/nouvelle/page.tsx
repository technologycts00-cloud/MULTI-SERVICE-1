import type { Metadata } from "next";
import { ExpenseForm } from "@/components/depenses/expense-form";
import { PageHeader } from "@/components/shared/page-header";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { todayHaiti } from "@/lib/utils";
import { listExpenseCategories } from "@/services/expenses";
import { cashOverview } from "@/services/payments";
import { createExpenseAction } from "../actions";

export const metadata: Metadata = { title: "Nouvelle dépense" };
export const dynamic = "force-dynamic";

export default async function NewExpensePage() {
  await requireRole("ADMIN");
  const db = await createClient();
  const [categories, cash] = await Promise.all([listExpenseCategories(db), cashOverview(db)]);
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Nouvelle dépense" description="Chaque dépense apparaît dans les finances ; payée en espèces, elle diminue le solde de caisse." back={{ href: "/depenses", label: "Retour aux dépenses" }} />
      <ExpenseForm categories={categories} today={todayHaiti()} cashOnHand={cash.cash_on_hand} create={createExpenseAction} />
    </div>
  );
}
