import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Paperclip, Plus } from "lucide-react";
import { CategoryManager } from "@/components/depenses/category-manager";
import { Empty } from "@/components/shared/empty";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination } from "@/components/shared/pagination";
import { StatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { requireRole } from "@/lib/auth";
import { METHOD_LABELS, RECORD_STATUS, formatDate, options } from "@/lib/labels";
import { firstParam, parsePage } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { cn, formatHTG } from "@/lib/utils";
import { listExpenseCategories, listExpenses } from "@/services/expenses";
import { addExpenseCategory, setExpenseCategoryActive } from "./actions";

export const metadata: Metadata = { title: "Dépenses" };
export const dynamic = "force-dynamic";
const dateOnly = (v: string | undefined) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);

export default async function DepensesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireRole("ADMIN");
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const category = /^[0-9a-f-]{36}$/i.test(firstParam(sp.category) ?? "") ? firstParam(sp.category) : undefined;
  const method = firstParam(sp.method) && firstParam(sp.method)! in METHOD_LABELS ? firstParam(sp.method) : undefined;
  const status = firstParam(sp.status) && firstParam(sp.status)! in RECORD_STATUS ? firstParam(sp.status) : undefined;
  const from = dateOnly(firstParam(sp.from));
  const to = dateOnly(firstParam(sp.to));
  const page = parsePage(firstParam(sp.page));

  const db = await createClient();
  const [{ rows, total, sum }, categories] = await Promise.all([listExpenses(db, { q, category, method, status, from, to, page }), listExpenseCategories(db, true)]);
  if (rows.length === 0 && page > 1) redirect("/depenses");

  return (
    <div className="space-y-5">
      <PageHeader
        title="Dépenses"
        description={`${total} dépense${total > 1 ? "s" : ""} — total de la sélection : ${formatHTG(sum)}`}
        actions={<Button asChild><Link href="/depenses/nouvelle"><Plus aria-hidden /> Nouvelle dépense</Link></Button>}
      />
      <form method="get" action="/depenses" className="grid gap-3 rounded-xl border border-border bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
        <Input name="q" defaultValue={q ?? ""} placeholder="Description ou n°" aria-label="Rechercher" className="sm:col-span-2" />
        <Select name="category" defaultValue={category ?? ""} aria-label="Catégorie"><option value="">Toutes catégories</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select>
        <Select name="method" defaultValue={method ?? ""} aria-label="Mode"><option value="">Tous les modes</option>{options(METHOD_LABELS as never).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
        <Select name="status" defaultValue={status ?? ""} aria-label="Statut"><option value="">Tous statuts</option>{options(RECORD_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</Select>
        <div className="flex gap-2"><Button type="submit" className="flex-1">Filtrer</Button><Button asChild variant="outline"><Link href="/depenses">Effacer</Link></Button></div>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">Du <Input type="date" name="from" defaultValue={from ?? ""} className="h-9" /></label>
        <label className="flex items-center gap-2 text-xs text-muted-foreground">Au <Input type="date" name="to" defaultValue={to ?? ""} className="h-9" /></label>
      </form>
      {rows.length === 0 ? <Empty>Aucune dépense trouvée.</Empty> : (
        <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr><th className="px-4 py-3">N°</th><th className="px-4 py-3">Date</th><th className="px-4 py-3">Catégorie</th><th className="px-4 py-3">Description</th><th className="px-4 py-3 text-right">Montant</th><th className="px-4 py-3">Mode</th><th className="px-4 py-3">Statut</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((e) => (
                  <tr key={e.id} className={cn("hover:bg-muted/50", e.status === "ANNULE" && "text-muted-foreground")}>
                    <td className="px-4 py-3"><Link href={`/depenses/${e.id}`} className="font-mono text-xs font-semibold hover:text-primary">{e.expense_number}</Link></td>
                    <td className="whitespace-nowrap px-4 py-3">{formatDate(e.expense_date)}</td>
                    <td className="px-4 py-3">{e.expense_categories?.name ?? "—"}</td>
                    <td className="px-4 py-3">{e.description}{e.receipt_url && <Paperclip className="ml-1 inline size-3.5 text-muted-foreground" aria-label="Justificatif joint" />}</td>
                    <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", e.status === "ANNULE" && "line-through")}>{formatHTG(e.amount)}</td>
                    <td className="px-4 py-3">{METHOD_LABELS[e.method] ?? e.method}</td>
                    <td className="px-4 py-3"><StatusBadge map={RECORD_STATUS} value={e.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} basePath="/depenses" params={{ q, category, method, status, from, to }} />
      <CategoryManager categories={categories} add={addExpenseCategory} setActive={setExpenseCategoryActive} />
    </div>
  );
}
