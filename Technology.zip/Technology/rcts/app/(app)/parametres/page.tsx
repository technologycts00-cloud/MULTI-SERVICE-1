import type { Metadata } from "next";
import { CheckCircle2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { SettingsForm } from "@/components/parametres/settings-form";
import { requireModule } from "@/lib/auth";
import { firstParam } from "@/lib/search";
import { createClient } from "@/lib/supabase/server";
import { SETTING_KEYS, type SettingsInput } from "@/lib/validations/admin";
import { saveSettings } from "./actions";

export const metadata: Metadata = { title: "Paramètres" };
export const dynamic = "force-dynamic";

export default async function SettingsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  await requireModule("parametres");
  const sp = await searchParams;
  const { data } = await (await createClient()).from("settings").select("key, value").in("key", [...SETTING_KEYS, "currency"]);
  const map = Object.fromEntries((data ?? []).map((r) => [r.key, typeof r.value === "string" ? r.value : ""]));
  const defaults = Object.fromEntries(SETTING_KEYS.map((k) => [k, map[k] ?? ""])) as SettingsInput;
  return (
    <div className="max-w-3xl space-y-5">
      <PageHeader title="Paramètres" description={`Informations de l'entreprise et numérotation. Devise : ${map.currency || "HTG"}.`} />
      {firstParam(sp.ok) === "1" && (
        <p role="status" className="flex items-center gap-2 rounded-lg bg-green-50 px-3 py-2 text-sm text-success"><CheckCircle2 className="size-4" aria-hidden /> Paramètres enregistrés.</p>
      )}
      <SettingsForm defaults={defaults} save={saveSettings} />
    </div>
  );
}
