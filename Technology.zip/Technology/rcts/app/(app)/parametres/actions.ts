"use server";

import { revalidatePath } from "next/cache";
import { authorize } from "@/lib/auth";
import { dbErrorMessage, zodFieldErrors, type ActionResult } from "@/lib/action-result";
import { SETTING_KEYS, settingsSchema } from "@/lib/validations/admin";

export async function saveSettings(raw: unknown): Promise<ActionResult<{ id: string }>> {
  const auth = await authorize("ADMIN");
  if (!auth.ok) return auth;
  const p = settingsSchema.safeParse(raw);
  if (!p.success) return { ok: false, error: "Certains champs sont invalides.", fieldErrors: zodFieldErrors(p.error) };
  const rows = SETTING_KEYS.map((key) => ({ key, value: p.data[key] }));
  const { error } = await auth.supabase.from("settings").upsert(rows, { onConflict: "key" });
  if (error) return { ok: false, error: dbErrorMessage(error) };
  revalidatePath("/", "layout");
  return { ok: true, id: "settings" };
}
