import type { Metadata } from "next";
import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "./login-form";

export const metadata: Metadata = { title: "Connexion" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const { next, error } = await searchParams;
  const initialError =
    error === "compte-inactif" ? "Ce compte est désactivé." : error === "lien-invalide" ? "Lien invalide ou expiré." : undefined;
  return (
    <AuthShell title="Connexion" description="Accédez à votre espace de gestion">
      <LoginForm next={next} initialError={initialError} />
    </AuthShell>
  );
}
