import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/components/auth/auth-shell";
import { ForgotForm } from "./forgot-form";

export const metadata: Metadata = { title: "Mot de passe oublié" };

export default function ForgotPasswordPage() {
  return (
    <AuthShell title="Mot de passe oublié" description="Saisissez votre e-mail pour recevoir un lien de réinitialisation">
      <ForgotForm />
      <div className="mt-4 text-center">
        <Link href="/login" className="text-sm text-primary hover:underline">
          Retour à la connexion
        </Link>
      </div>
    </AuthShell>
  );
}
