import type { Metadata } from "next";
import { AuthShell } from "@/components/auth/auth-shell";
import { ResetForm } from "./reset-form";

export const metadata: Metadata = { title: "Nouveau mot de passe" };

export default function ResetPasswordPage() {
  return (
    <AuthShell title="Nouveau mot de passe" description="Choisissez un nouveau mot de passe">
      <ResetForm />
    </AuthShell>
  );
}
