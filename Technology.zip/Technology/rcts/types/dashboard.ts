import type { Role } from "@/types";

export interface MonthTotal {
  month: string; // "2026-03"
  total: number;
}
export interface MonthCount {
  month: string;
  count: number;
}
export interface MonthSales extends MonthTotal {
  count: number;
}

export type CashCategory = "FORMATION" | "VENTE" | "SERVICE" | "DEPENSE" | "ACHAT_FOURNISSEUR" | "AUTRE";

export interface RecentTransaction {
  id: string;
  occurred_at: string;
  direction: "IN" | "OUT";
  category: CashCategory;
  description: string | null;
  amount: number;
  method: string;
  status: "VALIDE" | "ANNULE";
  user_name: string | null;
}

export interface StockAlert {
  id: string;
  code: string;
  name: string;
  current_stock: number;
  min_stock: number;
  stock_state: "FAIBLE" | "RUPTURE";
}

/** Réponse de la fonction SQL public.dashboard_stats() — chaque section est null si le rôle n'y a pas accès. */
export interface DashboardStats {
  role: Role;
  generated_at: string;
  finance: {
    revenue_today: number;
    revenue_month: number;
    total_payments: number;
    cash_balance: number;
    receivables: number;
    pending_count: number;
    total_expenses: number | null;
    expenses_month: number | null;
  } | null;
  school: {
    students_total: number;
    students_active: number;
    new_enrollments_month: number;
    unpaid_enrollments: number;
    enrollment_receivables: number;
  } | null;
  stock: {
    low_stock: number;
    out_of_stock: number;
    alerts: StockAlert[];
  } | null;
  recent: RecentTransaction[] | null;
  charts: {
    revenue: MonthTotal[] | null;
    expenses: MonthTotal[] | null;
    enrollments: MonthCount[] | null;
    sales: MonthSales[] | null;
    by_category: { category: CashCategory; total: number }[] | null;
  };
}
