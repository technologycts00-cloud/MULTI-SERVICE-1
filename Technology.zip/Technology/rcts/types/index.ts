export const ROLES = [
  "ADMIN",
  "CAISSIER",
  "SECRETAIRE",
  "GESTIONNAIRE",
  "FORMATEUR",
] as const;

export type Role = (typeof ROLES)[number];

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  role: Role;
  is_active: boolean;
}
