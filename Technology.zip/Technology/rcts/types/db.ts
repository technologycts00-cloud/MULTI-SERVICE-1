// FICHIER GÉNÉRÉ par scripts/gen-types.mjs — ne pas modifier à la main.
// Régénérer avec : npm run db:types

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type CashCategory = "FORMATION" | "VENTE" | "SERVICE" | "DEPENSE" | "ACHAT_FOURNISSEUR" | "AUTRE";
export type CashDirection = "IN" | "OUT";
export type CustomerType = "PARTICULIER" | "ENTREPRISE" | "INSTITUTION";
export type EnrollmentStatus = "ACTIVE" | "TERMINEE" | "ABANDONNEE" | "ANNULEE";
export type Gender = "M" | "F";
export type PaymentKind = "INSCRIPTION" | "VENTE" | "SERVICE";
export type PaymentMethod = "ESPECES" | "MONCASH" | "NATCASH" | "VIREMENT" | "AUTRE";
export type ProductStatus = "ACTIF" | "INACTIF";
export type RecordStatus = "VALIDE" | "ANNULE";
export type ServiceOrderStatus = "EN_ATTENTE" | "EN_COURS" | "TERMINE" | "LIVRE" | "ANNULE";
export type StockMovementType = "ENTREE" | "SORTIE" | "AJUSTEMENT" | "INVENTAIRE" | "VENTE" | "ACHAT" | "ANNULATION";
export type StudentStatus = "ACTIF" | "TERMINE" | "SUSPENDU" | "INACTIF";
export type TrainingStatus = "PLANIFIEE" | "EN_COURS" | "TERMINEE" | "ANNULEE";
export type UserRole = "ADMIN" | "CAISSIER" | "SECRETAIRE" | "GESTIONNAIRE" | "FORMATEUR";

export interface AuditLogsRow {
  id: number;
  user_id: string | null;
  user_email: string | null;
  action: string;
  module: string;
  record_id: string | null;
  old_value: Json | null;
  new_value: Json | null;
  created_at: string;
}

export interface CashTransactionsRow {
  id: string;
  direction: CashDirection;
  category: CashCategory;
  amount: number;
  method: PaymentMethod;
  description: string | null;
  occurred_at: string;
  source_type: string;
  source_id: string | null;
  status: RecordStatus;
  created_by: string | null;
  voided_at: string | null;
  created_at: string;
}

export interface CertificatesRow {
  id: string;
  certificate_number: string;
  enrollment_id: string;
  student_id: string;
  training_id: string;
  issued_on: string;
  issued_by: string | null;
  notes: string | null;
  created_at: string;
}

export interface CountersRow {
  key: string;
  year: number;
  value: number;
}

export interface CustomersRow {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  customer_type: CustomerType;
  notes: string | null;
  is_archived: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface EnrollmentsRow {
  id: string;
  enrollment_number: string;
  student_id: string;
  training_id: string;
  enrolled_on: string;
  training_price: number;
  registration_fee: number;
  discount: number;
  amount_paid: number;
  total_due: number | null;
  balance: number | null;
  payment_status: string | null;
  status: EnrollmentStatus;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ExpenseCategoriesRow {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
}

export interface ExpensesRow {
  id: string;
  expense_number: string;
  expense_date: string;
  category_id: string;
  description: string;
  amount: number;
  method: PaymentMethod;
  responsible_id: string | null;
  receipt_url: string | null;
  status: RecordStatus;
  voided_at: string | null;
  voided_by: string | null;
  void_reason: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface InvoicesRow {
  id: string;
  invoice_number: string;
  kind: PaymentKind;
  student_id: string | null;
  customer_id: string | null;
  enrollment_id: string | null;
  sale_id: string | null;
  service_order_id: string | null;
  client_name: string;
  description: string | null;
  total: number;
  issued_at: string;
  due_date: string | null;
  notes: string | null;
  status: RecordStatus;
  issued_by: string | null;
}

export interface PaymentsRow {
  id: string;
  payment_number: string;
  kind: PaymentKind;
  student_id: string | null;
  customer_id: string | null;
  enrollment_id: string | null;
  sale_id: string | null;
  service_order_id: string | null;
  amount: number;
  method: PaymentMethod;
  reference: string | null;
  description: string | null;
  paid_at: string;
  status: RecordStatus;
  created_by: string | null;
  voided_at: string | null;
  voided_by: string | null;
  void_reason: string | null;
  created_at: string;
}

export interface ProductCategoriesRow {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface ProductsRow {
  id: string;
  code: string;
  name: string;
  category_id: string | null;
  description: string | null;
  purchase_price: number;
  sale_price: number;
  current_stock: number;
  min_stock: number;
  supplier_id: string | null;
  status: ProductStatus;
  stock_state: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProfilesRow {
  id: string;
  full_name: string | null;
  email: string | null;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface PurchaseItemsRow {
  id: string;
  purchase_id: string;
  product_id: string;
  quantity: number;
  unit_cost: number;
  line_total: number | null;
}

export interface PurchasesRow {
  id: string;
  purchase_number: string;
  supplier_id: string;
  purchase_date: string;
  total_amount: number;
  amount_paid: number;
  balance: number | null;
  status: RecordStatus;
  notes: string | null;
  created_by: string | null;
  created_at: string;
}

export interface ReceiptsRow {
  id: string;
  receipt_number: string;
  payment_id: string;
  issued_at: string;
  issued_by: string | null;
  payer_name: string;
  description: string | null;
  amount: number;
  method: PaymentMethod;
  total_due: number;
  balance_after: number;
  status: RecordStatus;
}

export interface SaleItemsRow {
  id: string;
  sale_id: string;
  product_id: string | null;
  service_id: string | null;
  description: string;
  quantity: number;
  unit_price: number;
  line_total: number | null;
  created_at: string;
}

export interface SalesRow {
  id: string;
  sale_number: string;
  customer_id: string | null;
  sale_date: string;
  subtotal: number;
  discount: number;
  amount_paid: number;
  total: number | null;
  balance: number | null;
  payment_status: string | null;
  payment_method: PaymentMethod;
  status: RecordStatus;
  notes: string | null;
  seller_id: string | null;
  voided_at: string | null;
  voided_by: string | null;
  void_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface ServiceOrdersRow {
  id: string;
  order_number: string;
  customer_id: string;
  service_id: string;
  quantity: number;
  unit_price: number;
  amount_paid: number;
  total: number | null;
  balance: number | null;
  order_date: string;
  due_date: string | null;
  status: ServiceOrderStatus;
  responsible_id: string | null;
  comment: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ServicesRow {
  id: string;
  name: string;
  category: string | null;
  description: string | null;
  unit_price: number;
  unit: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface SettingsRow {
  key: string;
  value: Json;
  description: string | null;
  updated_by: string | null;
  updated_at: string;
}

export interface StockMovementsRow {
  id: string;
  product_id: string;
  movement_type: StockMovementType;
  quantity_change: number;
  stock_before: number;
  stock_after: number;
  reason: string | null;
  reference: string | null;
  source_type: string | null;
  source_id: string | null;
  created_by: string | null;
  created_at: string;
}

export interface StudentsRow {
  id: string;
  student_code: string;
  first_name: string;
  last_name: string;
  gender: Gender | null;
  birth_date: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  photo_url: string | null;
  enrolled_on: string;
  status: StudentStatus;
  is_archived: boolean;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface SupplierPaymentsRow {
  id: string;
  payment_number: string;
  purchase_id: string;
  supplier_id: string;
  amount: number;
  method: PaymentMethod;
  reference: string | null;
  paid_at: string;
  status: RecordStatus;
  created_by: string | null;
  created_at: string;
}

export interface SuppliersRow {
  id: string;
  name: string;
  company: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  products_supplied: string | null;
  notes: string | null;
  is_archived: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TrainingsRow {
  id: string;
  name: string;
  description: string | null;
  duration_value: number;
  duration_unit: string;
  price: number;
  registration_fee: number;
  max_students: number | null;
  start_date: string | null;
  end_date: string | null;
  schedule: string | null;
  trainer_id: string | null;
  status: TrainingStatus;
  is_archived: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface UsersRolesRow {
  role: UserRole;
  module: string;
  can_view: boolean;
  can_create: boolean;
  can_edit: boolean;
  can_delete: boolean;
  updated_at: string;
}

export interface VCashBalanceRow {
  cash_on_hand: number | null;
  total_in: number | null;
  total_out: number | null;
}

export interface VCustomerBalancesRow {
  customer_id: string | null;
  total: number | null;
  total_paid: number | null;
  balance: number | null;
}

export interface VStaffRow {
  id: string | null;
  full_name: string | null;
  role: UserRole | null;
}

export interface VStudentBalancesRow {
  student_id: string | null;
  total_due: number | null;
  total_paid: number | null;
  balance: number | null;
}

export interface VSupplierBalancesRow {
  supplier_id: string | null;
  total_purchased: number | null;
  total_paid: number | null;
  amount_due: number | null;
}

