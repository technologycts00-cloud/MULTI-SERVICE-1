// Génère types/db.ts depuis le schéma réel (migrations rejouées sur PGlite).
// Usage : npm run db:types   (hors ligne, sans CLI Supabase)
import { PGlite } from "@electric-sql/pglite";
import { pg_trgm } from "@electric-sql/pglite/contrib/pg_trgm";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const migDir = path.join(here, "..", "supabase", "migrations");
const db = new PGlite({ extensions: { pg_trgm } });

await db.exec(`
  create role anon nologin; create role authenticated nologin; create role service_role nologin;
  create schema auth;
  create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}');
  create function auth.uid() returns uuid language sql stable as $$ select null::uuid $$;
  grant usage on schema auth, public to anon, authenticated;
`);
for (const f of fs.readdirSync(migDir).filter((x) => x.endsWith(".sql")).sort()) {
  await db.exec(fs.readFileSync(path.join(migDir, f), "utf8"));
}

const enums = (await db.query(`
  select t.typname, array_agg(e.enumlabel order by e.enumsortorder) as labels
    from pg_type t join pg_enum e on e.enumtypid = t.oid
    join pg_namespace n on n.oid = t.typnamespace
   where n.nspname = 'public' group by t.typname order by t.typname`)).rows;
const enumNames = new Set(enums.map((e) => e.typname));

const cols = (await db.query(`
  select c.table_name, c.column_name, c.data_type, c.udt_name, c.is_nullable
    from information_schema.columns c
    join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
   where c.table_schema = 'public' and t.table_type in ('BASE TABLE','VIEW')
   order by c.table_name, c.ordinal_position`)).rows;

const pascal = (s) => s.replace(/(^|_)(\w)/g, (_, __, c) => c.toUpperCase());
function tsType(c) {
  if (enumNames.has(c.udt_name)) return pascal(c.udt_name);
  switch (c.udt_name) {
    case "int2": case "int4": case "int8": case "numeric": case "float4": case "float8": return "number";
    case "bool": return "boolean";
    case "json": case "jsonb": return "Json";
    default: return "string"; // uuid, text, date, timestamptz…
  }
}

let out = `// FICHIER GÉNÉRÉ par scripts/gen-types.mjs — ne pas modifier à la main.
// Régénérer avec : npm run db:types

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

`;
for (const e of enums) {
  out += `export type ${pascal(e.typname)} = ${e.labels.map((l) => `"${l}"`).join(" | ")};\n`;
}
out += "\n";
const byTable = Map.groupBy(cols, (c) => c.table_name);
for (const [table, list] of byTable) {
  out += `export interface ${pascal(table)}Row {\n`;
  for (const c of list) out += `  ${c.column_name}: ${tsType(c)}${c.is_nullable === "YES" ? " | null" : ""};\n`;
  out += "}\n\n";
}
fs.writeFileSync(path.join(here, "..", "types", "db.ts"), out);
console.log(`types/db.ts généré (${enums.length} énumérations, ${byTable.size} tables/vues)`);
