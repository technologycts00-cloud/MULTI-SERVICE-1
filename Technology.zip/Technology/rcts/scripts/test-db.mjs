// Teste les migrations SQL sur PostgreSQL local (PGlite) en simulant Supabase.
// Usage : npm run db:test
import { PGlite } from "@electric-sql/pglite";
import { pg_trgm } from "@electric-sql/pglite/contrib/pg_trgm";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const migDir = path.join(here, "..", "supabase", "migrations");

const db = new PGlite({ extensions: { pg_trgm } });

// --- Simulation minimale de l'environnement Supabase ------------------------
await db.exec(`
  create role anon nologin;
  create role authenticated nologin;
  create role service_role nologin bypassrls;
  create schema auth;
  create table auth.users (
    id uuid primary key default gen_random_uuid(),
    email text,
    raw_user_meta_data jsonb default '{}'::jsonb
  );
  create function auth.uid() returns uuid language sql stable as
    $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
  grant usage on schema auth, public to anon, authenticated;
  grant execute on function auth.uid() to anon, authenticated;
`);

for (const f of fs.readdirSync(migDir).filter((x) => x.endsWith(".sql")).sort()) {
  try {
    await db.exec(fs.readFileSync(path.join(migDir, f), "utf8"));
    console.log(`migration OK  ${f}`);
  } catch (e) {
    console.error(`migration KO  ${f}\n  ${e.message}`);
    process.exit(1);
  }
}

// --- Outils -----------------------------------------------------------------
const q = async (sql, params) => (await db.query(sql, params)).rows;
const one = async (sql, params) => (await q(sql, params))[0];

async function as(userId, fn) {
  await db.exec(`select set_config('request.jwt.claim.sub', '${userId}', false)`);
  await db.exec("set role authenticated");
  try {
    return await fn();
  } finally {
    await db.exec("reset role");
    await db.exec("select set_config('request.jwt.claim.sub', '', false)");
  }
}

async function fails(fn, re) {
  try {
    await fn();
  } catch (e) {
    if (re) assert.match(e.message, re, `message inattendu : ${e.message}`);
    return;
  }
  assert.fail("Une erreur était attendue mais l'opération a réussi");
}

let passed = 0;
let failed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ✗ ${name}\n      ${String(e.message).split("\n")[0]}`);
  }
}
const num = (x) => Number(x);
const cashOnHand = async () => num((await one("select cash_on_hand from public.v_cash_balance")).cash_on_hand);
const stockOf = async (id) => num((await one("select current_stock from public.products where id=$1", [id])).current_stock);

// --- Utilisateurs de test ---------------------------------------------------
const U = {};
for (const role of ["ADMIN", "CAISSIER", "SECRETAIRE", "GESTIONNAIRE", "FORMATEUR", "FORMATEUR2"]) {
  const id = randomUUID();
  await db.query("insert into auth.users (id, email) values ($1, $2)", [id, `${role.toLowerCase()}@rcts.test`]);
  await db.query("update public.profiles set role = $2, full_name = $3 where id = $1", [
    id, role.replace("2", ""), role,
  ]);
  U[role] = id;
}

const ctx = {};

console.log("\nProfils et rôles");
await test("un nouveau compte démarre en SECRETAIRE (pas d'auto-promotion)", async () => {
  const id = randomUUID();
  await db.query("insert into auth.users (id, email, raw_user_meta_data) values ($1,'x@rcts.test','{\"role\":\"ADMIN\"}')", [id]);
  assert.equal((await one("select role from public.profiles where id=$1", [id])).role, "SECRETAIRE");
});
await test("un utilisateur ne peut pas changer son propre rôle", async () => {
  await fails(() => as(U.SECRETAIRE, () => q("update public.profiles set role='ADMIN' where id=$1", [U.SECRETAIRE])), /permission denied/);
});
await test("anon n'a accès à aucune table", async () => {
  await db.exec("set role anon");
  try {
    await fails(() => q("select * from public.students"), /permission denied/);
  } finally {
    await db.exec("reset role");
  }
});

console.log("\nFormations et élèves");
await test("seul un FORMATEUR/ADMIN peut être assigné comme formateur", async () => {
  await fails(() => as(U.SECRETAIRE, () => q(
    "insert into public.trainings (name,duration_value,price,trainer_id) values ('X',1,100,$1)", [U.CAISSIER])), /formateur/i);
});
await test("le secrétariat crée une formation", async () => {
  ctx.t1 = (await as(U.SECRETAIRE, () => one(
    `insert into public.trainings (name,duration_value,price,registration_fee,max_students,trainer_id,status)
     values ('Excel',3,5000,500,2,$1,'EN_COURS') returning id`, [U.FORMATEUR]))).id;
  ctx.t2 = (await as(U.SECRETAIRE, () => one(
    `insert into public.trainings (name,duration_value,price,max_students,trainer_id,status)
     values ('Word',2,3000,10,$1,'EN_COURS') returning id`, [U.FORMATEUR2]))).id;
});
await test("création d'élèves avec ID étudiant automatique", async () => {
  ctx.s = [];
  for (const [f, l] of [["Marie","Jean"],["Paul","Louis"],["Anne","Pierre"],["Luc","Joseph"]]) {
    const r = await as(U.SECRETAIRE, () => one(
      "insert into public.students (first_name,last_name) values ($1,$2) returning id, student_code", [f, l]));
    assert.match(r.student_code, /^STU-\d{4}-\d{6}$/);
    ctx.s.push(r.id);
  }
});
await test("le gestionnaire ne voit pas les élèves", async () => {
  assert.equal((await as(U.GESTIONNAIRE, () => q("select * from public.students"))).length, 0);
});

console.log("\nInscriptions et paiements");
await test("le secrétariat inscrit sans encaisser", async () => {
  const r = await as(U.SECRETAIRE, () => one("select public.enroll_student($1,$2) as r", [ctx.s[0], ctx.t1]));
  ctx.e1 = r.r.enrollment_id;
  assert.equal(r.r.total_due, 5500);
  assert.equal(r.r.balance, 5500);
});
await test("le secrétariat ne peut pas encaisser un paiement", async () => {
  await fails(() => as(U.SECRETAIRE, () => q("select public.enroll_student($1,$2,0,1000)", [ctx.s[1], ctx.t1])), /Accès refusé/);
});
await test("inscription + réduction + paiement initial → reçu RCTS-AAAA-000001", async () => {
  const r = (await as(U.CAISSIER, () => one(
    "select public.enroll_student($1,$2,500,1000,'MONCASH','MC123') as r", [ctx.s[1], ctx.t1]))).r;
  ctx.e2 = r.enrollment_id;
  assert.equal(r.total_due, 5000);           // 5000 + 500 - 500
  assert.equal(r.balance, 4000);             // SOLDE = total - réduction - payé
  assert.match(r.payment.receipt_number, /^RCTS-\d{4}-000001$/);
  const cash = await one("select * from public.cash_transactions where source_id=$1", [r.payment.payment_id]);
  assert.equal(cash.direction, "IN");
  assert.equal(cash.method, "MONCASH");
});
await test("double inscription refusée", async () => {
  await fails(() => as(U.SECRETAIRE, () => q("select public.enroll_student($1,$2)", [ctx.s[0], ctx.t1])), /déjà inscrit/);
});
await test("capacité maximale respectée", async () => {
  await fails(() => as(U.SECRETAIRE, () => q("select public.enroll_student($1,$2)", [ctx.s[2], ctx.t1])), /complète/);
});
await test("paiement partiel puis solde complet", async () => {
  const a = (await as(U.CAISSIER, () => one("select public.record_payment('INSCRIPTION',$1,2000) as r", [ctx.e1]))).r;
  assert.equal(a.balance, 3500);
  await fails(() => as(U.CAISSIER, () => q("select public.record_payment('INSCRIPTION',$1,4000)", [ctx.e1])), /dépasse/);
  await as(U.CAISSIER, () => q("select public.record_payment('INSCRIPTION',$1,3500)", [ctx.e1]));
  const e = await one("select balance, payment_status, amount_paid from public.enrollments where id=$1", [ctx.e1]);
  assert.equal(num(e.balance), 0);
  assert.equal(e.payment_status, "SOLDE");
});
await test("la caisse ne compte que les espèces (2000 + 3500)", async () => {
  assert.equal(await as(U.ADMIN, cashOnHand), 5500);
});
await test("numéros de reçu séquentiels sans trou", async () => {
  const nums = (await q("select receipt_number from public.receipts order by receipt_number")).map((r) => Number(r.receipt_number.split("-")[2]));
  assert.deepEqual(nums, nums.map((_, i) => i + 1));
});
await test("solde de l'élève (vue)", async () => {
  const b = await as(U.ADMIN, () => one("select * from public.v_student_balances where student_id=$1", [ctx.s[1]]));
  assert.equal(num(b.balance), 4000);
});

console.log("\nImmuabilité financière");
await test("paiement non modifiable, même en superutilisateur", async () => {
  await fails(() => q("update public.payments set amount=1"), /ne peut pas être modifié/);
});
await test("aucune suppression de paiement, reçu, caisse ou vente", async () => {
  for (const t of ["payments", "receipts", "cash_transactions", "enrollments"]) {
    await fails(() => q(`delete from public.${t}`), /Suppression interdite/);
  }
});
await test("le caissier ne peut pas écrire directement dans les paiements", async () => {
  await fails(() => as(U.CAISSIER, () => q("update public.payments set status='ANNULE'")), /permission denied/);
  await fails(() => as(U.CAISSIER, () => q(
    "insert into public.cash_transactions (direction,category,amount,method,source_type) values ('IN','AUTRE',9999,'ESPECES','MANUAL')")), /permission denied/);
});
await test("le secrétariat ne peut pas changer le montant payé d'une inscription", async () => {
  await fails(() => as(U.SECRETAIRE, () => q("update public.enrollments set amount_paid=0 where id=$1", [ctx.e1])), /permission denied/);
});
await test("trop de réduction ou surpaiement bloqués par contrainte", async () => {
  await fails(() => q("update public.enrollments set discount=100000 where id=$1", [ctx.e1]));
});

console.log("\nProduits, achats et stock");
await test("le gestionnaire crée catégorie, fournisseur, produit (code auto, stock 0)", async () => {
  ctx.cat = (await as(U.GESTIONNAIRE, () => one("insert into public.product_categories (name) values ('Papeterie') returning id"))).id;
  ctx.sup = (await as(U.GESTIONNAIRE, () => one("insert into public.suppliers (name,company) values ('Jean','Papeterie Sud') returning id"))).id;
  const p = await as(U.GESTIONNAIRE, () => one(
    "insert into public.products (name,category_id,sale_price,purchase_price,min_stock,supplier_id) values ('Cahier',$1,100,50,2,$2) returning id, code, current_stock",
    [ctx.cat, ctx.sup]));
  ctx.p = p.id;
  assert.match(p.code, /^PRD-\d{4}-\d{6}$/);
  assert.equal(p.current_stock, 0);
});
await test("impossible de fixer le stock à l'insertion ou à la modification", async () => {
  await fails(() => as(U.GESTIONNAIRE, () => q("insert into public.products (name,sale_price,current_stock) values ('Triche',10,99)")), /row-level security/);
});
await test("achat fournisseur : entrée de stock + paiement espèces + caisse", async () => {
  const before = await as(U.ADMIN, cashOnHand);
  const r = (await as(U.GESTIONNAIRE, () => one(
    `select public.create_purchase($1, $2::jsonb, 200) as r`,
    [ctx.sup, JSON.stringify([{ product_id: ctx.p, quantity: 10, unit_cost: 50 }])]))).r;
  ctx.pu = r.purchase_id;
  assert.equal(r.total_amount, 500);
  assert.equal(r.balance, 300);
  assert.equal(await stockOf(ctx.p), 10);
  assert.equal(await as(U.ADMIN, cashOnHand), before - 200);
});
await test("paiement du reste dû au fournisseur ; surpaiement refusé", async () => {
  await fails(() => as(U.GESTIONNAIRE, () => q("select public.pay_supplier($1, 999)", [ctx.pu])), /dépasse/);
  const r = (await as(U.GESTIONNAIRE, () => one("select public.pay_supplier($1, 300) as r", [ctx.pu]))).r;
  assert.equal(r.balance, 0);
  const v = await as(U.ADMIN, () => one("select amount_due from public.v_supplier_balances where supplier_id=$1", [ctx.sup]));
  assert.equal(num(v.amount_due), 0);
});
await test("mouvements manuels : sortie, inventaire, ajustement", async () => {
  await as(U.GESTIONNAIRE, () => q("select public.record_stock_movement($1,'SORTIE',2,'casse')", [ctx.p]));
  assert.equal(await stockOf(ctx.p), 8);
  await fails(() => as(U.GESTIONNAIRE, () => q("select public.record_stock_movement($1,'SORTIE',100,'x')", [ctx.p])), /Stock insuffisant/);
  const same = (await as(U.GESTIONNAIRE, () => one("select public.record_stock_movement($1,'INVENTAIRE',8) as r", [ctx.p]))).r;
  assert.equal(same.changed, false);
  await as(U.GESTIONNAIRE, () => q("select public.record_stock_movement($1,'INVENTAIRE',7,'comptage')", [ctx.p]));
  assert.equal(await stockOf(ctx.p), 7);
  await fails(() => as(U.GESTIONNAIRE, () => q("select public.record_stock_movement($1,'AJUSTEMENT',-1)", [ctx.p])), /motif/);
  const mv = await one("select stock_before, stock_after from public.stock_movements order by created_at desc, id limit 1");
  assert.ok(mv.stock_before !== undefined);
});
await test("le caissier ne peut pas modifier le stock", async () => {
  await fails(() => as(U.CAISSIER, () => q("select public.record_stock_movement($1,'ENTREE',5)", [ctx.p])), /Accès refusé/);
});

console.log("\nCaisse et ventes");
await test("catalogue de services (ADMIN) et client (caissier)", async () => {
  ctx.sv = (await as(U.ADMIN, () => one("insert into public.services (name,category,unit_price) values ('Photocopie','Impression',75) returning id"))).id;
  ctx.c = (await as(U.CAISSIER, () => one("insert into public.customers (name,phone) values ('Client Test','3700-0000') returning id"))).id;
  await fails(() => as(U.CAISSIER, () => q("insert into public.services (name) values ('Pirate')")), /row-level security/);
});
await test("vente : sous-total, réduction, monnaie, stock, paiement, reçu", async () => {
  const cashBefore = await as(U.ADMIN, cashOnHand);
  const items = JSON.stringify([{ product_id: ctx.p, quantity: 3 }, { service_id: ctx.sv, quantity: 1, unit_price: 50 }]);
  const r = (await as(U.CAISSIER, () => one(
    "select public.create_sale(null, $1::jsonb, 50, 500) as r", [items]))).r;
  assert.equal(r.subtotal, 350);                       // 3*100 + 50
  assert.equal(r.total, 300);                          // SOUS-TOTAL - RÉDUCTION
  assert.equal(r.change, 200);                         // MONNAIE = PAYÉ - TOTAL
  assert.equal(r.amount_paid, 300);
  assert.equal(await stockOf(ctx.p), 4);               // 7 - 3
  assert.ok(r.payment.receipt_number);
  assert.equal(await as(U.ADMIN, cashOnHand), cashBefore + 300);
  ctx.sale1 = r.sale_id;
});
await test("vente supérieure au stock refusée et rien n'est enregistré (atomicité)", async () => {
  const n0 = num((await one("select count(*) c from public.sales")).c);
  const p0 = num((await one("select count(*) c from public.payments")).c);
  await fails(() => as(U.CAISSIER, () => q(
    "select public.create_sale(null, $1::jsonb, 0, 99999)", [JSON.stringify([{ product_id: ctx.p, quantity: 50 }])])), /Stock insuffisant/);
  assert.equal(num((await one("select count(*) c from public.sales")).c), n0);
  assert.equal(num((await one("select count(*) c from public.payments")).c), p0);
  assert.equal(await stockOf(ctx.p), 4);
});
await test("le même produit sur deux lignes ne contourne pas le stock", async () => {
  await fails(() => as(U.CAISSIER, () => q(
    "select public.create_sale(null, $1::jsonb, 0, 99999)",
    [JSON.stringify([{ product_id: ctx.p, quantity: 3 }, { product_id: ctx.p, quantity: 3 }])])), /Stock insuffisant/);
  assert.equal(await stockOf(ctx.p), 4);
});
await test("vente à crédit : client obligatoire, créance, puis règlement", async () => {
  const items = JSON.stringify([{ product_id: ctx.p, quantity: 1 }]);
  await fails(() => as(U.CAISSIER, () => q("select public.create_sale(null,$1::jsonb,0,40)", [items])), /client est requis/);
  const r = (await as(U.CAISSIER, () => one("select public.create_sale($1,$2::jsonb,0,40) as r", [ctx.c, items]))).r;
  assert.equal(r.balance, 60);
  ctx.sale2 = r.sale_id;
  const b = await as(U.CAISSIER, () => one("select balance from public.v_customer_balances where customer_id=$1", [ctx.c]));
  assert.equal(num(b.balance), 60);
  const p = (await as(U.CAISSIER, () => one("select public.record_payment('VENTE',$1,60) as r", [ctx.sale2]))).r;
  assert.equal(p.balance, 0);
  assert.equal(await stockOf(ctx.p), 3);
});
await test("alertes : stock faible puis rupture", async () => {
  await as(U.CAISSIER, () => q("select public.create_sale(null,$1::jsonb,0,100)", [JSON.stringify([{ product_id: ctx.p, quantity: 1 }])]));
  assert.equal((await one("select stock_state from public.products where id=$1", [ctx.p])).stock_state, "FAIBLE");
  await as(U.CAISSIER, () => q("select public.create_sale(null,$1::jsonb,0,200)", [JSON.stringify([{ product_id: ctx.p, quantity: 2 }])]));
  assert.equal((await one("select stock_state from public.products where id=$1", [ctx.p])).stock_state, "RUPTURE");
});
await test("commande de service avec acompte ; champs financiers verrouillés", async () => {
  const r = (await as(U.CAISSIER, () => one(
    "select public.create_service_order($1,$2,2,null,null,null,'Urgent',50) as r", [ctx.c, ctx.sv]))).r;
  assert.equal(r.total, 150);
  assert.equal(r.balance, 100);
  ctx.so = r.order_id;
  await as(U.CAISSIER, () => q("update public.service_orders set status='EN_COURS' where id=$1", [ctx.so]));
  await fails(() => as(U.CAISSIER, () => q("update public.service_orders set unit_price=1 where id=$1", [ctx.so])), /permission denied/);
  await fails(() => as(U.CAISSIER, () => q("update public.service_orders set status='ANNULE' where id=$1", [ctx.so])), /Annulez d'abord/);
});
await test("facture unique par cible", async () => {
  const a = (await as(U.CAISSIER, () => one("select public.issue_invoice('SERVICE',$1) as r", [ctx.so]))).r;
  const b = (await as(U.CAISSIER, () => one("select public.issue_invoice('SERVICE',$1) as r", [ctx.so]))).r;
  assert.equal(a.invoice_id, b.invoice_id);
  assert.equal(b.existing, true);
});

console.log("\nDépenses");
await test("dépense en espèces diminue la caisse ; solde insuffisant refusé", async () => {
  const cat = (await one("select id from public.expense_categories where name='Transport'")).id;
  const before = await as(U.ADMIN, cashOnHand);
  const r = (await as(U.ADMIN, () => one("select public.record_expense($1,'Taxi livraison',1000) as r", [cat]))).r;
  ctx.exp = r.expense_id;
  assert.equal(await as(U.ADMIN, cashOnHand), before - 1000);
  await fails(() => as(U.ADMIN, () => q("select public.record_expense($1,'Trop gros',99999999)", [cat])), /Solde de caisse insuffisant/);
});
await test("dépense MonCash : dans les finances mais pas dans les espèces", async () => {
  const cat = (await one("select id from public.expense_categories where name='Internet'")).id;
  const before = await as(U.ADMIN, cashOnHand);
  await as(U.ADMIN, () => q("select public.record_expense($1,'Forfait',500,'MONCASH')", [cat]));
  assert.equal(await as(U.ADMIN, cashOnHand), before);
});
await test("seul l'ADMIN enregistre une dépense", async () => {
  const cat = (await one("select id from public.expense_categories limit 1")).id;
  await fails(() => as(U.CAISSIER, () => q("select public.record_expense($1,'x',10)", [cat])), /Accès refusé/);
});
await test("annulation de dépense : motif obligatoire, caisse rétablie", async () => {
  await fails(() => as(U.ADMIN, () => q("select public.void_expense($1,'')", [ctx.exp])), /motif/);
  const before = await as(U.ADMIN, cashOnHand);
  await as(U.ADMIN, () => q("select public.void_expense($1,'Erreur de saisie')", [ctx.exp]));
  assert.equal(await as(U.ADMIN, cashOnHand), before + 1000);
});

console.log("\nAnnulations (jamais de suppression)");
await test("seul l'ADMIN annule ; motif obligatoire", async () => {
  await fails(() => as(U.CAISSIER, () => q("select public.void_sale($1,'x')", [ctx.sale2])), /Accès refusé/);
  await fails(() => as(U.ADMIN, () => q("select public.void_sale($1,'')", [ctx.sale2])), /motif/);
});
await test("annulation d'une vente : paiements annulés, stock réintégré, caisse corrigée", async () => {
  const stock0 = await stockOf(ctx.p);
  const cash0 = await as(U.ADMIN, cashOnHand);
  await as(U.ADMIN, () => q("select public.void_sale($1,'Retour client')", [ctx.sale2]));
  const s = await one("select status, amount_paid from public.sales where id=$1", [ctx.sale2]);
  assert.equal(s.status, "ANNULE");
  assert.equal(num(s.amount_paid), 0);
  assert.equal(await stockOf(ctx.p), stock0 + 1);
  assert.equal(await as(U.ADMIN, cashOnHand), cash0 - 100);       // 40 + 60 remboursés
  assert.equal((await one("select count(*) c from public.receipts where status='ANNULE'")).c, 2);
  await fails(() => as(U.ADMIN, () => q("select public.void_sale($1,'bis')", [ctx.sale2])), /déjà annulée/);
});
await test("annulation d'un paiement d'inscription : solde rétabli", async () => {
  const p = await one("select id from public.payments where enrollment_id=$1 and status='VALIDE' order by paid_at limit 1", [ctx.e1]);
  await as(U.ADMIN, () => q("select public.void_payment($1,'Mauvais montant')", [p.id]));
  const e = await one("select balance from public.enrollments where id=$1", [ctx.e1]);
  assert.equal(num(e.balance), 2000 + 0);  // 5500 - 3500 restant payé
});

console.log("\nSécurité du stock");
await test("le stock ne se modifie jamais directement (gestionnaire, caissier, ADMIN)", async () => {
  const before = await stockOf(ctx.p);
  for (const u of [U.GESTIONNAIRE, U.ADMIN, U.CAISSIER]) {
    await fails(() => as(u, () => q("update public.products set current_stock = 999 where id=$1", [ctx.p])));
  }
  assert.equal(await stockOf(ctx.p), before);
});
await test("les autres champs du produit restent modifiables par le gestionnaire", async () => {
  await as(U.GESTIONNAIRE, () => q("update public.products set sale_price = 110, min_stock = 3 where id=$1", [ctx.p]));
  const p = await one("select sale_price, min_stock from public.products where id=$1", [ctx.p]);
  assert.equal(num(p.sale_price), 110);
  await as(U.GESTIONNAIRE, () => q("update public.products set sale_price = 100, min_stock = 2 where id=$1", [ctx.p]));
});

console.log("\nRLS par rôle");
await test("le secrétariat ne voit que les paiements d'inscription", async () => {
  const kinds = (await as(U.SECRETAIRE, () => q("select distinct kind from public.payments"))).map((r) => r.kind);
  assert.deepEqual(kinds, ["INSCRIPTION"]);
  assert.equal((await as(U.SECRETAIRE, () => q("select * from public.sales"))).length, 0);
});
await test("le formateur ne voit que les élèves de ses formations", async () => {
  await as(U.SECRETAIRE, () => q("select public.enroll_student($1,$2)", [ctx.s[3], ctx.t2]));
  const f1 = await as(U.FORMATEUR, () => q("select id from public.students"));
  const f2 = await as(U.FORMATEUR2, () => q("select id from public.students"));
  assert.equal(f1.length, 2);
  assert.equal(f2.length, 1);
  assert.equal((await as(U.FORMATEUR, () => q("select * from public.payments"))).length, 0);
});
await test("le gestionnaire ne voit pas la caisse (la vue ne divulgue rien)", async () => {
  assert.equal((await as(U.GESTIONNAIRE, () => q("select * from public.cash_transactions"))).length, 0);
  assert.equal(await as(U.GESTIONNAIRE, cashOnHand), 0);
});
await test("le caissier ne voit ni dépenses ni achats", async () => {
  assert.equal((await as(U.CAISSIER, () => q("select * from public.expenses"))).length, 0);
  assert.equal((await as(U.CAISSIER, () => q("select * from public.purchases"))).length, 0);
});

console.log("\nPhase 5 — lectures paiements / caisse");
await test("list_payments : total, pagination, filtres et recherche sûre", async () => {
  const dbTotal = num((await one("select count(*) c from public.payments")).c);
  const all = (await as(U.ADMIN, () => one("select public.list_payments(p_limit=>5) as r"))).r;
  assert.equal(num(all.total), dbTotal);
  assert.ok(all.rows.length <= 5);
  const p2 = (await as(U.ADMIN, () => one("select public.list_payments(p_limit=>1,p_offset=>1) as r"))).r;
  assert.equal(p2.rows.length, dbTotal > 1 ? 1 : 0);
  const vente = (await as(U.ADMIN, () => one("select public.list_payments(p_kind=>'VENTE') as r"))).r;
  const dbVente = num((await one("select count(*) c from public.payments where kind='VENTE'")).c);
  assert.equal(num(vente.total), dbVente);
  const wild = (await as(U.ADMIN, () => one("select public.list_payments(p_q=>'%') as r"))).r;
  assert.equal(num(wild.total), 0, "le % ne doit pas servir de joker");
  const sec = (await as(U.SECRETAIRE, () => one("select public.list_payments(p_limit=>100) as r"))).r;
  assert.ok(sec.rows.every((r) => r.kind === "INSCRIPTION"));
});
await test("receipt_data : visibilité par rôle", async () => {
  const rc = await one("select r.id, p.kind from public.receipts r join public.payments p on p.id=r.payment_id order by r.issued_at limit 50");
  const rows = await q("select r.id, p.kind from public.receipts r join public.payments p on p.id=r.payment_id");
  const insc = rows.find((x) => x.kind === "INSCRIPTION");
  const vente = rows.find((x) => x.kind === "VENTE");
  assert.ok(rc && insc && vente);
  const a = (await as(U.CAISSIER, () => one("select public.receipt_data($1) as r", [vente.id]))).r;
  assert.ok(a && a.receipt && a.org && a.payment);
  assert.ok((await as(U.SECRETAIRE, () => one("select public.receipt_data($1) as r", [insc.id]))).r);
  assert.equal((await as(U.SECRETAIRE, () => one("select public.receipt_data($1) as r", [vente.id]))).r, null);
  assert.equal((await as(U.FORMATEUR, () => one("select public.receipt_data($1) as r", [vente.id]))).r, null);
});
await test("pos_catalog, search_customers, list_receivables", async () => {
  const cat = (await as(U.CAISSIER, () => one("select public.pos_catalog() as r"))).r;
  assert.ok(JSON.stringify(cat).length > 2);
  const rec = (await as(U.CAISSIER, () => one("select public.list_receivables() as r"))).r;
  assert.ok(rec && Array.isArray(rec.rows ?? rec));
  const c = (await as(U.CAISSIER, () => one("select public.search_customers('') as r"))).r;
  assert.ok(Array.isArray(c.items ?? c.rows ?? c));
});
await test("cash_overview et list_cash_transactions cohérents avec la caisse", async () => {
  const ov = (await as(U.ADMIN, () => one("select public.cash_overview() as r"))).r;
  assert.equal(num(ov.cash_on_hand), await cashOnHand());
  const l = (await as(U.ADMIN, () => one("select public.list_cash_transactions(p_limit=>100) as r"))).r;
  const dbN = num((await one("select count(*) c from public.cash_transactions")).c);
  assert.equal(num(l.total), dbN);
  const esp = (await as(U.ADMIN, () => one("select public.list_cash_transactions(p_method=>'ESPECES',p_include_void=>false) as r"))).r;
  assert.equal(num(esp.sum_in) - num(esp.sum_out), await cashOnHand());
  assert.equal(num((await as(U.GESTIONNAIRE, () => one("select public.list_cash_transactions() as r"))).r.total), 0);
});

console.log("\nFinances");
await test("finance_summary : recettes − dépenses = solde, cohérent avec la caisse", async () => {
  const f = (await as(U.ADMIN, () => one("select public.finance_summary() as r"))).r;
  const inT = num((await one("select coalesce(sum(amount),0) s from public.cash_transactions where status='VALIDE' and direction='IN'")).s);
  const outT = num((await one("select coalesce(sum(amount),0) s from public.cash_transactions where status='VALIDE' and direction='OUT'")).s);
  assert.equal(num(f.income), inT);
  assert.equal(num(f.expenses), outT);
  assert.equal(num(f.balance), inT - outT);
  const sumOf = (arr, k) => arr.reduce((a, x) => a + num(x[k]), 0);
  assert.equal(sumOf(f.income_by_category, "total"), inT);
  assert.equal(sumOf(f.income_by_method, "total"), inT);
  assert.equal(sumOf(f.expenses_by_category, "total"), outT);
  assert.equal(sumOf(f.monthly, "income"), inT);
  assert.equal(sumOf(f.monthly, "expenses"), outT);
  assert.equal(num(f.cash_on_hand), await as(U.ADMIN, cashOnHand));
});
await test("finance_summary : créances et dettes alignées sur les tables", async () => {
  const f = (await as(U.ADMIN, () => one("select public.finance_summary() as r"))).r;
  const recv = num((await one(`select (select coalesce(sum(balance),0) from public.enrollments where status<>'ANNULEE')
    + (select coalesce(sum(balance),0) from public.sales where status='VALIDE')
    + (select coalesce(sum(balance),0) from public.service_orders where status<>'ANNULE') s`)).s);
  assert.equal(num(f.receivables.total), recv);
  assert.equal(num(f.receivables.formations) + num(f.receivables.ventes) + num(f.receivables.services), recv);
  const debt = num((await one("select coalesce(sum(balance),0) s from public.purchases where status='VALIDE'")).s);
  assert.equal(num(f.payables.total), debt);
});
await test("finance_summary : filtre de période et accès ADMIN seulement", async () => {
  const none = (await as(U.ADMIN, () => one("select public.finance_summary('2000-01-01','2000-12-31') as r"))).r;
  assert.equal(num(none.income), 0);
  assert.equal(num(none.expenses), 0);
  const today = (await as(U.ADMIN, () => one("select public.finance_summary(current_date - 1, current_date + 1) as r"))).r;
  const all = (await as(U.ADMIN, () => one("select public.finance_summary() as r"))).r;
  assert.equal(num(today.income), num(all.income));
  await fails(() => as(U.ADMIN, () => q("select public.finance_summary('2026-02-01','2026-01-01')")), /précède/);
  for (const r of ["CAISSIER", "SECRETAIRE", "GESTIONNAIRE", "FORMATEUR"]) {
    await fails(() => as(U[r], () => q("select public.finance_summary()")), /Accès refusé/);
  }
});

console.log("\nRapports");
const rep = (uid, type, from = null, to = null) => as(uid, async () => (await one("select public.report_data($1,$2,$3) as r", [type, from, to])).r);
await test("les 9 rapports ADMIN : colonnes, lignes et résumé cohérents", async () => {
  for (const t of ["caisse", "ventes", "paiements", "formations", "inscriptions", "eleves", "stock", "depenses", "financier"]) {
    const r = await rep(U.ADMIN, t);
    assert.equal(r.type, t);
    assert.ok(r.title && r.columns.length > 0 && Array.isArray(r.rows) && Array.isArray(r.summary), t);
    for (const row of r.rows) for (const c of r.columns) assert.ok(c.key in row, `${t}: colonne ${c.key} absente`);
    assert.ok(r.rows.every((x) => !("sort" in x)), `${t}: colonne technique exposée`);
  }
});
await test("rapports : totaux égaux aux tables", async () => {
  const sumOf = (r, label) => num(r.summary.find((x) => x.label === label).value);
  const c = await rep(U.ADMIN, "caisse");
  assert.equal(sumOf(c, "Entrées"), num((await one("select coalesce(sum(amount),0) s from public.cash_transactions where direction='IN' and status='VALIDE'")).s));
  assert.equal(c.rows.length, num((await one("select count(*) c from public.cash_transactions")).c));
  const v = await rep(U.ADMIN, "ventes");
  assert.equal(sumOf(v, "Total des ventes"), num((await one("select coalesce(sum(total),0) s from public.sales where status='VALIDE'")).s));
  const pa = await rep(U.ADMIN, "paiements");
  assert.equal(sumOf(pa, "Total encaissé"), num((await one("select coalesce(sum(amount),0) s from public.payments where status='VALIDE'")).s));
  const i = await rep(U.ADMIN, "inscriptions");
  assert.equal(sumOf(i, "Solde à recevoir"), num((await one("select coalesce(sum(balance),0) s from public.enrollments where status<>'ANNULEE'")).s));
  const d = await rep(U.ADMIN, "depenses");
  assert.equal(sumOf(d, "Total des dépenses"), num((await one("select coalesce(sum(amount),0) s from public.expenses where status='VALIDE'")).s));
  const st = await rep(U.ADMIN, "stock");
  assert.equal(sumOf(st, "Valeur du stock (prix d'achat)"), num((await one("select coalesce(sum(current_stock*purchase_price),0) s from public.products where status='ACTIF'")).s));
  const f = await rep(U.ADMIN, "financier");
  assert.equal(sumOf(f, "Solde (recettes − dépenses)"), sumOf(f, "Recettes") - sumOf(f, "Dépenses"));
  assert.equal(f.rows.reduce((a, x) => a + num(x.solde), 0), sumOf(f, "Solde (recettes − dépenses)"));
});
await test("rapports : filtre de période et dates invalides", async () => {
  const old = await rep(U.ADMIN, "ventes", "2000-01-01", "2000-12-31");
  assert.equal(old.rows.length, 0);
  assert.equal(num(old.summary.find((x) => x.label === "Total des ventes").value), 0);
  const day = await rep(U.ADMIN, "caisse", new Date(Date.now() - 86400000).toISOString().slice(0, 10), new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10));
  assert.ok(day.rows.length > 0);
  await fails(() => as(U.ADMIN, () => q("select public.report_data('caisse','2026-02-01','2026-01-01')")), /précède/);
  await fails(() => as(U.ADMIN, () => q("select public.report_data('inconnu')")), /Accès refusé/);
});
await test("rapports : accès par rôle", async () => {
  await fails(() => rep(U.CAISSIER, "depenses"), /Accès refusé/);
  await fails(() => rep(U.CAISSIER, "financier"), /Accès refusé/);
  await fails(() => rep(U.SECRETAIRE, "caisse"), /Accès refusé/);
  await fails(() => rep(U.GESTIONNAIRE, "ventes"), /Accès refusé/);
  assert.ok((await rep(U.CAISSIER, "ventes")).rows.length > 0);
  assert.ok((await rep(U.GESTIONNAIRE, "stock")).rows.length > 0);
  assert.ok((await rep(U.SECRETAIRE, "eleves")).rows.length > 0);
  const form = await rep(U.FORMATEUR, "eleves");
  const all = await rep(U.ADMIN, "eleves");
  assert.ok(form.rows.length <= all.rows.length);
  await db.exec("set role anon");
  try { await fails(() => q("select public.report_data('caisse')"), /permission denied/); }
  finally { await db.exec("reset role"); }
});

console.log("\nPhase 10 — utilisateurs, matrice, paramètres");
await test("ADMIN change rôle et statut ; l'action est journalisée", async () => {
  await as(U.ADMIN, () => q("select public.admin_update_user($1,'Secrétaire Test','GESTIONNAIRE',true)", [U.SECRETAIRE]));
  const p = await one("select role, full_name from public.profiles where id=$1", [U.SECRETAIRE]);
  assert.equal(p.role, "GESTIONNAIRE");
  assert.equal(p.full_name, "Secrétaire Test");
  const log = await as(U.ADMIN, () => one("select * from public.audit_logs where module='profiles' and record_id=$1 and action='UPDATE' order by id desc limit 1", [U.SECRETAIRE]));
  assert.equal(log.new_value.role, "GESTIONNAIRE");
  assert.equal(log.user_id, U.ADMIN);
  await as(U.ADMIN, () => q("select public.admin_update_user($1,null,'SECRETAIRE',true)", [U.SECRETAIRE]));
});
await test("un non-ADMIN ne peut pas appeler admin_update_user", async () => {
  await fails(() => as(U.CAISSIER, () => q("select public.admin_update_user($1,null,'ADMIN',true)", [U.CAISSIER])), /Accès refusé/);
});
await test("garde-fous : pas d'auto-modification, au moins un ADMIN actif", async () => {
  await fails(() => as(U.ADMIN, () => q("select public.admin_update_user($1,null,'CAISSIER',true)", [U.ADMIN])), /propre rôle/);
  await fails(() => as(U.ADMIN, () => q("select public.admin_update_user($1,null,'ADMIN',false)", [U.ADMIN])), /propre rôle/);
  const a2 = randomUUID();
  await db.query("insert into auth.users (id, email) values ($1, 'admin2@rcts.test')", [a2]);
  await as(U.ADMIN, () => q("select public.admin_update_user($1,'Admin 2','ADMIN',true)", [a2]));
  // le second ADMIN peut rétrograder le premier ; ensuite il est seul et ne peut plus se retirer
  await as(a2, () => q("select public.admin_update_user($1,null,'CAISSIER',true)", [U.ADMIN]));
  await fails(() => as(a2, () => q("select public.admin_update_user($1,null,'CAISSIER',true)", [a2])), /propre rôle/);
  await db.query("update public.profiles set role='ADMIN' where id=$1", [U.ADMIN]);
  await db.query("update public.profiles set role='CAISSIER', is_active=false where id=$1", [a2]);
});
await test("un compte désactivé perd tout accès", async () => {
  await db.query("update public.profiles set is_active=false where id=$1", [U.FORMATEUR2]);
  assert.equal((await as(U.FORMATEUR2, () => q("select * from public.trainings"))).length, 0);
  await db.query("update public.profiles set is_active=true where id=$1", [U.FORMATEUR2]);
});
await test("matrice : l'ADMIN règle les autres rôles, jamais les droits ADMIN", async () => {
  await as(U.ADMIN, () => q("update public.users_roles set can_view=false where role='CAISSIER' and module='services'"));
  assert.equal((await one("select can_view from public.users_roles where role='CAISSIER' and module='services'")).can_view, false);
  await as(U.ADMIN, () => q("update public.users_roles set can_view=true where role='CAISSIER' and module='services'"));
  await fails(() => as(U.ADMIN, () => q("update public.users_roles set can_view=false where role='ADMIN' and module='parametres'")), /ne sont pas modifiables/);
  await as(U.CAISSIER, () => q("update public.users_roles set can_view=false where role='SECRETAIRE'")).catch(() => {});
  assert.equal((await one("select count(*)::int n from public.users_roles where role='SECRETAIRE' and not can_view")).n, 0);
  assert.equal((await one("select count(*)::int n from public.users_roles where role='CAISSIER' and module in ('clients','services','rapports')")).n, 3);
});
await test("paramètres : ADMIN seulement, préfixes validés, auteur tracé", async () => {
  await as(U.ADMIN, () => q("update public.settings set value=to_jsonb('R.CTS Les Anglais'::text) where key='org_name'"));
  const s = await one("select updated_by, value #>> '{}' v from public.settings where key='org_name'");
  assert.equal(s.updated_by, U.ADMIN);
  assert.equal(s.v, "R.CTS Les Anglais");
  await fails(() => as(U.ADMIN, () => q("update public.settings set value=to_jsonb('rc ts!'::text) where key='receipt_prefix'")), /Préfixe invalide/);
  await as(U.ADMIN, () => q("update public.settings set value=to_jsonb('RCTS'::text) where key='receipt_prefix'"));
  await as(U.CAISSIER, () => q("update public.settings set value=to_jsonb('X'::text) where key='org_name'"));
  assert.equal((await one("select value #>> '{}' v from public.settings where key='org_name'")).v, "R.CTS Les Anglais");
});

console.log("\nAudit");
await test("les actions sont journalisées avec utilisateur et valeurs", async () => {
  const log = await as(U.ADMIN, () => one(
    "select * from public.audit_logs where module='payments' and action='INSERT' and user_id=$1 limit 1", [U.CAISSIER]));
  assert.ok(log.new_value.amount);
  const upd = await as(U.ADMIN, () => one("select * from public.audit_logs where module='payments' and action='UPDATE' limit 1"));
  assert.ok(upd.old_value && upd.new_value);
});
await test("le journal est lisible par l'ADMIN seulement et immuable", async () => {
  assert.equal((await as(U.CAISSIER, () => q("select * from public.audit_logs"))).length, 0);
  await fails(() => q("update public.audit_logs set action='X'"), /immuable/);
  await fails(() => q("delete from public.audit_logs"), /Suppression interdite/);
});

console.log("\nDashboard");
const dash = (uid) => as(uid, async () => (await one("select public.dashboard_stats() as d")).d);
await test("ADMIN : chiffres cohérents avec la caisse et les tables", async () => {
  const d = await dash(U.ADMIN);
  const sum = async (sql) => num((await one(sql)).s);
  assert.equal(d.role, "ADMIN");
  assert.equal(d.finance.cash_balance, await as(U.ADMIN, cashOnHand));
  const inTotal = await sum("select coalesce(sum(amount),0) s from public.cash_transactions where direction='IN' and status='VALIDE'");
  assert.equal(d.finance.revenue_month, inTotal);           // tout a été créé ce mois-ci
  assert.equal(d.finance.revenue_today, inTotal);
  assert.equal(d.finance.total_payments, await sum("select coalesce(sum(amount),0) s from public.payments where status='VALIDE'"));
  assert.equal(d.finance.total_expenses, await sum("select coalesce(sum(amount),0) s from public.expenses where status='VALIDE'"));
  const recv = await sum(`select (select coalesce(sum(balance),0) from public.enrollments where status<>'ANNULEE')
    + (select coalesce(sum(balance),0) from public.sales where status='VALIDE')
    + (select coalesce(sum(balance),0) from public.service_orders where status<>'ANNULE') s`);
  assert.equal(d.finance.receivables, recv);
  assert.ok(d.finance.receivables > 0 && d.finance.pending_count > 0);
});
await test("séries : 12 mois, totaux égaux aux totaux globaux", async () => {
  const d = await dash(U.ADMIN);
  for (const k of ["revenue", "expenses", "enrollments", "sales"]) assert.equal(d.charts[k].length, 12, k);
  const months = d.charts.revenue.map((x) => x.month);
  assert.deepEqual(months, [...months].sort());
  const sumOf = (arr, f) => arr.reduce((a, x) => a + num(x[f]), 0);
  assert.equal(sumOf(d.charts.revenue, "total"), d.finance.revenue_month);
  assert.equal(sumOf(d.charts.by_category, "total"), d.finance.revenue_month);
  assert.equal(sumOf(d.charts.expenses, "total"), d.finance.total_expenses);
  assert.equal(sumOf(d.charts.enrollments, "count"), d.school.new_enrollments_month);
  assert.equal(d.charts.revenue.at(-1).month, new Date().toISOString().slice(0, 7));
});
await test("élèves, stock et transactions récentes", async () => {
  const d = await dash(U.ADMIN);
  assert.equal(d.school.students_total, num((await one("select count(*) c from public.students")).c));
  assert.ok(d.school.students_active <= d.school.students_total);
  const cnt = async (state) => num((await one("select count(*) c from public.products where status='ACTIF' and stock_state=$1", [state])).c);
  assert.equal(d.stock.low_stock, await cnt("FAIBLE"));
  assert.equal(d.stock.out_of_stock, await cnt("RUPTURE"));
  assert.equal(d.stock.low_stock + d.stock.out_of_stock, 1);  // « Cahier » : 1 en stock, minimum 2 → faible
  assert.equal(d.stock.alerts[0].stock_state, "FAIBLE");
  assert.ok(d.recent.length > 0 && d.recent.length <= 10);
  const dates = d.recent.map((r) => r.occurred_at);
  assert.deepEqual(dates, [...dates].sort().reverse());
  assert.ok(d.recent.some((r) => r.user_name === "CAISSIER"));
  assert.ok(d.recent.some((r) => r.status === "ANNULE"));   // les annulations restent visibles
});
await test("CAISSIER : finances et stock, sans dépenses ni élèves", async () => {
  const d = await dash(U.CAISSIER);
  assert.ok(d.finance && d.stock && d.recent);
  assert.equal(d.finance.total_expenses, null);
  assert.equal(d.charts.expenses, null);
  assert.equal(d.school, null);
});
await test("SECRETAIRE : élèves seulement", async () => {
  const d = await dash(U.SECRETAIRE);
  assert.ok(d.school);
  assert.equal(d.finance, null);
  assert.equal(d.stock, null);
  assert.equal(d.recent, null);
  assert.equal(d.charts.revenue, null);
});
await test("GESTIONNAIRE : stock seulement", async () => {
  const d = await dash(U.GESTIONNAIRE);
  assert.ok(d.stock);
  assert.equal(d.finance, null);
  assert.equal(d.school, null);
});
await test("FORMATEUR : uniquement ses propres élèves", async () => {
  const d = await dash(U.FORMATEUR);
  assert.equal(d.school.students_total, 2);
  assert.equal(d.finance, null);
  const d2 = await dash(U.FORMATEUR2);
  assert.equal(d2.school.students_total, 1);
});
await test("anonyme et utilisateur sans profil refusés", async () => {
  await db.exec("set role anon");
  try { await fails(() => q("select public.dashboard_stats()"), /permission denied/); }
  finally { await db.exec("reset role"); }
  const ghost = randomUUID();
  await fails(() => as(ghost, () => q("select public.dashboard_stats()")), /Accès refusé/);
  await db.query("insert into auth.users (id,email) values ($1,'off@rcts.test')", [ghost]);
  await db.query("update public.profiles set is_active=false where id=$1", [ghost]);
  await fails(() => as(ghost, () => q("select public.dashboard_stats()")), /Accès refusé/);
});

if (process.env.DASH_SAMPLE_DIR) {
  fs.mkdirSync(process.env.DASH_SAMPLE_DIR, { recursive: true });
  for (const r of ["ADMIN", "CAISSIER", "GESTIONNAIRE"]) {
    fs.writeFileSync(path.join(process.env.DASH_SAMPLE_DIR, `${r}.json`), JSON.stringify(await dash(U[r])));
  }
  // Lignes brutes pour le contrôle visuel des modules (élèves, formations, inscriptions)
  const dump = {};
  for (const t of ["students", "trainings", "enrollments", "payments", "receipts", "certificates"]) {
    dump[t] = (await q(
      `select to_jsonb(x) as r from public.${t} x order by coalesce(to_jsonb(x)->>'created_at', to_jsonb(x)->>'issued_at'), x.id`,
    )).map((r) => r.r);
  }
  dump.staff = await q("select id, full_name, role from public.v_staff");
  fs.writeFileSync(path.join(process.env.DASH_SAMPLE_DIR, "phase4.json"), JSON.stringify(dump));
}

console.log(`\n${passed} tests réussis, ${failed} échoués`);
process.exit(failed ? 1 : 0);
