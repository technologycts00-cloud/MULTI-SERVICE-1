# R.CTS — R.COMPLEX TECHNOLOGY SERVICES

Plateforme de gestion (Next.js 16 · TypeScript · Tailwind · Supabase · PWA installable sur Android).
Devise : HTG. Interface en français.

## Démarrage

1. Créez un projet sur [supabase.com](https://supabase.com).
2. Copiez `.env.example` vers `.env.local` et renseignez les clés (Supabase > Project Settings > API).
   `SUPABASE_SERVICE_ROLE_KEY` reste **côté serveur** (jamais de préfixe `NEXT_PUBLIC_`) ; elle sert uniquement
   à créer des comptes depuis la page Utilisateurs.
3. Dans Supabase > SQL Editor, exécutez les fichiers de `supabase/migrations/` **dans l'ordre** (0001 → 0013).
   Ils ne sont pas rejouables : exécutez chaque fichier une seule fois.
   La migration 0008 crée aussi le bucket privé `student-photos`.
4. Dans Supabase > Authentication > Users, créez votre compte, puis promouvez-le :
   ```sql
   update public.profiles set role = 'ADMIN' where email = 'votre@email.com';
   ```
5. Dans Supabase > Authentication > URL Configuration, ajoutez `http://localhost:3000/auth/callback`
   (et l'adresse de production) aux URLs de redirection.
6. `npm install` puis `npm run dev` → http://localhost:3000
   Production : `npm run build && npm start` (le service worker PWA ne s'active qu'en production, en HTTPS).

Ensuite, dans l'application : **Paramètres** (nom, adresse, logo, préfixes) puis **Utilisateurs** (créer les comptes).

## Modules

| Module | Contenu | Rôles |
|---|---|---|
| Dashboard | indicateurs, 5 graphiques, transactions récentes, alertes de stock | tous (chiffres filtrés par rôle) |
| Élèves, Formations, Inscriptions | fiches, photos, capacité, remises, certificats | ADMIN, SECRETAIRE (FORMATEUR : ses élèves) |
| Paiements, Caisse | historique, annulation motivée, caisse POS, journal, reçus A5 / ticket (impression + PDF) | ADMIN, CAISSIER |
| Ventes, Produits, Stock | ventes atomiques, catégories, mouvements, alertes | ADMIN, CAISSIER / GESTIONNAIRE |
| Clients, Services | clients, commandes de service, factures | ADMIN, CAISSIER |
| Fournisseurs | achats, dettes, paiements fournisseurs | ADMIN, GESTIONNAIRE |
| Dépenses, Finances | dépenses par catégorie, recettes − dépenses, créances, dettes, journal financier | ADMIN |
| Rapports | 9 rapports, filtres de période, impression, PDF, Excel, CSV | selon le rôle |
| Utilisateurs | comptes, rôles, statut, lien de réinitialisation, matrice de permissions, **journal d'audit** | ADMIN |
| Paramètres | identité de l'entreprise, logo, préfixes de numérotation | ADMIN |

Numéros : reçus `RCTS-2026-000001` (préfixe et année configurables), factures `FAC-…`, sans trou.

## Structure

```
app/(auth)           connexion, mot de passe oublié, réinitialisation
app/(app)            zone protégée : un dossier par module (pages + actions serveur)
app/manifest.ts      manifeste PWA ; public/sw.js service worker ; app/hors-ligne page de secours
components/          ui, layout, shared, un dossier par module
lib/                 supabase, permissions, validations (Zod), labels, reports, pdf
services/            accès aux données par module (RPC et requêtes)
supabase/migrations  schéma, triggers, RPC, RLS, seed, vues (0001 → 0013)
scripts/             test-db.mjs (tests SQL), gen-types.mjs
proxy.ts             protection des routes (remplace middleware.ts dans Next 16)
```

## Sécurité

- **RLS partout** ; aucune écriture financière directe : tout passe par des fonctions SQL atomiques
  (`create_sale`, `enroll_student`, `record_payment`, `record_expense`, `create_purchase`…).
- Paiements, reçus, caisse, ventes, dépenses : **jamais supprimés ni modifiés** ; un ADMIN peut les annuler avec motif.
- Journal d'audit immuable (qui, quoi, avant/après) sur 23 tables, lisible par l'ADMIN seulement.
- Rôle d'un compte modifiable uniquement par `admin_update_user` (pas d'auto-promotion, au moins un ADMIN actif).
- La matrice de permissions ne peut que **masquer** des modules ; les droits réels restent ceux de la RLS.
- En-têtes de sécurité (nosniff, anti-iframe, HSTS…) ; le service worker ne met en cache aucune donnée métier.
- Exports CSV/Excel : cellules texte neutralisées contre l'injection de formules.

## Règles financières

- Le solde de caisse ne compte que les **espèces** ; MonCash, NatCash et virement figurent dans les finances.
- Chiffre d'affaires = encaissements valides (toutes méthodes). Créances = soldes non annulés
  (inscriptions, ventes, services). Jours et mois calculés à l'heure d'Haïti.
- TOTAL = SOUS-TOTAL − RÉDUCTION ; MONNAIE = MONTANT PAYÉ − TOTAL.

## Tests

`npm run db:test` rejoue les 13 migrations sur PostgreSQL local (PGlite, sans compte Supabase) et exécute
75 scénarios : calculs, atomicité, stock, droits par rôle, immuabilité, audit, finances, rapports, dashboard,
administration des utilisateurs. `npm run db:types` régénère `types/db.ts`.
Vérifications de code : `npx tsc --noEmit` et `npm run build`.
