import { ArrowDownCircle, ArrowUpCircle } from "lucide-react";
import { StatusBadge } from "@/components/ui/badge";
import { CASH_CATEGORY, METHOD_LABELS, RECORD_STATUS } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { CashTx } from "@/services/payments";

export function CashTable({ rows }: { rows: CashTx[] }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucune opération trouvée.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Opération</th>
              <th className="px-4 py-3">Catégorie</th>
              <th className="px-4 py-3">Mode</th>
              <th className="px-4 py-3 text-right">Montant</th>
              <th className="px-4 py-3">Par</th>
              <th className="px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((t) => {
              const inn = t.direction === "IN";
              return (
                <tr key={t.id} className={cn("hover:bg-muted/50", t.status === "ANNULE" && "text-muted-foreground")}>
                  <td className="whitespace-nowrap px-4 py-3">{formatDateTime(t.occurred_at)}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center gap-2">
                      {inn ? <ArrowDownCircle className="size-4 text-success" aria-label="Entrée" /> : <ArrowUpCircle className="size-4 text-destructive" aria-label="Sortie" />}
                      {t.description ?? "—"}
                    </span>
                  </td>
                  <td className="px-4 py-3">{CASH_CATEGORY[t.category] ?? t.category}</td>
                  <td className="px-4 py-3">{METHOD_LABELS[t.method] ?? t.method}</td>
                  <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", t.status === "VALIDE" ? (inn ? "text-success" : "text-destructive") : "line-through")}>
                    {inn ? "+" : "−"} {formatHTG(t.amount)}
                  </td>
                  <td className="px-4 py-3">{t.user_name ?? "—"}</td>
                  <td className="px-4 py-3"><StatusBadge map={RECORD_STATUS} value={t.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
