"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { Minus, Pencil, Plus, Printer, Search, Trash2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS, STOCK_STATE } from "@/lib/labels";
import { cn, formatHTG } from "@/lib/utils";
import type { CatalogItem, CustomerOption } from "@/services/payments";
import type { SaleResult } from "@/app/(app)/caisse/actions";

interface CartLine {
  key: string;
  type: "product" | "service";
  id: string;
  name: string;
  quantity: number;
  unit_price: number;
  max?: number | null; // stock disponible (produits)
  editablePrice: boolean;
}

const num = (v: string) => {
  const n = Number(v.replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? n : 0;
};

export function Pos({
  initialCatalog,
  searchCatalog,
  searchCustomers,
  save,
}: {
  initialCatalog: CatalogItem[];
  searchCatalog: (q: string) => Promise<ActionResult<{ items: CatalogItem[] }>>;
  searchCustomers: (q: string) => Promise<ActionResult<{ items: CustomerOption[] }>>;
  save: (raw: unknown) => Promise<ActionResult<SaleResult>>;
}) {
  const [catalog, setCatalog] = useState(initialCatalog);
  const [q, setQ] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [discount, setDiscount] = useState("0");
  const [tendered, setTendered] = useState("");
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [customer, setCustomer] = useState<CustomerOption | null>(null);
  const [cq, setCq] = useState("");
  const [cResults, setCResults] = useState<CustomerOption[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<SaleResult | null>(null);
  const [pending, start] = useTransition();
  const seq = useRef(0);

  useEffect(() => {
    const n = ++seq.current;
    const t = setTimeout(async () => {
      const res = await searchCatalog(q);
      if (n === seq.current && res.ok) setCatalog(res.items);
    }, 250);
    return () => clearTimeout(t);
  }, [q, searchCatalog]);

  useEffect(() => {
    const t = setTimeout(async () => {
      if (cq.trim().length < 2) return setCResults([]);
      const res = await searchCustomers(cq);
      if (res.ok) setCResults(res.items);
    }, 250);
    return () => clearTimeout(t);
  }, [cq, searchCustomers]);

  const subtotal = useMemo(() => cart.reduce((s, l) => s + l.quantity * l.unit_price, 0), [cart]);
  const disc = Math.min(num(discount), subtotal);
  const total = Math.max(subtotal - disc, 0); // TOTAL = SOUS-TOTAL − RÉDUCTION
  const paid = tendered.trim() === "" ? total : num(tendered);
  const change = Math.max(paid - total, 0); // MONNAIE = PAYÉ − TOTAL
  const balance = Math.max(total - paid, 0);

  function add(item: CatalogItem) {
    setDone(null);
    setError(null);
    setCart((c) => {
      const key = `${item.type}-${item.id}`;
      const ex = c.find((l) => l.key === key);
      if (ex) {
        if (ex.max != null && ex.quantity >= ex.max) return c;
        return c.map((l) => (l.key === key ? { ...l, quantity: l.quantity + 1 } : l));
      }
      if (item.type === "product" && (item.stock ?? 0) <= 0) return c;
      return [...c, { key, type: item.type, id: item.id, name: item.name, quantity: 1, unit_price: item.price, max: item.type === "product" ? item.stock : null, editablePrice: item.type === "service" }];
    });
  }

  function setQty(key: string, qty: number) {
    setCart((c) => c.map((l) => (l.key === key ? { ...l, quantity: Math.max(1, Math.min(qty || 1, l.max ?? 100000)) } : l)));
  }

  function reset() {
    setCart([]);
    setDiscount("0");
    setTendered("");
    setReference("");
    setCustomer(null);
    setCq("");
    setError(null);
    setEditing(null);
  }

  function submit() {
    setError(null);
    if (cart.length === 0) return setError("Le panier est vide.");
    if (balance > 0 && !customer) return setError("Un montant payé inférieur au total (vente à crédit) demande un client.");
    start(async () => {
      const res = await save({
        customer_id: customer?.id ?? "",
        items: cart.map((l) => ({ type: l.type, id: l.id, quantity: l.quantity, ...(l.type === "service" ? { unit_price: l.unit_price } : {}) })),
        discount,
        amount_tendered: String(paid),
        method,
        reference,
        notes: "",
      });
      if (!res.ok) return setError(res.fieldErrors ? Object.values(res.fieldErrors)[0] ?? res.error : res.error);
      setDone(res);
      reset();
      const fresh = await searchCatalog(q);
      if (fresh.ok) setCatalog(fresh.items);
    });
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_26rem]">
      {/* Gauche : recherche produits / services */}
      <Card className="h-fit">
        <CardHeader>
          <CardTitle>Produits et services</CardTitle>
          <div className="relative pt-2">
            <Search className="pointer-events-none absolute left-3 top-1/2 mt-1 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Nom, code ou catégorie" className="pl-9" aria-label="Rechercher un produit ou un service" autoComplete="off" />
          </div>
        </CardHeader>
        <CardContent>
          {catalog.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">Aucun résultat.</p>
          ) : (
            <ul className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
              {catalog.map((i) => {
                const out = i.type === "product" && (i.stock ?? 0) <= 0;
                return (
                  <li key={`${i.type}-${i.id}`}>
                    <button
                      type="button"
                      disabled={out}
                      onClick={() => add(i)}
                      className={cn("flex h-full w-full flex-col gap-1 rounded-lg border border-border bg-white p-3 text-left transition hover:border-primary hover:bg-blue-50", out && "cursor-not-allowed opacity-50 hover:border-border hover:bg-white")}
                    >
                      <span className="line-clamp-2 text-sm font-semibold">{i.name}</span>
                      <span className="text-xs text-muted-foreground">{i.category ?? (i.type === "service" ? "Service" : "Sans catégorie")}</span>
                      <span className="mt-auto flex items-center justify-between gap-2 pt-1">
                        <span className="font-bold tabular-nums text-primary">{formatHTG(i.price)}</span>
                        {i.type === "product" ? (
                          <Badge tone={STOCK_STATE[i.stock_state ?? "OK"]?.tone ?? "slate"}>{out ? "Rupture" : `Stock ${i.stock}`}</Badge>
                        ) : (
                          <Badge tone="blue">Service</Badge>
                        )}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Droite : panier */}
      <Card className="h-fit lg:sticky lg:top-24">
        <CardHeader><CardTitle>Panier</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {done && (
            <div role="status" className="space-y-2 rounded-lg bg-green-50 p-3 text-sm">
              <div className="font-bold text-success">Vente {done.sale_number} enregistrée — {formatHTG(done.total)}</div>
              {done.change > 0 && <div>Monnaie à rendre : <strong>{formatHTG(done.change)}</strong></div>}
              {done.balance > 0 && <div className="text-destructive">Reste à payer : <strong>{formatHTG(done.balance)}</strong> (à crédit)</div>}
              {done.receipt_id && (
                <Button asChild size="sm"><Link href={`/recus/${done.receipt_id}?print=1&format=ticket`}><Printer aria-hidden /> Imprimer le reçu {done.receipt_number}</Link></Button>
              )}
            </div>
          )}

          {cart.length === 0 ? (
            <p className="py-4 text-center text-sm text-muted-foreground">Touchez un produit ou un service pour l&apos;ajouter.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-xs uppercase text-muted-foreground">
                  <tr><th className="py-1">Produit</th><th className="py-1 text-center">Qté</th><th className="py-1 text-right">P.U.</th><th className="py-1 text-right">Sous-total</th><th className="py-1"><span className="sr-only">Action</span></th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {cart.map((l) => (
                    <tr key={l.key}>
                      <td className="py-2 pr-2 font-medium">{l.name}</td>
                      <td className="py-2">
                        <div className="flex items-center justify-center gap-1">
                          <button type="button" aria-label="Diminuer" className="rounded border border-border p-1 hover:bg-muted" onClick={() => setQty(l.key, l.quantity - 1)}><Minus className="size-3" /></button>
                          <input aria-label="Quantité" inputMode="numeric" value={l.quantity} onChange={(e) => setQty(l.key, Number(e.target.value.replace(/\D/g, "")))} className="h-7 w-10 rounded border border-border text-center tabular-nums" />
                          <button type="button" aria-label="Augmenter" className="rounded border border-border p-1 hover:bg-muted" onClick={() => setQty(l.key, l.quantity + 1)}><Plus className="size-3" /></button>
                        </div>
                      </td>
                      <td className="py-2 text-right tabular-nums">
                        {editing === l.key && l.editablePrice ? (
                          <input aria-label="Prix unitaire" inputMode="decimal" autoFocus defaultValue={l.unit_price} onBlur={(e) => { setCart((c) => c.map((x) => (x.key === l.key ? { ...x, unit_price: num(e.target.value) } : x))); setEditing(null); }} className="h-7 w-20 rounded border border-border px-1 text-right" />
                        ) : formatHTG(l.unit_price)}
                      </td>
                      <td className="py-2 text-right font-semibold tabular-nums">{formatHTG(l.quantity * l.unit_price)}</td>
                      <td className="py-2 pl-1">
                        <div className="flex justify-end gap-1">
                          {l.editablePrice && <button type="button" aria-label="Modifier le prix" className="rounded p-1 hover:bg-muted" onClick={() => setEditing(l.key)}><Pencil className="size-3.5" /></button>}
                          <button type="button" aria-label={`Supprimer ${l.name}`} className="rounded p-1 text-destructive hover:bg-red-50" onClick={() => setCart((c) => c.filter((x) => x.key !== l.key))}><X className="size-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Client */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="pos-client">Client (facultatif)</label>
            {customer ? (
              <div className="flex items-center justify-between rounded-lg border border-border bg-muted px-3 py-2 text-sm">
                <span className="font-semibold">{customer.name}</span>
                <button type="button" aria-label="Retirer le client" onClick={() => setCustomer(null)}><X className="size-4" /></button>
              </div>
            ) : (
              <div className="relative">
                <Input id="pos-client" value={cq} onChange={(e) => setCq(e.target.value)} placeholder="Client comptoir — chercher un nom" autoComplete="off" />
                {cResults.length > 0 && (
                  <ul className="absolute z-10 mt-1 w-full overflow-hidden rounded-lg border border-border bg-white shadow-lg">
                    {cResults.map((c) => (
                      <li key={c.id}><button type="button" className="flex w-full justify-between px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => { setCustomer(c); setCq(""); setCResults([]); }}><span className="font-semibold">{c.name}</span><span className="text-xs text-muted-foreground">{c.phone}</span></button></li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* Totaux */}
          <dl className="space-y-2 border-t border-border pt-3 text-sm">
            <div className="flex justify-between"><dt className="text-muted-foreground">Sous-total</dt><dd className="font-semibold tabular-nums">{formatHTG(subtotal)}</dd></div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-muted-foreground"><label htmlFor="pos-discount">Réduction</label></dt>
              <dd><Input id="pos-discount" inputMode="decimal" value={discount} onChange={(e) => setDiscount(e.target.value)} className="h-8 w-28 text-right" /></dd>
            </div>
            <div className="flex justify-between text-lg"><dt className="font-bold">Total</dt><dd className="font-black tabular-nums text-primary">{formatHTG(total)}</dd></div>
            <div className="flex items-center justify-between gap-3">
              <dt className="text-muted-foreground"><label htmlFor="pos-paid">Montant payé</label></dt>
              <dd><Input id="pos-paid" inputMode="decimal" placeholder={String(total)} value={tendered} onChange={(e) => setTendered(e.target.value)} className="h-8 w-28 text-right" /></dd>
            </div>
            <div className="flex justify-between"><dt className="text-muted-foreground">Monnaie</dt><dd className="font-bold tabular-nums text-success">{formatHTG(change)}</dd></div>
            {balance > 0 && <div className="flex justify-between"><dt className="text-muted-foreground">Reste à payer</dt><dd className="font-bold tabular-nums text-destructive">{formatHTG(balance)}</dd></div>}
            <div className="flex items-center justify-between gap-3">
              <dt className="text-muted-foreground"><label htmlFor="pos-method">Mode de paiement</label></dt>
              <dd><Select id="pos-method" value={method} onChange={(e) => setMethod(e.target.value)} className="h-8 w-36">{Object.entries(METHOD_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></dd>
            </div>
            {method !== "ESPECES" && (
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground"><label htmlFor="pos-ref">Référence</label></dt>
                <dd><Input id="pos-ref" value={reference} onChange={(e) => setReference(e.target.value)} className="h-8 w-36" /></dd>
              </div>
            )}
          </dl>

          {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">{error}</p>}
          <div className="grid grid-cols-2 gap-2">
            <Button type="button" size="lg" variant="success" className="col-span-2" disabled={pending || cart.length === 0} onClick={submit}>
              {pending ? "Enregistrement…" : "Enregistrer la vente"}
            </Button>
            <Button type="button" variant="outline" disabled={pending || cart.length === 0} onClick={reset}><Trash2 aria-hidden /> Vider</Button>
            {done?.receipt_id ? (
              <Button asChild variant="outline"><Link href={`/recus/${done.receipt_id}?print=1&format=ticket`}><Printer aria-hidden /> Imprimer</Link></Button>
            ) : (
              <Button type="button" variant="outline" disabled title="Enregistrez la vente pour imprimer le reçu"><Printer aria-hidden /> Imprimer</Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
