import Link from "next/link";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { CASH_CATEGORY, METHOD_LABELS, options } from "@/lib/labels";

export interface CashParams {
  q?: string;
  direction?: string;
  category?: string;
  method?: string;
  from?: string;
  to?: string;
}

const pick = (v: string | undefined, allowed: string[]) => (v && allowed.includes(v) ? v : undefined);
const dateOnly = (v: string | undefined) => (v && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : undefined);

/** Lecture sûre des filtres de l'URL. */
export function parseCashParams(get: (k: string) => string | undefined): CashParams {
  return {
    q: get("q")?.trim() || undefined,
    direction: pick(get("direction"), ["IN", "OUT"]),
    category: pick(get("category"), Object.keys(CASH_CATEGORY)),
    method: pick(get("method"), Object.keys(METHOD_LABELS)),
    from: dateOnly(get("from")),
    to: dateOnly(get("to")),
  };
}

export function CashFilters({ basePath, p }: { basePath: string; p: CashParams }) {
  return (
    <form method="get" action={basePath} className="grid gap-3 rounded-xl border border-border bg-white p-3 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
      <div className="relative sm:col-span-2">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <Input name="q" defaultValue={p.q ?? ""} placeholder="Description de l'opération" className="pl-9" aria-label="Rechercher" />
      </div>
      <Select name="direction" defaultValue={p.direction ?? ""} aria-label="Sens">
        <option value="">Entrées et sorties</option>
        <option value="IN">Entrées</option>
        <option value="OUT">Sorties</option>
      </Select>
      <Select name="category" defaultValue={p.category ?? ""} aria-label="Catégorie">
        <option value="">Toutes catégories</option>
        {options(CASH_CATEGORY).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </Select>
      <Select name="method" defaultValue={p.method ?? ""} aria-label="Mode de paiement">
        <option value="">Tous les modes</option>
        {options(METHOD_LABELS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </Select>
      <div className="flex gap-2">
        <Button type="submit" className="flex-1">Filtrer</Button>
        <Button asChild variant="outline"><Link href={basePath}>Effacer</Link></Button>
      </div>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">Du <Input type="date" name="from" defaultValue={p.from ?? ""} className="h-9" /></label>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">Au <Input type="date" name="to" defaultValue={p.to ?? ""} className="h-9" /></label>
    </form>
  );
}
