"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { ActionResult } from "@/lib/action-result";

export function CategoryManager({
  categories, add, setActive,
}: {
  categories: { id: string; name: string; is_active: boolean }[];
  add: (name: string) => Promise<ActionResult>;
  setActive: (id: string, active: boolean) => Promise<ActionResult>;
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const run = (fn: () => Promise<ActionResult>, after?: () => void) =>
    start(async () => {
      const res = await fn();
      if (!res.ok) return setError(res.error);
      setError(null);
      after?.();
      router.refresh();
    });
  return (
    <details className="rounded-xl border border-border bg-white p-4 shadow-sm">
      <summary className="cursor-pointer text-sm font-semibold">Gérer les catégories de dépenses</summary>
      <div className="mt-3 space-y-3">
        <ul className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <li key={c.id} className="flex items-center gap-1">
              <Badge tone={c.is_active ? "blue" : "slate"}>{c.name}</Badge>
              <button type="button" disabled={pending} onClick={() => run(() => setActive(c.id, !c.is_active))} className="text-xs text-primary hover:underline">
                {c.is_active ? "Désactiver" : "Réactiver"}
              </button>
            </li>
          ))}
        </ul>
        <form className="flex flex-wrap items-center gap-2" onSubmit={(e) => { e.preventDefault(); run(() => add(name), () => setName("")); }}>
          <Input aria-label="Nouvelle catégorie" placeholder="Nouvelle catégorie" value={name} onChange={(e) => setName(e.target.value)} className="h-9 w-56" />
          <Button type="submit" size="sm" variant="outline" disabled={pending || !name.trim()}>Ajouter</Button>
        </form>
        {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
      </div>
    </details>
  );
}
