"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS } from "@/lib/labels";

export function ExpenseForm({
  categories, today, cashOnHand, create,
}: {
  categories: { id: string; name: string }[];
  today: string;
  cashOnHand: number;
  create: (fd: FormData) => Promise<ActionResult<{ id: string }>>;
}) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [method, setMethod] = useState("ESPECES");
  const [pending, start] = useTransition();

  return (
    <form
      noValidate
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        setErrors({});
        setServerError(null);
        start(async () => {
          const res = await create(fd);
          if (!res.ok) {
            setServerError(res.error);
            setErrors(res.fieldErrors ?? {});
            return;
          }
          router.push(`/depenses/${res.id}`);
          router.refresh();
        });
      }}
    >
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          <Field id="category_id" label="Catégorie" required error={errors.category_id}>
            <Select id="category_id" name="category_id" defaultValue="">
              <option value="">— Choisir —</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field id="expense_date" label="Date" required error={errors.expense_date}>
            <Input id="expense_date" name="expense_date" type="date" defaultValue={today} max={today} />
          </Field>
          <Field id="description" label="Description" required className="md:col-span-2" error={errors.description}>
            <Input id="description" name="description" maxLength={200} />
          </Field>
          <Field id="amount" label="Montant (HTG)" required error={errors.amount}>
            <Input id="amount" name="amount" inputMode="decimal" />
          </Field>
          <Field id="method" label="Mode de paiement" error={errors.method} hint={method === "ESPECES" ? `Sort de la caisse (disponible : ${new Intl.NumberFormat("fr-FR").format(cashOnHand)} HTG)` : "Ne modifie pas le solde en espèces"}>
            <Select id="method" name="method" value={method} onChange={(e) => setMethod(e.target.value)}>
              {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </Select>
          </Field>
          <Field id="receipt" label="Justificatif (facultatif)" className="md:col-span-2" hint="Photo ou PDF, 5 Mo maximum" error={errors.receipt}>
            <Input id="receipt" name="receipt" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="h-auto py-2" />
          </Field>
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer la dépense"}</Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
