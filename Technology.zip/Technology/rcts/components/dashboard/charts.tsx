"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipContentProps,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCompact, formatHTG, formatInt, monthLabel } from "@/lib/utils";
import type { CashCategory } from "@/types/dashboard";

// Une teinte par entité (jamais recyclée) : revenus = bleu, dépenses = orange, etc.
const COLORS = {
  revenue: "#2a78d6",
  expenses: "#eb6834",
  enrollments: "#1baf7a",
  sales: "#4a3aa7",
} as const;
const INK = "#0f172a";
const MUTED = "#64748b";
const GRID = "#e1e6ee";

const CATEGORY_LABELS: Record<CashCategory, string> = {
  FORMATION: "Formations",
  VENTE: "Ventes",
  SERVICE: "Services",
  DEPENSE: "Dépenses",
  ACHAT_FOURNISSEUR: "Achats fournisseurs",
  AUTRE: "Autres revenus",
};

type Kind = "money" | "count";

interface Row {
  label: string;
  value: number;
  extra?: string;
}

function fmt(v: number, kind: Kind) {
  return kind === "money" ? formatHTG(v) : formatInt(v);
}

function ChartTooltip({
  active,
  payload,
  kind,
}: Pick<TooltipContentProps, "active" | "payload"> & { kind: Kind }) {
  if (!active || !payload?.length) return null;
  const row = payload[0].payload as Row;
  return (
    <div className="rounded-lg border border-border bg-white px-3 py-2 text-sm shadow-lg">
      <div className="font-semibold">{row.label}</div>
      <div className="tabular-nums">{fmt(row.value, kind)}</div>
      {row.extra && <div className="text-xs text-muted-foreground">{row.extra}</div>}
    </div>
  );
}

/** Carte de graphique : titre, graphique, et version tableau pour l'accessibilité. */
function ChartCard({
  title,
  description,
  rows,
  kind,
  valueHeader,
  children,
}: {
  title: string;
  description: string;
  rows: Row[];
  kind: Kind;
  valueHeader: string;
  children: React.ReactNode;
}) {
  const empty = rows.every((r) => r.value === 0);
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {empty ? (
          <div className="flex h-56 items-center justify-center rounded-lg bg-muted text-sm text-muted-foreground">
            Aucune donnée enregistrée pour le moment
          </div>
        ) : (
          children
        )}
        <details className="mt-3 text-sm">
          <summary className="cursor-pointer text-primary hover:underline">Voir en tableau</summary>
          <div className="mt-2 max-h-56 overflow-auto rounded-lg border border-border">
            <table className="w-full text-left">
              <thead className="sticky top-0 bg-muted text-xs text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 font-semibold">Période</th>
                  <th className="px-3 py-2 text-right font-semibold">{valueHeader}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.label} className="border-t border-border">
                    <td className="px-3 py-1.5">{r.label}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums">{fmt(r.value, kind)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>
      </CardContent>
    </Card>
  );
}

interface MonthlyProps {
  title: string;
  description: string;
  data: { month: string; value: number; extra?: string }[];
  color: keyof typeof COLORS;
  kind: Kind;
  valueHeader: string;
}

/** Histogramme sur 12 mois (une seule série, donc pas de légende : le titre la nomme). */
export function MonthlyChart({ title, description, data, color, kind, valueHeader }: MonthlyProps) {
  const rows: Row[] = data.map((d) => ({ label: monthLabel(d.month), value: d.value, extra: d.extra }));
  return (
    <ChartCard title={title} description={description} rows={rows} kind={kind} valueHeader={valueHeader}>
      <div className="h-56" role="img" aria-label={`${title} — voir le tableau pour le détail`}>
        <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 520, height: 224 }}>
          <BarChart data={rows} margin={{ top: 8, right: 4, left: 0, bottom: 0 }} barCategoryGap="22%">
            <CartesianGrid vertical={false} stroke={GRID} strokeWidth={1} />
            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={{ stroke: GRID }}
              tick={{ fill: MUTED, fontSize: 11 }}
              interval="preserveStartEnd"
              minTickGap={8}
            />
            <YAxis
              width={44}
              tickLine={false}
              axisLine={false}
              tick={{ fill: MUTED, fontSize: 11 }}
              tickFormatter={(v: number) => formatCompact(v)}
              allowDecimals={false}
            />
            <Tooltip content={(p) => <ChartTooltip {...p} kind={kind} />} cursor={{ fill: "rgba(15,23,42,0.05)" }} />
            <Bar dataKey="value" fill={COLORS[color]} radius={[4, 4, 0, 0]} maxBarSize={28} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ChartCard>
  );
}

/** Revenus par catégorie : barres horizontales triées, étiquetées directement. */
export function CategoryChart({ data }: { data: { category: CashCategory; total: number }[] }) {
  const rows: Row[] = data.map((d) => ({ label: CATEGORY_LABELS[d.category] ?? d.category, value: d.total }));
  const height = Math.max(120, rows.length * 44 + 16);
  return (
    <ChartCard
      title="Revenus par catégorie"
      description="12 derniers mois"
      rows={rows}
      kind="money"
      valueHeader="Montant"
    >
      <div style={{ height }} role="img" aria-label="Revenus par catégorie — voir le tableau pour le détail">
        <ResponsiveContainer width="100%" height="100%" initialDimension={{ width: 520, height }}>
          <BarChart data={rows} layout="vertical" margin={{ top: 4, right: 96, left: 4, bottom: 4 }} barCategoryGap="30%">
            <XAxis type="number" hide />
            <YAxis
              type="category"
              dataKey="label"
              width={110}
              tickLine={false}
              axisLine={false}
              tick={{ fill: INK, fontSize: 12 }}
            />
            <Tooltip content={(p) => <ChartTooltip {...p} kind="money" />} cursor={{ fill: "rgba(15,23,42,0.05)" }} />
            <Bar
              dataKey="value"
              radius={[0, 4, 4, 0]}
              maxBarSize={22}
              label={{
                position: "right",
                fill: INK,
                fontSize: 12,
                formatter: (v: unknown) => formatCompact(Number(v)) + " HTG",
              }}
            >
              {rows.map((r) => (
                <Cell key={r.label} fill={COLORS.revenue} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ChartCard>
  );
}
