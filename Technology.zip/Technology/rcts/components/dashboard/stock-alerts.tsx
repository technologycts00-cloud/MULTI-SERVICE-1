import { AlertTriangle, PackageX } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { StockAlert } from "@/types/dashboard";

export function StockAlerts({ alerts }: { alerts: StockAlert[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Alertes de stock</CardTitle>
        <CardDescription>Produits à réapprovisionner</CardDescription>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="rounded-lg bg-green-50 p-4 text-center text-sm font-medium text-success">
            Tous les produits sont au-dessus du stock minimum.
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {alerts.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-3 py-2.5">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{a.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {a.code} · minimum {a.min_stock}
                  </div>
                </div>
                {a.stock_state === "RUPTURE" ? (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-xs font-semibold text-destructive">
                    <PackageX className="size-3" aria-hidden /> Rupture
                  </span>
                ) : (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-semibold text-yellow-800">
                    <AlertTriangle className="size-3" aria-hidden /> Faible : {a.current_stock}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
