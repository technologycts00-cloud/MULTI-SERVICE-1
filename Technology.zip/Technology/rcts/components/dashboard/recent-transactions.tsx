import { ArrowDownLeft, ArrowUpRight, Ban, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { CashCategory, RecentTransaction } from "@/types/dashboard";

const TYPE_LABELS: Record<CashCategory, string> = {
  FORMATION: "Formation",
  VENTE: "Vente",
  SERVICE: "Service",
  DEPENSE: "Dépense",
  ACHAT_FOURNISSEUR: "Achat fournisseur",
  AUTRE: "Autre",
};

function Status({ status }: { status: RecentTransaction["status"] }) {
  return status === "VALIDE" ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-0.5 text-xs font-semibold text-success">
      <CheckCircle2 className="size-3" aria-hidden /> Validée
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-xs font-semibold text-destructive">
      <Ban className="size-3" aria-hidden /> Annulée
    </span>
  );
}

function Amount({ t }: { t: RecentTransaction }) {
  const isIn = t.direction === "IN";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 font-semibold tabular-nums",
        isIn ? "text-success" : "text-destructive",
        t.status === "ANNULE" && "text-muted-foreground line-through",
      )}
    >
      {isIn ? <ArrowDownLeft className="size-3.5" aria-label="Entrée" /> : <ArrowUpRight className="size-3.5" aria-label="Sortie" />}
      {isIn ? "+" : "−"}
      {formatHTG(t.amount)}
    </span>
  );
}

export function RecentTransactions({ items }: { items: RecentTransaction[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Transactions récentes</CardTitle>
        <CardDescription>Les 10 derniers mouvements de caisse</CardDescription>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <div className="rounded-lg bg-muted p-6 text-center text-sm text-muted-foreground">
            Aucune transaction enregistrée pour le moment.
          </div>
        ) : (
          <>
            {/* Mobile : cartes */}
            <ul className="space-y-3 md:hidden">
              {items.map((t) => (
                <li key={t.id} className="rounded-lg border border-border p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground">
                        {formatDateTime(t.occurred_at)} · {TYPE_LABELS[t.category]}
                      </div>
                      <div className="truncate text-sm font-medium">{t.description ?? "—"}</div>
                    </div>
                    <Amount t={t} />
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                    <span>{t.user_name ?? "—"}</span>
                    <Status status={t.status} />
                  </div>
                </li>
              ))}
            </ul>

            {/* Ordinateur / tablette : tableau */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full text-left text-sm">
                <thead className="text-xs text-muted-foreground">
                  <tr className="border-b border-border">
                    <th className="py-2 pr-3 font-semibold">Date</th>
                    <th className="py-2 pr-3 font-semibold">Type</th>
                    <th className="py-2 pr-3 font-semibold">Description</th>
                    <th className="py-2 pr-3 text-right font-semibold">Montant</th>
                    <th className="py-2 pr-3 font-semibold">Utilisateur</th>
                    <th className="py-2 font-semibold">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((t) => (
                    <tr key={t.id} className="border-b border-border last:border-0">
                      <td className="whitespace-nowrap py-2.5 pr-3 tabular-nums">{formatDateTime(t.occurred_at)}</td>
                      <td className="whitespace-nowrap py-2.5 pr-3">{TYPE_LABELS[t.category]}</td>
                      <td className="max-w-xs truncate py-2.5 pr-3" title={t.description ?? ""}>
                        {t.description ?? "—"}
                      </td>
                      <td className="whitespace-nowrap py-2.5 pr-3 text-right">
                        <Amount t={t} />
                      </td>
                      <td className="whitespace-nowrap py-2.5 pr-3">{t.user_name ?? "—"}</td>
                      <td className="py-2.5">
                        <Status status={t.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
