import {
  AlertTriangle, Banknote, BookUser, CalendarDays, Clock, GraduationCap, HandCoins, PackageX,
  TrendingDown, TrendingUp, UserPlus, Wallet,
} from "lucide-react";
import { CategoryChart, MonthlyChart } from "@/components/dashboard/charts";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { RecentTransactions } from "@/components/dashboard/recent-transactions";
import { StockAlerts } from "@/components/dashboard/stock-alerts";
import { formatHTG, formatInt } from "@/lib/utils";
import type { DashboardStats } from "@/types/dashboard";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{title}</h2>
      {children}
    </section>
  );
}

const GRID = "grid grid-cols-1 gap-3 min-[480px]:grid-cols-2 xl:grid-cols-4";

/** Affichage pur : reçoit les chiffres calculés par la base, n'invente aucune valeur. */
export function DashboardView({ stats }: { stats: DashboardStats }) {
  const { finance, school, stock, recent, charts } = stats;
  const isSecretary = stats.role === "SECRETAIRE";
  const showEnrollmentMoney = isSecretary && school;

  return (
    <div className="space-y-8">
      {finance && (
        <Section title="Finances">
          <div className={GRID}>
            <KpiCard label="Chiffre d'affaires aujourd'hui" value={formatHTG(finance.revenue_today)} icon={TrendingUp} tone="green" />
            <KpiCard label="Chiffre d'affaires du mois" value={formatHTG(finance.revenue_month)} icon={CalendarDays} tone="blue" />
            <KpiCard label="Solde de caisse (espèces)" value={formatHTG(finance.cash_balance)} icon={Wallet} tone="blue" />
            <KpiCard label="Total des paiements" value={formatHTG(finance.total_payments)} hint="Cumul depuis le début" icon={Banknote} tone="green" />
            {finance.total_expenses !== null && (
              <KpiCard
                label="Total des dépenses"
                value={formatHTG(finance.total_expenses)}
                hint={`Ce mois : ${formatHTG(finance.expenses_month)}`}
                icon={TrendingDown}
                tone="slate"
              />
            )}
            <KpiCard label="Créances" value={formatHTG(finance.receivables)} hint="Soldes restant à encaisser" icon={HandCoins} tone="yellow" />
            <KpiCard label="Paiements en attente" value={formatInt(finance.pending_count)} hint="Dossiers avec un solde à payer" icon={Clock} tone="yellow" />
          </div>
        </Section>
      )}

      {school && (
        <Section title="Élèves et inscriptions">
          <div className={GRID}>
            <KpiCard label="Nombre d'élèves" value={formatInt(school.students_total)} icon={GraduationCap} tone="blue" />
            <KpiCard label="Élèves actifs" value={formatInt(school.students_active)} icon={BookUser} tone="green" />
            <KpiCard label="Nouvelles inscriptions" value={formatInt(school.new_enrollments_month)} hint="Ce mois-ci" icon={UserPlus} tone="blue" />
            {showEnrollmentMoney && (
              <>
                <KpiCard label="Paiements en attente" value={formatInt(school.unpaid_enrollments)} hint="Inscriptions non soldées" icon={Clock} tone="yellow" />
                <KpiCard label="Créances" value={formatHTG(school.enrollment_receivables)} hint="Frais de formation à encaisser" icon={HandCoins} tone="yellow" />
              </>
            )}
          </div>
        </Section>
      )}

      {stock && (
        <Section title="Stock">
          <div className={GRID}>
            <KpiCard label="Produits en stock faible" value={formatInt(stock.low_stock)} icon={AlertTriangle} tone={stock.low_stock > 0 ? "yellow" : "green"} />
            <KpiCard label="Produits en rupture" value={formatInt(stock.out_of_stock)} icon={PackageX} tone={stock.out_of_stock > 0 ? "red" : "green"} />
          </div>
        </Section>
      )}

      {(charts.revenue || charts.enrollments) && (
        <Section title="Évolution sur 12 mois">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {charts.revenue && (
              <MonthlyChart
                title="Revenus mensuels"
                description="Paiements encaissés"
                data={charts.revenue.map((d) => ({ month: d.month, value: d.total }))}
                color="revenue"
                kind="money"
                valueHeader="Revenus"
              />
            )}
            {charts.expenses && (
              <MonthlyChart
                title="Dépenses mensuelles"
                description="Dépenses validées"
                data={charts.expenses.map((d) => ({ month: d.month, value: d.total }))}
                color="expenses"
                kind="money"
                valueHeader="Dépenses"
              />
            )}
            {charts.enrollments && (
              <MonthlyChart
                title="Inscriptions mensuelles"
                description="Nouvelles inscriptions"
                data={charts.enrollments.map((d) => ({ month: d.month, value: d.count }))}
                color="enrollments"
                kind="count"
                valueHeader="Inscriptions"
              />
            )}
            {charts.sales && (
              <MonthlyChart
                title="Ventes mensuelles"
                description="Montant des ventes validées"
                data={charts.sales.map((d) => ({
                  month: d.month,
                  value: d.total,
                  extra: `${formatInt(d.count)} vente${d.count > 1 ? "s" : ""}`,
                }))}
                color="sales"
                kind="money"
                valueHeader="Ventes"
              />
            )}
            {charts.by_category && <CategoryChart data={charts.by_category} />}
            {stock && <StockAlerts alerts={stock.alerts} />}
          </div>
        </Section>
      )}

      {/* Rôles sans graphiques (ex. gestionnaire) : alertes de stock seules */}
      {stock && !(charts.revenue || charts.enrollments) && <StockAlerts alerts={stock.alerts} />}

      {recent && <RecentTransactions items={recent} />}
    </div>
  );
}
