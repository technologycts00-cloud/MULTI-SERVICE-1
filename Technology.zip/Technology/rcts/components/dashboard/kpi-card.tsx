import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export type KpiTone = "blue" | "green" | "yellow" | "red" | "slate";

const TONES: Record<KpiTone, { icon: string; value: string }> = {
  blue: { icon: "bg-blue-50 text-primary", value: "text-foreground" },
  green: { icon: "bg-green-50 text-success", value: "text-foreground" },
  yellow: { icon: "bg-yellow-100 text-yellow-700", value: "text-foreground" },
  red: { icon: "bg-red-50 text-destructive", value: "text-destructive" },
  slate: { icon: "bg-muted text-muted-foreground", value: "text-foreground" },
};

export function KpiCard({
  label,
  value,
  hint,
  icon: Icon,
  tone = "blue",
}: {
  label: string;
  value: string;
  hint?: string;
  icon: LucideIcon;
  tone?: KpiTone;
}) {
  const t = TONES[tone];
  return (
    <div className="flex items-start gap-3 rounded-xl border border-border bg-white p-4 shadow-sm">
      <div className={cn("flex size-10 shrink-0 items-center justify-center rounded-lg", t.icon)}>
        <Icon className="size-5" aria-hidden />
      </div>
      <div className="min-w-0">
        <div className="text-xs font-medium text-muted-foreground">{label}</div>
        <div className={cn("truncate text-xl font-black tabular-nums", t.value)}>{value}</div>
        {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
      </div>
    </div>
  );
}
