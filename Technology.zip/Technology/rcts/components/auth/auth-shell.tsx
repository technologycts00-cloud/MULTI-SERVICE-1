import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function AuthShell({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-sidebar via-primary to-primary p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center text-white">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-accent text-xl font-black text-accent-foreground">
            R
          </div>
          <h1 className="text-2xl font-black tracking-wide">R.CTS</h1>
          <p className="text-xs tracking-widest text-blue-100">R.COMPLEX TECHNOLOGY SERVICES</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>{title}</CardTitle>
            {description && <CardDescription>{description}</CardDescription>}
          </CardHeader>
          <CardContent>{children}</CardContent>
        </Card>
      </div>
    </main>
  );
}

export function FormMessage({ error, success }: { error?: string; success?: string }) {
  if (!error && !success) return null;
  return (
    <p
      role="alert"
      className={`rounded-lg px-3 py-2 text-sm ${error ? "bg-red-50 text-destructive" : "bg-green-50 text-success"}`}
    >
      {error ?? success}
    </p>
  );
}
