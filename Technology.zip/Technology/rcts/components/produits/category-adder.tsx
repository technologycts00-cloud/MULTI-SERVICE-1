"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { ActionResult } from "@/lib/action-result";

export function CategoryAdder({ add }: { add: (name: string) => Promise<ActionResult> }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-wrap items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const res = await add(name);
          if (!res.ok) return setError(res.error);
          setName("");
          setError(null);
          router.refresh();
        });
      }}
    >
      <Input aria-label="Nouvelle catégorie" placeholder="Nouvelle catégorie" value={name} onChange={(e) => setName(e.target.value)} className="h-9 w-56" />
      <Button type="submit" size="sm" variant="outline" disabled={pending || !name.trim()}>Ajouter</Button>
      {error && <span role="alert" className="text-xs text-destructive">{error}</span>}
    </form>
  );
}
