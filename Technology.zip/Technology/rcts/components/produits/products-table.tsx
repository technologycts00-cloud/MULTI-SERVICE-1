import Link from "next/link";
import { StatusBadge } from "@/components/ui/badge";
import { STOCK_STATE } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";
import type { ProductListRow } from "@/services/products";

export function ProductsTable({ rows, showCost }: { rows: ProductListRow[]; showCost: boolean }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucun produit trouvé.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[680px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Produit</th>
              <th className="px-4 py-3">Code</th>
              <th className="px-4 py-3">Catégorie</th>
              {showCost && <th className="px-4 py-3 text-right">Achat</th>}
              <th className="px-4 py-3 text-right">Vente</th>
              <th className="px-4 py-3 text-right">Stock</th>
              <th className="px-4 py-3">État</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((p) => (
              <tr key={p.id} className="hover:bg-muted/50">
                <td className="px-4 py-3 font-semibold"><Link href={`/produits/${p.id}`} className="hover:text-primary">{p.name}</Link></td>
                <td className="px-4 py-3 font-mono text-xs">{p.code}</td>
                <td className="px-4 py-3">{p.product_categories?.name ?? "—"}</td>
                {showCost && <td className="px-4 py-3 text-right tabular-nums">{formatHTG(p.purchase_price)}</td>}
                <td className="px-4 py-3 text-right tabular-nums">{formatHTG(p.sale_price)}</td>
                <td className="px-4 py-3 text-right font-semibold tabular-nums">{p.current_stock}</td>
                <td className="px-4 py-3"><StatusBadge map={STOCK_STATE} value={p.stock_state} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
