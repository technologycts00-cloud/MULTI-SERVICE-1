"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { PRODUCT_STATUS, options } from "@/lib/labels";
import { productSchema, type ProductFormInput, type ProductValues } from "@/lib/validations/product";

export function ProductForm({
  productId,
  defaults,
  categories,
  suppliers,
  save,
}: {
  productId: string | null;
  defaults: ProductFormInput;
  categories: { id: string; name: string }[];
  suppliers: { id: string; name: string }[];
  save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string; warning?: string }>>;
}) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const { register, handleSubmit, getValues, setError, formState: { errors } } = useForm<ProductFormInput, unknown, ProductValues>({
    resolver: zodResolver(productSchema),
    defaultValues: defaults,
  });

  const onValid = () => {
    setServerError(null);
    start(async () => {
      const res = await save(productId, getValues());
      if (!res.ok) {
        setServerError(res.error);
        for (const [n, m] of Object.entries(res.fieldErrors ?? {})) setError(n as keyof ProductFormInput, { message: m });
        return;
      }
      router.push(`/produits/${res.id}`);
      router.refresh();
    });
  };

  return (
    <form onSubmit={handleSubmit(onValid)} noValidate className="space-y-4">
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          <Field id="name" label="Nom du produit" required className="md:col-span-2" error={errors.name?.message}>
            <Input id="name" aria-invalid={!!errors.name} {...register("name")} />
          </Field>
          <Field id="category_id" label="Catégorie" error={errors.category_id?.message}>
            <Select id="category_id" {...register("category_id")}>
              <option value="">Sans catégorie</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field id="supplier_id" label="Fournisseur" error={errors.supplier_id?.message}>
            <Select id="supplier_id" {...register("supplier_id")}>
              <option value="">Aucun</option>
              {suppliers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field id="purchase_price" label="Prix d'achat (HTG)" error={errors.purchase_price?.message}>
            <Input id="purchase_price" inputMode="decimal" {...register("purchase_price")} />
          </Field>
          <Field id="sale_price" label="Prix de vente (HTG)" required error={errors.sale_price?.message}>
            <Input id="sale_price" inputMode="decimal" {...register("sale_price")} />
          </Field>
          <Field id="min_stock" label="Stock minimum (alerte)" error={errors.min_stock?.message}>
            <Input id="min_stock" inputMode="numeric" {...register("min_stock")} />
          </Field>
          {productId === null ? (
            <Field id="initial_stock" label="Stock initial" hint="Enregistré comme une entrée de stock" error={errors.initial_stock?.message}>
              <Input id="initial_stock" inputMode="numeric" {...register("initial_stock")} />
            </Field>
          ) : (
            <Field id="status" label="Statut" error={errors.status?.message}>
              <Select id="status" {...register("status")}>
                {options(PRODUCT_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </Select>
            </Field>
          )}
          <Field id="description" label="Description" className="md:col-span-2" error={errors.description?.message}>
            <Textarea id="description" {...register("description")} />
          </Field>
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>{pending ? "Enregistrement…" : productId ? "Enregistrer" : "Créer le produit"}</Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
