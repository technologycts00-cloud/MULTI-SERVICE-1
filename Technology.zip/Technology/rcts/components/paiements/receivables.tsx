"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Printer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { METHOD_LABELS, PAYMENT_KIND } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";
import type { Receivable } from "@/services/payments";
import { recordPaymentAction } from "@/app/(app)/paiements/actions";

function PayRow({ r }: { r: Receivable }) {
  const router = useRouter();
  const [amount, setAmount] = useState(String(r.balance));
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string; receipt?: string } | null>(null);
  const [pending, start] = useTransition();

  return (
    <li className="space-y-2 py-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="font-semibold">{r.payer_name}</div>
          <div className="text-xs text-muted-foreground">
            <Badge tone="blue" className="mr-1">{PAYMENT_KIND[r.kind]}</Badge>
            <span className="font-mono">{r.number}</span> · {r.description}
          </div>
        </div>
        <div className="text-right text-sm">
          <div className="font-bold text-destructive tabular-nums">{formatHTG(r.balance)}</div>
          <div className="text-xs text-muted-foreground">sur {formatHTG(r.total)}</div>
        </div>
      </div>
      <form
        className="flex flex-wrap items-center gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          setMsg(null);
          start(async () => {
            const res = await recordPaymentAction({ kind: r.kind, target_id: r.id, amount, method, reference });
            if (!res.ok) return setMsg({ ok: false, text: res.fieldErrors?.amount ?? res.error });
            setMsg({ ok: true, text: `Paiement enregistré — reçu ${res.receipt_number}`, receipt: res.receipt_id });
            router.refresh();
          });
        }}
      >
        <Input aria-label="Montant" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-9 w-28" />
        <Select aria-label="Mode de paiement" value={method} onChange={(e) => setMethod(e.target.value)} className="h-9 w-32">
          {Object.entries(METHOD_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </Select>
        {method !== "ESPECES" && (
          <Input aria-label="Référence" placeholder="Référence" value={reference} onChange={(e) => setReference(e.target.value)} className="h-9 w-36" />
        )}
        <Button type="submit" size="sm" disabled={pending}>{pending ? "…" : "Encaisser"}</Button>
      </form>
      {msg && (
        <p role={msg.ok ? "status" : "alert"} className={`text-xs ${msg.ok ? "text-success" : "text-destructive"}`}>
          {msg.text}{" "}
          {msg.receipt && (
            <Link href={`/recus/${msg.receipt}?print=1`} className="inline-flex items-center gap-1 font-semibold underline">
              <Printer className="size-3" aria-hidden /> Imprimer
            </Link>
          )}
        </p>
      )}
    </li>
  );
}

export function Receivables({ items }: { items: Receivable[] }) {
  if (items.length === 0) return <p className="text-sm text-muted-foreground">Aucun solde à encaisser.</p>;
  return <ul className="divide-y divide-border">{items.map((r) => <PayRow key={`${r.kind}-${r.id}`} r={r} />)}</ul>;
}
