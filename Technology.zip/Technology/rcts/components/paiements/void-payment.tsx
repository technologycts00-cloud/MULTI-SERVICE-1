"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { voidPaymentAction } from "@/app/(app)/paiements/actions";

/** Annulation d'un paiement avec motif obligatoire (ADMIN). */
export function VoidPayment({ paymentId }: { paymentId: string }) {
  const router = useRouter();
  const dialog = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  return (
    <>
      <Button type="button" size="sm" variant="ghost" className="text-destructive" onClick={() => dialog.current?.showModal()}>
        Annuler
      </Button>
      <dialog ref={dialog} className="m-auto w-[min(92vw,26rem)] rounded-xl border border-border p-0 shadow-xl backdrop:bg-black/40">
        <div className="space-y-4 p-5 text-left">
          <h2 className="text-lg font-bold">Annuler ce paiement ?</h2>
          <p className="text-sm text-muted-foreground">Le paiement reste visible (annulé), la caisse et le solde sont corrigés automatiquement.</p>
          <div className="space-y-1.5">
            <label htmlFor={`reason-${paymentId}`} className="text-sm font-medium">Motif (obligatoire)</label>
            <Textarea id={`reason-${paymentId}`} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />
          </div>
          {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">{error}</p>}
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" disabled={pending} onClick={() => dialog.current?.close()}>Retour</Button>
            <Button
              type="button"
              variant="destructive"
              disabled={pending}
              onClick={() =>
                start(async () => {
                  const res = await voidPaymentAction(paymentId, reason);
                  if (!res.ok) return setError(res.error);
                  dialog.current?.close();
                  setReason("");
                  setError(null);
                  router.refresh();
                })
              }
            >
              {pending ? "En cours…" : "Annuler le paiement"}
            </Button>
          </div>
        </div>
      </dialog>
    </>
  );
}
