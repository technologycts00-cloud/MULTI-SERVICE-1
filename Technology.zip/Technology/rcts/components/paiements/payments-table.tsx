import Link from "next/link";
import { Receipt } from "lucide-react";
import { StatusBadge } from "@/components/ui/badge";
import { METHOD_LABELS, PAYMENT_KIND, RECORD_STATUS } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { PaymentRow } from "@/services/payments";
import { VoidPayment } from "./void-payment";

export function PaymentsTable({ rows, canVoid }: { rows: PaymentRow[]; canVoid: boolean }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucun paiement trouvé.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Payeur</th>
              <th className="px-4 py-3">Objet</th>
              <th className="px-4 py-3">Mode</th>
              <th className="px-4 py-3 text-right">Montant</th>
              <th className="px-4 py-3">Reçu</th>
              <th className="px-4 py-3">Par</th>
              <th className="px-4 py-3">Statut</th>
              {canVoid && <th className="px-4 py-3" />}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((p) => (
              <tr key={p.id} className={cn("hover:bg-muted/50", p.status === "ANNULE" && "text-muted-foreground")}>
                <td className="whitespace-nowrap px-4 py-3">{formatDateTime(p.paid_at)}</td>
                <td className="px-4 py-3 font-semibold">{p.payer_name}</td>
                <td className="px-4 py-3">
                  <div>{PAYMENT_KIND[p.kind] ?? p.kind}</div>
                  <div className="font-mono text-xs text-muted-foreground">{p.target_number}</div>
                </td>
                <td className="px-4 py-3">
                  {METHOD_LABELS[p.method] ?? p.method}
                  {p.reference && <div className="text-xs text-muted-foreground">{p.reference}</div>}
                </td>
                <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", p.status === "ANNULE" && "line-through")}>{formatHTG(p.amount)}</td>
                <td className="px-4 py-3">
                  {p.receipt_id ? (
                    <Link href={`/recus/${p.receipt_id}`} className="inline-flex items-center gap-1 font-mono text-xs font-semibold text-primary hover:underline">
                      <Receipt className="size-3.5" aria-hidden /> {p.receipt_number}
                    </Link>
                  ) : "—"}
                </td>
                <td className="px-4 py-3">{p.user_name ?? "—"}</td>
                <td className="px-4 py-3">
                  <StatusBadge map={RECORD_STATUS} value={p.status} />
                  {p.void_reason && <div className="mt-1 max-w-48 text-xs">{p.void_reason}</div>}
                </td>
                {canVoid && <td className="px-4 py-3 text-right">{p.status === "VALIDE" && <VoidPayment paymentId={p.id} />}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
