"use client";

import { Button } from "@/components/ui/button";

export function ReloadButton() {
  return <Button type="button" variant="accent" size="lg" onClick={() => window.location.reload()}>Réessayer</Button>;
}
