"use client";

import { EntityForm } from "@/components/shared/entity-form";
import type { ActionResult } from "@/lib/action-result";
import { CUSTOMER_TYPE, options } from "@/lib/labels";
import { customerSchema, type CustomerFormInput } from "@/lib/validations/party";

export function CustomerForm({ id, defaults, save }: { id: string | null; defaults: CustomerFormInput; save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string }>> }) {
  return (
    <EntityForm
      schema={customerSchema}
      defaults={defaults}
      submitLabel={id ? "Enregistrer" : "Créer le client"}
      save={(raw) => save(id, raw)}
      redirectTo={(i) => `/clients/${i}`}
      fields={[
        { name: "name", label: "Nom du client", required: true, wide: true },
        { name: "customer_type", label: "Type", type: "select", options: options(CUSTOMER_TYPE) },
        { name: "phone", label: "Téléphone", type: "tel" },
        { name: "email", label: "E-mail", type: "email" },
        { name: "address", label: "Adresse" },
        { name: "notes", label: "Notes", type: "textarea", wide: true },
      ]}
    />
  );
}
