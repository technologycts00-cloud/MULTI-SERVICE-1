"use client";

import { EntityForm } from "@/components/shared/entity-form";
import type { ActionResult } from "@/lib/action-result";
import { settingsSchema, type SettingsInput } from "@/lib/validations/admin";

export function SettingsForm({ defaults, save }: { defaults: SettingsInput; save: (raw: unknown) => Promise<ActionResult<{ id: string }>> }) {
  return (
    <EntityForm
      schema={settingsSchema}
      defaults={defaults}
      submitLabel="Enregistrer les paramètres"
      save={save}
      redirectTo={() => "/parametres?ok=1"}
      fields={[
        { name: "org_name", label: "Nom commercial", required: true },
        { name: "org_legal_name", label: "Raison sociale (en-tête des documents)", required: true },
        { name: "phone", label: "Téléphone", type: "tel" },
        { name: "email", label: "E-mail", type: "email" },
        { name: "address", label: "Adresse", wide: true },
        { name: "logo_url", label: "Logo (lien https://…)", wide: true, hint: "Image hébergée en ligne ; affichée dans le menu et sur les reçus/factures." },
        { name: "receipt_prefix", label: "Préfixe des reçus", required: true, hint: "Exemple : RCTS → RCTS-2026-000001. Ne change pas les numéros déjà émis." },
        { name: "invoice_prefix", label: "Préfixe des factures", required: true },
        { name: "invoice_footer", label: "Mentions de bas de facture", type: "textarea", wide: true },
      ]}
    />
  );
}
