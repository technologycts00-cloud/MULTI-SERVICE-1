"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";

/** Bouton d'annulation avec boîte de confirmation et motif obligatoire (pour vente, dépense, etc.). */
export function VoidWithReason({
  action,
  title,
  description,
  label,
  redirectTo,
}: {
  action: (reason: string) => Promise<ActionResult>;
  title: string;
  description: string;
  label: string;
  redirectTo?: string;
}) {
  const router = useRouter();
  const dialog = useRef<HTMLDialogElement>(null);
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <>
      <Button type="button" variant="destructive" onClick={() => dialog.current?.showModal()}>{label}</Button>
      <dialog ref={dialog} className="m-auto w-[min(92vw,26rem)] rounded-xl border border-border p-0 shadow-xl backdrop:bg-black/40">
        <div className="space-y-4 p-5 text-left">
          <h2 className="text-lg font-bold">{title}</h2>
          <p className="text-sm text-muted-foreground">{description}</p>
          <div className="space-y-1.5">
            <label htmlFor="void-reason" className="text-sm font-medium">Motif (obligatoire)</label>
            <Textarea id="void-reason" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />
          </div>
          {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">{error}</p>}
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" disabled={pending} onClick={() => dialog.current?.close()}>Retour</Button>
            <Button
              type="button"
              variant="destructive"
              disabled={pending}
              onClick={() =>
                start(async () => {
                  const res = await action(reason);
                  if (!res.ok) return setError(res.error);
                  dialog.current?.close();
                  setReason("");
                  setError(null);
                  if (redirectTo) router.push(redirectTo);
                  else router.refresh();
                })
              }
            >
              {pending ? "En cours…" : label}
            </Button>
          </div>
        </div>
      </dialog>
    </>
  );
}
