import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PERIOD_PRESETS, type Period } from "@/lib/period";
import { cn } from "@/lib/utils";

/** Filtres de période : boutons (aujourd'hui, semaine, mois, année) + période personnalisée (formulaire GET). */
export function PeriodFilter({ basePath, period, extra = {} }: { basePath: string; period: Period; extra?: Record<string, string | undefined> }) {
  const qs = (p: Record<string, string | undefined>) => {
    const u = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...extra, ...p })) if (v) u.set(k, v);
    const s = u.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  return (
    <div className="no-print flex flex-col gap-3 rounded-xl border border-border bg-white p-3 shadow-sm lg:flex-row lg:items-end lg:justify-between">
      <div className="flex flex-wrap gap-2" role="group" aria-label="Période">
        {(["today", "week", "month", "year"] as const).map((k) => (
          <Link
            key={k}
            href={qs({ periode: k })}
            aria-current={period.preset === k ? "true" : undefined}
            className={cn("rounded-lg border px-3 py-2 text-sm font-semibold", period.preset === k ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:bg-muted")}
          >
            {PERIOD_PRESETS[k]}
          </Link>
        ))}
      </div>
      <form method="get" action={basePath} className="flex flex-wrap items-end gap-2">
        {Object.entries(extra).map(([k, v]) => (v ? <input key={k} type="hidden" name={k} value={v} /> : null))}
        <input type="hidden" name="periode" value="custom" />
        <label className="text-xs text-muted-foreground">Du<Input type="date" name="from" defaultValue={period.from} className="h-9 w-40" /></label>
        <label className="text-xs text-muted-foreground">Au<Input type="date" name="to" defaultValue={period.to} className="h-9 w-40" /></label>
        <Button type="submit" variant={period.preset === "custom" ? "default" : "outline"}>Appliquer</Button>
      </form>
    </div>
  );
}
