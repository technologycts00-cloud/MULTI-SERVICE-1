"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button, type ButtonProps } from "@/components/ui/button";
import type { ActionResult } from "@/lib/action-result";

/**
 * Bouton qui exécute une Server Action, avec confirmation facultative (boîte native <dialog>),
 * affichage de l'erreur renvoyée par le serveur, et rafraîchissement de la page en cas de succès.
 */
export function ActionButton({
  action,
  children,
  confirm,
  variant = "outline",
  size = "sm",
  redirectTo,
}: {
  action: () => Promise<ActionResult>;
  children: React.ReactNode;
  confirm?: { title: string; description: string; confirmLabel: string };
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  redirectTo?: string;
}) {
  const router = useRouter();
  const dialog = useRef<HTMLDialogElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function run() {
    setError(null);
    start(async () => {
      const res = await action();
      dialog.current?.close();
      if (!res.ok) {
        setError(res.error);
        return;
      }
      if (redirectTo) router.push(redirectTo);
      else router.refresh();
    });
  }

  return (
    <>
      <Button
        type="button"
        variant={variant}
        size={size}
        disabled={pending}
        onClick={() => (confirm ? dialog.current?.showModal() : run())}
      >
        {pending ? "En cours…" : children}
      </Button>
      {error && (
        <p role="alert" className="w-full rounded-lg bg-red-50 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}
      {confirm && (
        <dialog
          ref={dialog}
          className="m-auto w-[min(92vw,26rem)] rounded-xl border border-border p-0 shadow-xl backdrop:bg-black/40"
        >
          <div className="space-y-4 p-5">
            <h2 className="text-lg font-bold">{confirm.title}</h2>
            <p className="text-sm text-muted-foreground">{confirm.description}</p>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => dialog.current?.close()} disabled={pending}>
                Annuler
              </Button>
              <Button
                type="button"
                variant={variant === "destructive" ? "destructive" : "default"}
                onClick={run}
                disabled={pending}
              >
                {pending ? "En cours…" : confirm.confirmLabel}
              </Button>
            </div>
          </div>
        </dialog>
      )}
    </>
  );
}

