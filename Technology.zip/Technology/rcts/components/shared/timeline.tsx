import { cn, formatDateTime } from "@/lib/utils";

export interface TimelineEvent {
  at: string;
  title: string;
  detail?: string | null;
  tone: "blue" | "green" | "red" | "yellow";
}

const DOT = { blue: "bg-primary", green: "bg-success", red: "bg-destructive", yellow: "bg-accent" };

export function Timeline({ events }: { events: TimelineEvent[] }) {
  const sorted = [...events].sort((a, b) => (a.at < b.at ? 1 : -1));
  if (sorted.length === 0) return <p className="text-sm text-muted-foreground">Aucun événement.</p>;
  return (
    <ol className="space-y-4 border-l-2 border-border pl-5">
      {sorted.map((e, i) => (
        <li key={i} className="relative">
          <span className={cn("absolute -left-[1.6rem] top-1.5 size-2.5 rounded-full ring-4 ring-white", DOT[e.tone])} aria-hidden />
          <div className="text-sm font-semibold">{e.title}</div>
          {e.detail && <div className="text-xs text-muted-foreground">{e.detail}</div>}
          <div className="text-xs text-muted-foreground">{formatDateTime(e.at)}</div>
        </li>
      ))}
    </ol>
  );
}
