import Link from "next/link";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";

export interface FilterSelect {
  name: string;
  label: string;
  value: string | undefined;
  options: { value: string; label: string }[];
  allLabel: string;
}

/**
 * Barre de recherche + filtres : un simple formulaire GET (marche sans JavaScript,
 * l'URL reste partageable, la pagination conserve les filtres).
 */
export function ListFilters({
  basePath,
  q,
  placeholder,
  selects = [],
  archivedToggle,
}: {
  basePath: string;
  q: string | undefined;
  placeholder: string;
  selects?: FilterSelect[];
  archivedToggle?: { checked: boolean; label: string };
}) {
  const active = Boolean(q) || selects.some((s) => s.value) || archivedToggle?.checked;
  return (
    <form method="get" action={basePath} className="flex flex-col gap-3 rounded-xl border border-border bg-white p-3 shadow-sm md:flex-row md:flex-wrap md:items-end">
      <div className="md:min-w-64 md:flex-1">
        <label htmlFor="q" className="sr-only">
          Rechercher
        </label>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input id="q" name="q" defaultValue={q ?? ""} placeholder={placeholder} className="pl-9" autoComplete="off" />
        </div>
      </div>
      {selects.map((s) => (
        <div key={s.name} className="md:w-48">
          <label htmlFor={s.name} className="sr-only">
            {s.label}
          </label>
          <Select id={s.name} name={s.name} defaultValue={s.value ?? ""}>
            <option value="">{s.allLabel}</option>
            {s.options.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </Select>
        </div>
      ))}
      {archivedToggle && (
        <label className="flex h-10 items-center gap-2 text-sm">
          <input type="checkbox" name="archives" value="1" defaultChecked={archivedToggle.checked} className="size-4 accent-primary" />
          {archivedToggle.label}
        </label>
      )}
      <div className="flex gap-2">
        <Button type="submit">Rechercher</Button>
        {active && (
          <Button asChild variant="outline">
            <Link href={basePath}>Réinitialiser</Link>
          </Button>
        )}
      </div>
    </form>
  );
}

