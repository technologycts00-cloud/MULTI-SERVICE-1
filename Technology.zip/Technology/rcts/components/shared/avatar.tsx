import { cn } from "@/lib/utils";

const SIZES = { sm: "size-8 text-xs", md: "size-10 text-sm", lg: "size-16 text-xl", xl: "size-28 text-3xl" };

/** Photo ou initiales. */
export function Avatar({ first, last, src, size = "md" }: { first: string; last: string; src?: string | null; size?: keyof typeof SIZES }) {
  const initials = `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={src} alt={`${first} ${last}`} className={cn("shrink-0 rounded-full border border-border object-cover", SIZES[size])} />
  ) : (
    <div
      aria-hidden
      className={cn("flex shrink-0 items-center justify-center rounded-full bg-primary font-black text-primary-foreground", SIZES[size])}
    >
      {initials}
    </div>
  );
}
