import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { PAGE_SIZE } from "@/lib/search";
import { cn } from "@/lib/utils";

/** Pagination par liens (rendu serveur) : conserve les filtres de l'URL. */
export function Pagination({
  page,
  total,
  basePath,
  params,
  pageParam = "page",
  pageSize = PAGE_SIZE,
}: {
  page: number;
  total: number;
  basePath: string;
  params: Record<string, string | undefined>;
  pageParam?: string;
  pageSize?: number;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);

  const href = (p: number) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) sp.set(k, v);
    if (p > 1) sp.set(pageParam, String(p));
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  };

  const btn =
    "inline-flex h-9 items-center gap-1 rounded-lg border border-border bg-white px-3 text-sm font-medium";

  return (
    <nav aria-label="Pagination" className="flex flex-wrap items-center justify-between gap-3 text-sm">
      <span className="text-muted-foreground">
        {total === 0 ? "Aucun résultat" : `${from}–${to} sur ${total}`}
      </span>
      <div className="flex items-center gap-2">
        {page > 1 ? (
          <Link href={href(page - 1)} className={cn(btn, "hover:bg-muted")}>
            <ChevronLeft className="size-4" aria-hidden /> Précédent
          </Link>
        ) : (
          <span className={cn(btn, "pointer-events-none opacity-40")} aria-disabled>
            <ChevronLeft className="size-4" aria-hidden /> Précédent
          </span>
        )}
        <span className="px-1 text-muted-foreground">
          Page {page} / {pages}
        </span>
        {page < pages ? (
          <Link href={href(page + 1)} className={cn(btn, "hover:bg-muted")}>
            Suivant <ChevronRight className="size-4" aria-hidden />
          </Link>
        ) : (
          <span className={cn(btn, "pointer-events-none opacity-40")} aria-disabled>
            Suivant <ChevronRight className="size-4" aria-hidden />
          </span>
        )}
      </div>
    </nav>
  );
}

