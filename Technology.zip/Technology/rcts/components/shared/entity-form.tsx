"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm, type FieldValues, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { ZodType } from "zod";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";

export interface FieldSpec {
  name: string;
  label: string;
  type?: "text" | "textarea" | "select" | "money" | "number" | "tel" | "email" | "password";
  options?: { value: string; label: string }[];
  required?: boolean;
  wide?: boolean;
  hint?: string;
}

/**
 * Formulaire générique (react-hook-form + Zod). Le schéma est fourni par un composant client enveloppe,
 * les champs sont décrits par `fields`. La Server Action reçoit les valeurs brutes et revalide tout côté serveur.
 */
export function EntityForm<TIn extends FieldValues>({
  schema,
  fields,
  defaults,
  submitLabel,
  save,
  redirectTo,
}: {
  schema: ZodType<unknown, TIn>;
  fields: FieldSpec[];
  defaults: TIn;
  submitLabel: string;
  save: (raw: unknown) => Promise<ActionResult<{ id: string }>>;
  redirectTo: (id: string) => string;
}) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const { register, handleSubmit, getValues, setError, formState: { errors } } = useForm<TIn>({
    resolver: zodResolver(schema as never) as Resolver<TIn>,
    defaultValues: defaults as never,
  });

  const onValid = () => {
    setServerError(null);
    start(async () => {
      const res = await save(getValues());
      if (!res.ok) {
        setServerError(res.error);
        for (const [n, m] of Object.entries(res.fieldErrors ?? {})) setError(n as never, { message: m });
        return;
      }
      router.push(redirectTo(res.id));
      router.refresh();
    });
  };

  const err = (n: string) => (errors as Record<string, { message?: string } | undefined>)[n]?.message;

  return (
    <form onSubmit={handleSubmit(onValid)} noValidate className="space-y-4">
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          {fields.map((f) => {
            const common = { id: f.name, "aria-invalid": !!err(f.name), ...register(f.name as never) };
            return (
              <Field key={f.name} id={f.name} label={f.label} required={f.required} hint={f.hint} error={err(f.name)} className={f.wide ? "md:col-span-2" : undefined}>
                {f.type === "textarea" ? (
                  <Textarea {...common} />
                ) : f.type === "select" ? (
                  <Select {...common}>
                    {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </Select>
                ) : (
                  <Input {...common} type={f.type === "tel" ? "tel" : f.type === "email" ? "email" : f.type === "password" ? "password" : "text"} autoComplete={f.type === "password" ? "new-password" : undefined} inputMode={f.type === "money" ? "decimal" : f.type === "number" ? "numeric" : undefined} />
                )}
              </Field>
            );
          })}
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>{pending ? "Enregistrement…" : submitLabel}</Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
