export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">{children}</div>;
}

export function Stat({ label, value, tone }: { label: string; value: string; tone?: "red" | "green" }) {
  return (
    <div className="rounded-xl border border-border bg-white p-4 shadow-sm">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={`text-xl font-black tabular-nums ${tone === "red" ? "text-destructive" : tone === "green" ? "text-success" : ""}`}>{value}</div>
    </div>
  );
}
