"use client";

import { EntityForm } from "@/components/shared/entity-form";
import type { ActionResult } from "@/lib/action-result";
import { serviceSchema, type ServiceFormInput } from "@/lib/validations/party";

export function ServiceForm({ id, defaults, save }: { id: string | null; defaults: ServiceFormInput; save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string }>> }) {
  return (
    <EntityForm
      schema={serviceSchema}
      defaults={defaults}
      submitLabel={id ? "Enregistrer" : "Créer le service"}
      save={(raw) => save(id, raw)}
      redirectTo={() => "/services"}
      fields={[
        { name: "name", label: "Nom du service", required: true, wide: true },
        { name: "category", label: "Catégorie" },
        { name: "unit", label: "Unité (page, heure, unité…)", required: true },
        { name: "unit_price", label: "Prix unitaire (HTG)", type: "money", required: true },
        { name: "is_active", label: "Statut", type: "select", options: [{ value: "true", label: "Actif" }, { value: "false", label: "Inactif" }] },
        { name: "description", label: "Description", type: "textarea", wide: true },
      ]}
    />
  );
}
