"use client";

import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";

interface Props {
  customers: { id: string; name: string; phone: string | null }[];
  services: { id: string; name: string; unit_price: number; unit: string }[];
  staff: { id: string; full_name: string }[];
  defaultCustomer?: string;
  create: (raw: unknown) => Promise<ActionResult<{ id: string; number: string }>>;
}

export function OrderForm({ customers, services, staff, defaultCustomer, create }: Props) {
  const router = useRouter();
  const [v, setV] = useState({
    customer_id: defaultCustomer ?? "", service_id: "", quantity: "1", unit_price: "", due_date: "",
    responsible_id: "", comment: "", amount_paid: "0", method: "ESPECES", reference: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const set = (k: keyof typeof v) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setV((s) => ({ ...s, [k]: e.target.value }));
  const service = services.find((s) => s.id === v.service_id);
  const total = useMemo(() => {
    const q = Number(v.quantity) || 0;
    const p = v.unit_price.trim() !== "" ? Number(v.unit_price.replace(",", ".")) || 0 : (service?.unit_price ?? 0);
    return q * p;
  }, [v.quantity, v.unit_price, service]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    setServerError(null);
    start(async () => {
      const res = await create(v);
      if (!res.ok) {
        setServerError(res.error);
        setErrors(res.fieldErrors ?? {});
        return;
      }
      router.push(`/services/commandes/${res.id}`);
      router.refresh();
    });
  }

  return (
    <form onSubmit={submit} noValidate className="space-y-4">
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          <Field id="customer_id" label="Client" required error={errors.customer_id} hint="Client absent de la liste ? Créez-le d'abord.">
            <Select id="customer_id" value={v.customer_id} onChange={set("customer_id")}>
              <option value="">— Choisir —</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{c.name}{c.phone ? ` · ${c.phone}` : ""}</option>)}
            </Select>
            <Link href="/clients/nouveau" className="text-xs text-primary hover:underline">+ Nouveau client</Link>
          </Field>
          <Field id="service_id" label="Service" required error={errors.service_id}>
            <Select id="service_id" value={v.service_id} onChange={set("service_id")}>
              <option value="">— Choisir —</option>
              {services.map((s) => <option key={s.id} value={s.id}>{s.name} — {formatHTG(s.unit_price)} / {s.unit}</option>)}
            </Select>
          </Field>
          <Field id="quantity" label="Quantité" required error={errors.quantity}>
            <Input id="quantity" inputMode="numeric" value={v.quantity} onChange={set("quantity")} />
          </Field>
          <Field id="unit_price" label="Prix unitaire (HTG)" hint={service ? `Laisser vide pour ${formatHTG(service.unit_price)}` : "Laisser vide pour le prix du catalogue"} error={errors.unit_price}>
            <Input id="unit_price" inputMode="decimal" value={v.unit_price} onChange={set("unit_price")} />
          </Field>
          <Field id="due_date" label="Date d'échéance" error={errors.due_date}>
            <Input id="due_date" type="date" value={v.due_date} onChange={set("due_date")} />
          </Field>
          <Field id="responsible_id" label="Responsable" error={errors.responsible_id}>
            <Select id="responsible_id" value={v.responsible_id} onChange={set("responsible_id")}>
              <option value="">Aucun</option>
              {staff.map((s) => <option key={s.id} value={s.id}>{s.full_name}</option>)}
            </Select>
          </Field>
          <Field id="comment" label="Commentaire" className="md:col-span-2" error={errors.comment}>
            <Textarea id="comment" value={v.comment} onChange={set("comment")} />
          </Field>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-3">
          <div className="md:col-span-3 flex items-baseline justify-between rounded-lg bg-muted px-4 py-3">
            <span className="text-sm text-muted-foreground">Total de la commande</span>
            <span className="text-2xl font-black tabular-nums">{formatHTG(total)}</span>
          </div>
          <Field id="amount_paid" label="Acompte versé (HTG)" error={errors.amount_paid}>
            <Input id="amount_paid" inputMode="decimal" value={v.amount_paid} onChange={set("amount_paid")} />
          </Field>
          <Field id="method" label="Mode de paiement" error={errors.method}>
            <Select id="method" value={v.method} onChange={set("method")}>
              {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </Select>
          </Field>
          <Field id="reference" label="Référence (MonCash, virement…)" error={errors.reference}>
            <Input id="reference" value={v.reference} onChange={set("reference")} />
          </Field>
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer la commande"}</Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
