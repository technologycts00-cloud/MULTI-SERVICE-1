"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Select } from "@/components/ui/select";
import type { ActionResult } from "@/lib/action-result";
import { SERVICE_ORDER_STATUS, options } from "@/lib/labels";

export function OrderStatusSelect({ value, change }: { value: string; change: (status: string) => Promise<ActionResult> }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <div className="space-y-1">
      <Select
        aria-label="Statut de la commande"
        value={value}
        disabled={pending}
        className="h-9 w-44"
        onChange={(e) => {
          const next = e.target.value;
          setError(null);
          start(async () => {
            const res = await change(next);
            if (!res.ok) setError(res.error);
            router.refresh();
          });
        }}
      >
        {options(SERVICE_ORDER_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </Select>
      {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
