"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { METHOD_LABELS } from "@/lib/labels";
import { recordPaymentAction } from "@/app/(app)/paiements/actions";

/** Encaissement d'un solde de commande (même Server Action que la page Paiements). */
export function PayOrderForm({ orderId, balance }: { orderId: string; balance: number }) {
  const router = useRouter();
  const [amount, setAmount] = useState(String(balance));
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-wrap items-center gap-2 rounded-lg bg-muted p-3"
      onSubmit={(e) => {
        e.preventDefault();
        setMsg(null);
        start(async () => {
          const res = await recordPaymentAction({ kind: "SERVICE", target_id: orderId, amount, method, reference });
          if (!res.ok) return setMsg({ ok: false, text: res.fieldErrors?.amount ?? res.error });
          setMsg({ ok: true, text: `Paiement enregistré — reçu ${res.receipt_number}` });
          router.refresh();
        });
      }}
    >
      <span className="text-sm font-semibold">Encaisser</span>
      <Input aria-label="Montant" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-9 w-32" />
      <Select aria-label="Mode de paiement" value={method} onChange={(e) => setMethod(e.target.value)} className="h-9 w-32">
        {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
      </Select>
      {method !== "ESPECES" && <Input aria-label="Référence" placeholder="Référence" value={reference} onChange={(e) => setReference(e.target.value)} className="h-9 w-36" />}
      <Button type="submit" size="sm" disabled={pending}>{pending ? "…" : "Valider"}</Button>
      {msg && <p role={msg.ok ? "status" : "alert"} className={msg.ok ? "w-full text-xs text-success" : "w-full text-xs text-destructive"}>{msg.text}</p>}
    </form>
  );
}
