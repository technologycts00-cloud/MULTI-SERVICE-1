"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { issueInvoiceAction } from "@/app/(app)/paiements/actions";

/** Émet (ou retrouve) la facture d'une inscription / vente / commande de service, puis l'ouvre. */
export function InvoiceButton({ kind, targetId }: { kind: "INSCRIPTION" | "VENTE" | "SERVICE"; targetId: string }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <>
      <Button
        type="button"
        variant="outline"
        disabled={pending}
        onClick={() =>
          start(async () => {
            const res = await issueInvoiceAction(kind, targetId);
            if (!res.ok) return setError(res.error);
            router.push(`/factures/${res.invoice_id}`);
          })
        }
      >
        <FileText aria-hidden /> {pending ? "…" : "Facture"}
      </Button>
      {error && <span role="alert" className="text-xs text-destructive">{error}</span>}
    </>
  );
}
