import { OrgHeader } from "@/components/documents/org-header";
import { METHOD_LABELS } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { ReceiptData } from "@/services/documents";

export type ReceiptFormat = "a5" | "ticket";

function Row({ k, v, strong, red }: { k: string; v: string; strong?: boolean; red?: boolean }) {
  return (
    <div className={cn("flex justify-between gap-3 py-0.5 text-sm", strong && "border-t border-black/30 pt-1 font-black")}>
      <span>{k}</span>
      <span className={cn("tabular-nums", red && "text-destructive")}>{v}</span>
    </div>
  );
}

export function ReceiptView({ data, format }: { data: ReceiptData; format: ReceiptFormat }) {
  const { receipt: r, payment: p, context: c, org } = data;
  const ticket = format === "ticket";
  const voided = r.status === "ANNULE";

  return (
    <>
      <style>{`@media print { @page { size: ${ticket ? "80mm auto" : "A5 portrait"}; margin: ${ticket ? "4mm" : "10mm"}; } body { background:#fff !important; } }`}</style>
      <article
        className={cn(
          "relative mx-auto space-y-3 bg-white text-black",
          ticket ? "w-[80mm] max-w-full p-3 text-[13px]" : "w-full max-w-[148mm] rounded-xl border border-border p-6 shadow-sm",
          "print:rounded-none print:border-0 print:shadow-none",
        )}
      >
        <OrgHeader org={org} compact={ticket} />
        <div className={cn(ticket && "text-center")}>
          <h1 className="text-base font-black uppercase">Reçu de paiement</h1>
          <div className="font-mono text-sm font-bold">{r.receipt_number}</div>
          <div className="text-xs text-muted-foreground">{formatDateTime(r.issued_at)}</div>
        </div>

        {voided && (
          <div className="rounded border-2 border-destructive p-2 text-center text-sm font-black uppercase text-destructive">
            Reçu annulé{p.void_reason ? ` — ${p.void_reason}` : ""}
          </div>
        )}

        <div className="space-y-0.5 text-sm">
          <Row k="Reçu de" v={r.payer_name} />
          {c.student_code && <Row k="ID étudiant" v={c.student_code} />}
          {c.reference_number && <Row k="Référence" v={c.reference_number} />}
          <Row k="Objet" v={c.label ?? r.description ?? "—"} />
        </div>

        {c.items && c.items.length > 0 && (
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-black/40 text-left">
                <th className="py-1 font-semibold">Article</th>
                <th className="py-1 text-right font-semibold">Qté</th>
                <th className="py-1 text-right font-semibold">Total</th>
              </tr>
            </thead>
            <tbody>
              {c.items.map((i, n) => (
                <tr key={n} className="align-top">
                  <td className="py-0.5 pr-2">
                    {i.description}
                    <div className="text-[10px] text-muted-foreground">{formatHTG(i.unit_price)} / unité</div>
                  </td>
                  <td className="py-0.5 text-right tabular-nums">{i.quantity}</td>
                  <td className="py-0.5 text-right tabular-nums">{formatHTG(i.line_total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        <div className="border-t border-dashed border-black/40 pt-2">
          {Number(c.discount ?? 0) > 0 && <Row k="Réduction" v={`− ${formatHTG(c.discount)}`} />}
          <Row k="Total à payer" v={formatHTG(r.total_due)} />
          <Row k={`Montant payé (${METHOD_LABELS[r.method] ?? r.method})`} v={formatHTG(r.amount)} strong />
          <Row k="Solde restant" v={formatHTG(r.balance_after)} red={Number(r.balance_after) > 0} />
          {p.reference && <Row k="Réf. transaction" v={p.reference} />}
        </div>

        <footer className={cn("space-y-1 pt-2 text-xs text-muted-foreground", ticket && "text-center")}>
          <div>Encaissé par : {data.issuer ?? "—"}</div>
          <div>Merci de votre confiance.</div>
        </footer>
      </article>
    </>
  );
}
