import { OrgHeader } from "@/components/documents/org-header";
import { METHOD_LABELS, formatDate } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { InvoiceData } from "@/services/documents";

export function InvoiceView({ data }: { data: InvoiceData }) {
  const { invoice: inv, totals: t, org, client } = data;
  const voided = inv.status === "ANNULE";
  return (
    <>
      <style>{`@media print { @page { size: A4 portrait; margin: 14mm; } body { background:#fff !important; } }`}</style>
      <article className="mx-auto w-full max-w-[210mm] space-y-5 rounded-xl border border-border bg-white p-6 text-black shadow-sm sm:p-8 print:rounded-none print:border-0 print:p-0 print:shadow-none">
        <OrgHeader org={org} />
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black uppercase text-primary">Facture</h1>
            <div className="font-mono text-sm font-bold">{inv.invoice_number}</div>
            <div className="text-xs text-muted-foreground">Émise le {formatDateTime(inv.issued_at)}</div>
            {inv.due_date && <div className="text-xs text-muted-foreground">Échéance : {formatDate(inv.due_date)}</div>}
          </div>
          <div className="min-w-[12rem] rounded-lg bg-muted p-3 text-sm">
            <div className="text-xs font-semibold uppercase text-muted-foreground">Facturé à</div>
            <div className="font-bold">{inv.client_name}</div>
            {client.code && <div className="text-xs">ID : {client.code}</div>}
            {client.phone && <div className="text-xs">{client.phone}</div>}
            {client.address && <div className="text-xs">{client.address}</div>}
          </div>
        </div>

        {voided && (
          <div className="rounded border-2 border-destructive p-2 text-center font-black uppercase text-destructive">
            Facture annulée
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-primary text-left">
                <th className="py-2">Description</th>
                <th className="py-2 text-right">Qté</th>
                <th className="py-2 text-right">Prix unitaire</th>
                <th className="py-2 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {data.lines.map((l, i) => (
                <tr key={i} className="border-b border-border">
                  <td className="py-2 pr-2">{l.description}</td>
                  <td className="py-2 text-right tabular-nums">{l.quantity}</td>
                  <td className="py-2 text-right tabular-nums">{formatHTG(l.unit_price)}</td>
                  <td className="py-2 text-right tabular-nums">{formatHTG(l.line_total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="ml-auto w-full max-w-xs space-y-1 text-sm">
          {Number(t.discount) > 0 && (
            <div className="flex justify-between">
              <span>Réduction</span>
              <span className="tabular-nums">− {formatHTG(t.discount)}</span>
            </div>
          )}
          <div className="flex justify-between border-t border-black/30 pt-1 text-base font-black">
            <span>Total</span>
            <span className="tabular-nums">{formatHTG(t.total)}</span>
          </div>
          <div className="flex justify-between">
            <span>Déjà payé</span>
            <span className="tabular-nums">{formatHTG(t.paid)}</span>
          </div>
          <div className={cn("flex justify-between font-bold", Number(t.balance) > 0 ? "text-destructive" : "text-success")}>
            <span>Reste à payer</span>
            <span className="tabular-nums">{formatHTG(t.balance)}</span>
          </div>
        </div>

        {data.payments.length > 0 && (
          <section>
            <h2 className="mb-1 text-xs font-bold uppercase text-muted-foreground">Paiements reçus</h2>
            <ul className="space-y-0.5 text-xs">
              {data.payments.map((p) => (
                <li key={p.payment_number} className="flex justify-between gap-2">
                  <span>
                    {formatDateTime(p.paid_at)} · {METHOD_LABELS[p.method] ?? p.method}
                  </span>
                  <span className="tabular-nums">{formatHTG(p.amount)}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {inv.notes && <p className="text-xs">{inv.notes}</p>}
        <footer className="border-t border-border pt-2 text-center text-xs text-muted-foreground">
          {org.invoice_footer || "Merci de votre confiance."}
        </footer>
      </article>
    </>
  );
}
