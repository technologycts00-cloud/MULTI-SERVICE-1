"use client";

import { useEffect } from "react";
import Link from "next/link";
import { Download, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";

/** Barre d'actions (masquée à l'impression). `autoPrint` ouvre la boîte d'impression au chargement. */
export function PrintControls({
  autoPrint,
  pdfHref,
  formats,
}: {
  autoPrint?: boolean;
  pdfHref: string;
  formats?: { href: string; label: string; active: boolean }[];
}) {
  useEffect(() => {
    if (autoPrint) {
      const t = setTimeout(() => window.print(), 300);
      return () => clearTimeout(t);
    }
  }, [autoPrint]);

  return (
    <div className="flex flex-wrap items-center gap-2 print:hidden">
      <Button type="button" onClick={() => window.print()}>
        <Printer aria-hidden /> Imprimer
      </Button>
      <Button asChild variant="outline">
        <a href={pdfHref}>
          <Download aria-hidden /> Télécharger le PDF
        </a>
      </Button>
      {formats?.map((f) => (
        <Button key={f.href} asChild variant={f.active ? "accent" : "ghost"} size="sm">
          <Link href={f.href}>{f.label}</Link>
        </Button>
      ))}
    </div>
  );
}
