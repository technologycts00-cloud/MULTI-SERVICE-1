import type { OrgInfo } from "@/services/documents";

export function OrgHeader({ org, compact }: { org: OrgInfo; compact?: boolean }) {
  const lines = [org.address, [org.phone, org.email].filter(Boolean).join(" · ")].filter(Boolean);
  return (
    <header className={compact ? "text-center" : "flex items-start gap-4 border-b-2 border-primary pb-3"}>
      {org.logo_url && !compact && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={org.logo_url} alt="" className="h-14 w-14 object-contain" />
      )}
      <div>
        <div className="text-lg font-black uppercase leading-tight text-primary">{org.org_name || "R.CTS"}</div>
        {org.org_legal_name && <div className="text-xs">{org.org_legal_name}</div>}
        {lines.map((l) => (
          <div key={l} className="text-xs text-muted-foreground">
            {l}
          </div>
        ))}
      </div>
    </header>
  );
}
