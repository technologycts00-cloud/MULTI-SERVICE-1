"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { X } from "lucide-react";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { ActionResult } from "@/lib/action-result";

type Opt = { id: string; code: string; name: string; current_stock: number };

const HELP: Record<string, string> = {
  ENTREE: "Quantité reçue (positive).",
  SORTIE: "Quantité sortie (positive) — motif obligatoire (casse, perte, usage interne…).",
  AJUSTEMENT: "Différence à appliquer : +5 ou −3 — motif obligatoire.",
  INVENTAIRE: "Quantité réellement comptée : le stock est ramené à ce nombre.",
};

export function MovementForm({
  initialProduct,
  search,
  save,
}: {
  initialProduct: Opt | null;
  search: (q: string) => Promise<{ ok: true; items: Opt[] } | { ok: false; error: string }>;
  save: (raw: unknown) => Promise<ActionResult<{ stock_after: number | null }>>;
}) {
  const router = useRouter();
  const [product, setProduct] = useState<Opt | null>(initialProduct);
  const [q, setQ] = useState("");
  const [items, setItems] = useState<Opt[]>([]);
  const [type, setType] = useState("ENTREE");
  const [quantity, setQuantity] = useState("");
  const [reason, setReason] = useState("");
  const [reference, setReference] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, start] = useTransition();

  useEffect(() => {
    const t = setTimeout(async () => {
      if (q.trim().length < 2) return setItems([]);
      const r = await search(q);
      if (r.ok) setItems(r.items);
    }, 250);
    return () => clearTimeout(t);
  }, [q, search]);

  return (
    <Card>
      <CardHeader><CardTitle>Mouvement de stock</CardTitle></CardHeader>
      <CardContent>
        <form
          className="grid gap-4 md:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            setError(null);
            setOk(null);
            start(async () => {
              const res = await save({ product_id: product?.id ?? "", type, quantity, reason, reference });
              if (!res.ok) return setError(res.error);
              setOk(`Enregistré — nouveau stock : ${res.stock_after ?? "—"}`);
              setQuantity("");
              setReason("");
              setReference("");
              setProduct((p) => (p && res.stock_after !== null ? { ...p, current_stock: res.stock_after } : p));
              router.refresh();
            });
          }}
        >
          <Field id="mv-product" label="Produit" required>
            {product ? (
              <div className="flex items-center justify-between rounded-lg border border-border bg-muted px-3 py-2 text-sm">
                <span><span className="font-semibold">{product.name}</span> <span className="text-muted-foreground">· stock {product.current_stock}</span></span>
                <button type="button" aria-label="Changer de produit" onClick={() => setProduct(null)}><X className="size-4" /></button>
              </div>
            ) : (
              <div className="relative">
                <Input id="mv-product" placeholder="Nom ou code (2 lettres)" value={q} onChange={(e) => setQ(e.target.value)} autoComplete="off" />
                {items.length > 0 && (
                  <ul className="absolute z-10 mt-1 w-full overflow-hidden rounded-lg border border-border bg-white shadow-lg">
                    {items.map((i) => (
                      <li key={i.id}><button type="button" className="flex w-full justify-between px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => { setProduct(i); setQ(""); setItems([]); }}><span className="font-semibold">{i.name}</span><span className="text-xs text-muted-foreground">stock {i.current_stock}</span></button></li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </Field>
          <Field id="mv-type" label="Type" required>
            <Select id="mv-type" value={type} onChange={(e) => setType(e.target.value)}>
              <option value="ENTREE">Entrée</option>
              <option value="SORTIE">Sortie</option>
              <option value="AJUSTEMENT">Ajustement</option>
              <option value="INVENTAIRE">Inventaire</option>
            </Select>
          </Field>
          <Field id="mv-qty" label="Quantité" required hint={HELP[type]}>
            <Input id="mv-qty" inputMode="numeric" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
          </Field>
          <Field id="mv-reason" label={type === "SORTIE" || type === "AJUSTEMENT" ? "Motif (obligatoire)" : "Motif"}>
            <Input id="mv-reason" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={200} />
          </Field>
          <Field id="mv-ref" label="Référence" className="md:col-span-2">
            <Input id="mv-ref" value={reference} onChange={(e) => setReference(e.target.value)} maxLength={80} />
          </Field>
          <div className="space-y-2 md:col-span-2">
            <FormBanner error={error} />
            {ok && <p role="status" className="rounded-lg bg-green-50 px-3 py-2 text-sm text-success">{ok}</p>}
            <Button type="submit" disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer le mouvement"}</Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
