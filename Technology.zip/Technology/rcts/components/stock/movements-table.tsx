import { StatusBadge } from "@/components/ui/badge";
import { MOVEMENT_TYPES } from "@/lib/labels";
import { cn, formatDateTime } from "@/lib/utils";
import type { MovementRow } from "@/services/products";

export function MovementsTable({ rows, showProduct = true }: { rows: MovementRow[]; showProduct?: boolean }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-6 text-center text-sm text-muted-foreground">Aucun mouvement de stock.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Date</th>
              {showProduct && <th className="px-4 py-3">Produit</th>}
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3 text-right">Quantité</th>
              <th className="px-4 py-3 text-right">Avant → après</th>
              <th className="px-4 py-3">Motif</th>
              <th className="px-4 py-3">Par</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((m) => (
              <tr key={m.id}>
                <td className="whitespace-nowrap px-4 py-3">{formatDateTime(m.created_at)}</td>
                {showProduct && <td className="px-4 py-3 font-semibold">{m.products ? m.products.name : "—"}</td>}
                <td className="px-4 py-3"><StatusBadge map={MOVEMENT_TYPES} value={m.movement_type} /></td>
                <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", m.quantity_change > 0 ? "text-success" : "text-destructive")}>
                  {m.quantity_change > 0 ? "+" : ""}{m.quantity_change}
                </td>
                <td className="px-4 py-3 text-right tabular-nums">{m.stock_before} → {m.stock_after}</td>
                <td className="px-4 py-3">{m.reason ?? m.reference ?? "—"}</td>
                <td className="px-4 py-3">{m.user_name ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
