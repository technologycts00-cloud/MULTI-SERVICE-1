import Link from "next/link";
import { StatusBadge } from "@/components/ui/badge";
import { DURATION_UNITS, TRAINING_STATUS, formatDate } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";
import type { TrainingListRow } from "@/services/trainings";

export function durationText(v: number | string, unit: string) {
  const n = Number(v);
  return `${Number.isInteger(n) ? n : n.toLocaleString("fr-FR")} ${DURATION_UNITS[unit] ?? unit}`;
}

export function TrainingsTable({ rows, showFinance }: { rows: TrainingListRow[]; showFinance: boolean }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucune formation trouvée.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Formation</th>
              <th className="px-4 py-3">Durée</th>
              {showFinance && <th className="px-4 py-3 text-right">Prix</th>}
              <th className="px-4 py-3">Formateur</th>
              <th className="px-4 py-3">Début</th>
              <th className="px-4 py-3 text-right">Places</th>
              <th className="px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((t) => {
              const full = t.max_students !== null && t.enrolled >= t.max_students;
              return (
                <tr key={t.id} className="hover:bg-muted/50">
                  <td className="px-4 py-3 font-semibold">
                    <Link href={`/formations/${t.id}`} className="hover:text-primary">{t.name}</Link>
                  </td>
                  <td className="px-4 py-3">{durationText(t.duration_value, t.duration_unit)}</td>
                  {showFinance && <td className="px-4 py-3 text-right tabular-nums">{formatHTG(Number(t.price))}</td>}
                  <td className="px-4 py-3">{t.trainer_name ?? "—"}</td>
                  <td className="px-4 py-3">{formatDate(t.start_date)}</td>
                  <td className={`px-4 py-3 text-right tabular-nums ${full ? "font-semibold text-destructive" : ""}`}>
                    {t.enrolled}{t.max_students !== null ? ` / ${t.max_students}` : ""}
                  </td>
                  <td className="px-4 py-3"><StatusBadge map={TRAINING_STATUS} value={t.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
