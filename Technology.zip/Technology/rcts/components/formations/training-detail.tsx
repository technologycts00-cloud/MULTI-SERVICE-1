import Link from "next/link";
import { CalendarDays, Clock, UserRound, Users } from "lucide-react";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ENROLLMENT_STATUS, TRAINING_STATUS, formatDate } from "@/lib/labels";
import { cn, formatHTG } from "@/lib/utils";
import type { TrainingDetail } from "@/services/trainings";
import { durationText } from "./trainings-table";

export function TrainingDetailView({
  detail,
  showFinance,
  canWrite,
  actions,
}: {
  detail: TrainingDetail;
  showFinance: boolean;
  canWrite: boolean;
  actions?: React.ReactNode;
}) {
  const { training: t, trainerName, roster, enrolled } = detail;
  return (
    <div className="space-y-5">
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-black">{t.name}</h2>
            <StatusBadge map={TRAINING_STATUS} value={t.status} />
            {t.is_archived && <Badge>Archivée</Badge>}
          </div>
          {t.description && <p className="text-sm text-muted-foreground">{t.description}</p>}
          <div className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div className="flex items-center gap-2"><Clock className="size-4 text-muted-foreground" aria-hidden />{durationText(t.duration_value, t.duration_unit)}</div>
            <div className="flex items-center gap-2"><CalendarDays className="size-4 text-muted-foreground" aria-hidden />{formatDate(t.start_date)} → {formatDate(t.end_date)}</div>
            <div className="flex items-center gap-2"><UserRound className="size-4 text-muted-foreground" aria-hidden />{trainerName ?? "Aucun formateur"}</div>
            <div className="flex items-center gap-2"><Users className="size-4 text-muted-foreground" aria-hidden />{enrolled}{t.max_students !== null ? ` / ${t.max_students}` : ""} place(s) occupée(s)</div>
          </div>
          {t.schedule && <p className="text-sm"><span className="font-semibold">Horaire :</span> {t.schedule}</p>}
          {showFinance && (
            <div className="flex flex-wrap gap-6 rounded-lg bg-muted p-4 text-sm">
              <div><div className="text-xs text-muted-foreground">Prix</div><div className="font-bold">{formatHTG(Number(t.price))}</div></div>
              <div><div className="text-xs text-muted-foreground">Frais d&apos;inscription</div><div className="font-bold">{formatHTG(Number(t.registration_fee))}</div></div>
            </div>
          )}
          {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Élèves inscrits ({roster.length})</CardTitle></CardHeader>
        <CardContent className="p-0">
          {roster.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">Aucun élève inscrit.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-sm">
                <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Élève</th>
                    <th className="px-4 py-3">Téléphone</th>
                    <th className="px-4 py-3">Inscription</th>
                    <th className="px-4 py-3">Statut</th>
                    {canWrite && <th className="px-4 py-3 text-right">Solde</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {roster.map((r) => (
                    <tr key={r.id} className="hover:bg-muted/50">
                      <td className="px-4 py-3 font-semibold">
                        {r.students ? <Link href={`/eleves/${r.students.id}`} className="hover:text-primary">{r.students.last_name} {r.students.first_name}</Link> : "—"}
                      </td>
                      <td className="px-4 py-3">{r.students?.phone ?? "—"}</td>
                      <td className="px-4 py-3">
                        {canWrite ? <Link href={`/inscriptions/${r.id}`} className="font-mono text-xs hover:text-primary">{r.enrollment_number}</Link> : <span className="font-mono text-xs">{r.enrollment_number}</span>}
                      </td>
                      <td className="px-4 py-3"><StatusBadge map={ENROLLMENT_STATUS} value={r.status} /></td>
                      {canWrite && (
                        <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", Number(r.balance ?? 0) > 0 ? "text-destructive" : "text-success")}>
                          {formatHTG(Number(r.balance ?? 0))}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
