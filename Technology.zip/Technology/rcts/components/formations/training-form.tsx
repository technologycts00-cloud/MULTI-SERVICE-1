"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { DURATION_UNITS, TRAINING_STATUS, options } from "@/lib/labels";
import { trainingSchema, type TrainingFormInput, type TrainingValues } from "@/lib/validations/training";

export function TrainingForm({
  trainingId,
  defaults,
  trainers,
  save,
}: {
  trainingId: string | null;
  defaults: TrainingFormInput;
  trainers: { id: string; label: string }[];
  save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string }>>;
}) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const {
    register,
    handleSubmit,
    getValues,
    setError,
    formState: { errors },
  } = useForm<TrainingFormInput, unknown, TrainingValues>({ resolver: zodResolver(trainingSchema), defaultValues: defaults });

  const onValid = () => {
    setServerError(null);
    start(async () => {
      const res = await save(trainingId, getValues());
      if (!res.ok) {
        setServerError(res.error);
        for (const [name, message] of Object.entries(res.fieldErrors ?? {})) setError(name as keyof TrainingFormInput, { message });
        return;
      }
      router.push(`/formations/${res.id}`);
      router.refresh();
    });
  };

  return (
    <form onSubmit={handleSubmit(onValid)} noValidate className="space-y-4">
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          <Field id="name" label="Nom de la formation" required className="md:col-span-2" error={errors.name?.message}>
            <Input id="name" aria-invalid={!!errors.name} {...register("name")} />
          </Field>
          <Field id="description" label="Description" className="md:col-span-2" error={errors.description?.message}>
            <Textarea id="description" {...register("description")} />
          </Field>
          <Field id="duration_value" label="Durée" required error={errors.duration_value?.message}>
            <Input id="duration_value" inputMode="decimal" {...register("duration_value")} />
          </Field>
          <Field id="duration_unit" label="Unité" required error={errors.duration_unit?.message}>
            <Select id="duration_unit" {...register("duration_unit")}>
              {Object.entries(DURATION_UNITS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Select>
          </Field>
          <Field id="price" label="Prix (HTG)" required error={errors.price?.message}>
            <Input id="price" inputMode="decimal" {...register("price")} />
          </Field>
          <Field id="registration_fee" label="Frais d'inscription (HTG)" error={errors.registration_fee?.message}>
            <Input id="registration_fee" inputMode="decimal" {...register("registration_fee")} />
          </Field>
          <Field id="max_students" label="Capacité maximale" hint="Laisser vide = illimitée" error={errors.max_students?.message}>
            <Input id="max_students" inputMode="numeric" {...register("max_students")} />
          </Field>
          <Field id="trainer_id" label="Formateur" error={errors.trainer_id?.message}>
            <Select id="trainer_id" {...register("trainer_id")}>
              <option value="">Aucun</option>
              {trainers.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
            </Select>
          </Field>
          <Field id="start_date" label="Date de début" error={errors.start_date?.message}>
            <Input id="start_date" type="date" {...register("start_date")} />
          </Field>
          <Field id="end_date" label="Date de fin" error={errors.end_date?.message}>
            <Input id="end_date" type="date" {...register("end_date")} />
          </Field>
          <Field id="schedule" label="Horaire" hint="Ex. Lun-Mer-Ven 8h-10h" error={errors.schedule?.message}>
            <Input id="schedule" {...register("schedule")} />
          </Field>
          <Field id="status" label="Statut" required error={errors.status?.message}>
            <Select id="status" {...register("status")}>
              {options(TRAINING_STATUS).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
          </Field>
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>
          {pending ? "Enregistrement…" : trainingId ? "Enregistrer les modifications" : "Créer la formation"}
        </Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
