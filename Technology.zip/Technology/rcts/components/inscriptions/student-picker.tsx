"use client";

import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { Input } from "@/components/ui/input";
import type { ActionResult } from "@/lib/action-result";
import type { StudentOption } from "@/services/students";

export function StudentPicker({
  value,
  onChange,
  search,
  error,
}: {
  value: StudentOption | null;
  onChange: (s: StudentOption | null) => void;
  search: (q: string) => Promise<ActionResult<{ items: StudentOption[] }>>;
  error?: string;
}) {
  const [q, setQ] = useState("");
  const [items, setItems] = useState<StudentOption[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const seq = useRef(0);

  useEffect(() => {
    const n = ++seq.current;
    const t = setTimeout(async () => {
      if (q.trim().length < 2) {
        setItems([]);
        setMsg(null);
        return;
      }
      const res = await search(q);
      if (n !== seq.current) return;
      if (!res.ok) return setMsg(res.error);
      setItems(res.items);
      setMsg(res.items.length === 0 ? "Aucun élève inscriptible trouvé." : null);
    }, 250);
    return () => clearTimeout(t);
  }, [q, search]);

  if (value) {
    return (
      <div className="flex items-center justify-between rounded-lg border border-border bg-muted px-3 py-2 text-sm">
        <span>
          <span className="font-semibold">{value.last_name} {value.first_name}</span>{" "}
          <span className="font-mono text-xs text-muted-foreground">{value.student_code}</span>
        </span>
        <button type="button" onClick={() => onChange(null)} aria-label="Changer d'élève" className="rounded p-1 hover:bg-white">
          <X className="size-4" />
        </button>
      </div>
    );
  }
  return (
    <div className="relative">
      <Input
        placeholder="Nom, prénom, ID ou téléphone (2 lettres minimum)"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        aria-invalid={!!error}
        autoComplete="off"
      />
      {(items.length > 0 || msg) && (
        <ul className="absolute z-10 mt-1 max-h-64 w-full overflow-auto rounded-lg border border-border bg-white shadow-lg">
          {msg && <li className="px-3 py-2 text-sm text-muted-foreground">{msg}</li>}
          {items.map((s) => (
            <li key={s.id}>
              <button type="button" className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => { onChange(s); setQ(""); setItems([]); }}>
                <span className="font-semibold">{s.last_name} {s.first_name}</span>
                <span className="font-mono text-xs text-muted-foreground">{s.student_code}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
