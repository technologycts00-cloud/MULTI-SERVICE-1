import Link from "next/link";
import { Award, Receipt } from "lucide-react";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ENROLLMENT_STATUS, METHOD_LABELS, PAYMENT_STATUS, RECORD_STATUS, formatDate } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { EnrollmentDetail } from "@/services/enrollments";

function Line({ label, value, bold, tone }: { label: string; value: React.ReactNode; bold?: boolean; tone?: "red" | "green" }) {
  return (
    <div className="flex justify-between gap-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("tabular-nums", bold && "font-bold", tone === "red" && "text-destructive", tone === "green" && "text-success")}>{value}</span>
    </div>
  );
}

export function EnrollmentDetailView({
  detail,
  actions,
  discountControl,
}: {
  detail: EnrollmentDetail;
  actions?: React.ReactNode;
  discountControl?: React.ReactNode;
}) {
  const { enrollment: e, student, training, payments, receipts, certificate } = detail;
  const balance = Number(e.balance ?? 0);
  return (
    <div className="space-y-5">
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-mono text-lg font-black">{e.enrollment_number}</h2>
            <StatusBadge map={ENROLLMENT_STATUS} value={e.status} />
            <StatusBadge map={PAYMENT_STATUS} value={e.payment_status} />
            {certificate && <Badge tone="green"><Award className="size-3" aria-hidden /> Certificat {certificate.certificate_number}</Badge>}
          </div>
          <div className="grid gap-4 text-sm sm:grid-cols-3">
            <div>
              <div className="text-xs text-muted-foreground">Élève</div>
              {student ? <Link href={`/eleves/${student.id}`} className="font-semibold hover:text-primary">{student.last_name} {student.first_name}</Link> : "—"}
              {student && <div className="font-mono text-xs text-muted-foreground">{student.student_code}</div>}
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Formation</div>
              {training ? <Link href={`/formations/${training.id}`} className="font-semibold hover:text-primary">{training.name}</Link> : "—"}
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Inscrit le</div>
              <div className="font-semibold">{formatDate(e.enrolled_on)}</div>
            </div>
          </div>
          {e.notes && <p className="text-sm text-muted-foreground">{e.notes}</p>}
          {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
        </CardContent>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Situation financière</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <Line label="Prix de la formation" value={formatHTG(Number(e.training_price))} />
            <Line label="Frais d'inscription" value={formatHTG(Number(e.registration_fee))} />
            <Line label="Réduction" value={`− ${formatHTG(Number(e.discount))}`} />
            <Line label="Total à payer" value={formatHTG(Number(e.total_due ?? 0))} bold />
            <Line label="Total payé" value={formatHTG(Number(e.amount_paid))} tone="green" />
            <Line label="Solde" value={formatHTG(balance)} bold tone={balance > 0 ? "red" : "green"} />
            {discountControl && <div className="pt-2">{discountControl}</div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Paiements</CardTitle></CardHeader>
          <CardContent>
            {payments === null ? (
              <p className="text-sm text-muted-foreground">Les paiements ne sont pas accessibles avec votre rôle.</p>
            ) : payments.length === 0 ? (
              <p className="text-sm text-muted-foreground">Aucun paiement enregistré.</p>
            ) : (
              <ul className="divide-y divide-border">
                {payments.map((p) => {
                  const r = receipts[p.id];
                  return (
                    <li key={p.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                      <div>
                        <div className="font-semibold tabular-nums">{formatHTG(Number(p.amount))} <span className="font-normal text-muted-foreground">· {METHOD_LABELS[p.method] ?? p.method}</span></div>
                        <div className="text-xs text-muted-foreground">{formatDateTime(p.paid_at)}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        {p.status === "ANNULE" && <StatusBadge map={RECORD_STATUS} value="ANNULE" />}
                        {r && (
                          <Link href={`/recus/${r.id}`} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
                            <Receipt className="size-3.5" aria-hidden /> {r.receipt_number}
                          </Link>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
