"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";
import { enrollmentSchema } from "@/lib/validations/enrollment";
import type { StudentOption } from "@/services/students";
import type { OpenTraining } from "@/services/trainings";
import { StudentPicker } from "./student-picker";

function num(v: string) {
  const n = Number(v.replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

export function EnrollmentForm({
  trainings,
  initialStudent,
  initialTrainingId,
  canCollect,
  save,
  search,
}: {
  trainings: OpenTraining[];
  initialStudent: StudentOption | null;
  initialTrainingId: string;
  canCollect: boolean;
  save: (raw: unknown) => Promise<ActionResult<{ id: string; receipt_number: string | null }>>;
  search: (q: string) => Promise<ActionResult<{ items: StudentOption[] }>>;
}) {
  const router = useRouter();
  const [student, setStudent] = useState<StudentOption | null>(initialStudent);
  const [trainingId, setTrainingId] = useState(initialTrainingId);
  const [discount, setDiscount] = useState("0");
  const [paid, setPaid] = useState("0");
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const training = trainings.find((t) => t.id === trainingId) ?? null;
  const total = training ? training.price + training.registration_fee : 0;
  const disc = num(discount);
  const due = Math.max(total - disc, 0);
  const pay = canCollect ? num(paid) : 0;
  const balance = due - pay;

  const preview = useMemo(() => (training ? { total, due, balance } : null), [training, total, due, balance]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setServerError(null);
    const raw = {
      student_id: student?.id ?? "",
      training_id: trainingId,
      discount,
      amount_paid: canCollect ? paid : "0",
      method,
      reference,
      notes,
    };
    const parsed = enrollmentSchema.safeParse(raw);
    if (!parsed.success) {
      const fe: Record<string, string> = {};
      for (const i of parsed.error.issues) fe[String(i.path[0])] ??= i.message;
      setErrors(fe);
      return;
    }
    setErrors({});
    start(async () => {
      const res = await save(raw);
      if (!res.ok) {
        setServerError(res.error);
        setErrors(res.fieldErrors ?? {});
        return;
      }
      router.push(`/inscriptions/${res.id}`);
      router.refresh();
    });
  }

  return (
    <form onSubmit={submit} noValidate className="grid gap-4 lg:grid-cols-[1fr_20rem]">
      <div className="space-y-4">
        <Card>
          <CardHeader><CardTitle>1. Élève et formation</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Field id="student" label="Élève" required error={errors.student_id}>
              <StudentPicker value={student} onChange={setStudent} search={search} error={errors.student_id} />
            </Field>
            <Field id="training" label="Formation" required error={errors.training_id}>
              <Select id="training" value={trainingId} onChange={(e) => setTrainingId(e.target.value)}>
                <option value="">Choisir une formation</option>
                {trainings.map((t) => (
                  <option key={t.id} value={t.id} disabled={t.places_left === 0}>
                    {t.name} — {formatHTG(t.price)}{t.places_left === 0 ? " (complète)" : t.places_left !== null ? ` (${t.places_left} place(s))` : ""}
                  </option>
                ))}
              </Select>
            </Field>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>2. Paiement</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <Field id="discount" label="Réduction (HTG)" error={errors.discount}>
              <Input id="discount" inputMode="decimal" value={discount} onChange={(e) => setDiscount(e.target.value)} />
            </Field>
            {canCollect ? (
              <>
                <Field id="amount_paid" label="Montant payé maintenant (HTG)" error={errors.amount_paid}>
                  <Input id="amount_paid" inputMode="decimal" value={paid} onChange={(e) => setPaid(e.target.value)} />
                </Field>
                <Field id="method" label="Mode de paiement" error={errors.method}>
                  <Select id="method" value={method} onChange={(e) => setMethod(e.target.value)}>
                    {Object.entries(METHOD_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </Select>
                </Field>
                <Field id="reference" label="Référence (MonCash, NatCash…)" error={errors.reference}>
                  <Input id="reference" value={reference} onChange={(e) => setReference(e.target.value)} />
                </Field>
              </>
            ) : (
              <p className="self-end text-sm text-muted-foreground md:col-span-1">Le paiement sera encaissé par la caisse.</p>
            )}
            <Field id="notes" label="Notes" className="md:col-span-2" error={errors.notes}>
              <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
            </Field>
          </CardContent>
        </Card>
        <FormBanner error={serverError} />
      </div>

      <Card className="h-fit lg:sticky lg:top-24">
        <CardHeader><CardTitle>Récapitulatif</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          {preview ? (
            <>
              <Row label="Prix + inscription" value={formatHTG(preview.total)} />
              <Row label="Réduction" value={`− ${formatHTG(Math.min(disc, preview.total))}`} />
              <Row label="Total à payer" value={formatHTG(preview.due)} bold />
              <Row label="Payé maintenant" value={formatHTG(pay)} />
              <Row label="Solde restant" value={formatHTG(Math.max(preview.balance, 0))} bold danger={preview.balance > 0} />
              {preview.balance < 0 && <p className="text-xs text-destructive">Le montant payé dépasse le total dû.</p>}
            </>
          ) : (
            <p className="text-muted-foreground">Choisissez une formation.</p>
          )}
          <Button type="submit" size="lg" className="mt-3 w-full" disabled={pending}>
            {pending ? "Enregistrement…" : "Enregistrer l'inscription"}
          </Button>
        </CardContent>
      </Card>
    </form>
  );
}

function Row({ label, value, bold, danger }: { label: string; value: string; bold?: boolean; danger?: boolean }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-muted-foreground">{label}</span>
      <span className={`tabular-nums ${bold ? "font-bold" : ""} ${danger ? "text-destructive" : ""}`}>{value}</span>
    </div>
  );
}
