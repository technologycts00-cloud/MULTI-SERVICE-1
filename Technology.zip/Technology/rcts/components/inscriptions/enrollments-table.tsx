import Link from "next/link";
import { StatusBadge } from "@/components/ui/badge";
import { ENROLLMENT_STATUS, PAYMENT_STATUS, formatDate } from "@/lib/labels";
import { cn, formatHTG } from "@/lib/utils";
import type { EnrollmentListRow } from "@/services/enrollments";

export function EnrollmentsTable({ rows }: { rows: EnrollmentListRow[] }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucune inscription trouvée.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">N°</th>
              <th className="px-4 py-3">Élève</th>
              <th className="px-4 py-3">Formation</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3 text-right">Payé</th>
              <th className="px-4 py-3 text-right">Solde</th>
              <th className="px-4 py-3">Paiement</th>
              <th className="px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((e) => {
              const bal = Number(e.balance ?? 0);
              return (
                <tr key={e.id} className="hover:bg-muted/50">
                  <td className="px-4 py-3"><Link href={`/inscriptions/${e.id}`} className="font-mono text-xs font-semibold hover:text-primary">{e.enrollment_number}</Link></td>
                  <td className="px-4 py-3">{e.students.last_name} {e.students.first_name}</td>
                  <td className="px-4 py-3">{e.trainings.name}</td>
                  <td className="px-4 py-3">{formatDate(e.enrolled_on)}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{formatHTG(Number(e.amount_paid))}</td>
                  <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", bal > 0 ? "text-destructive" : "text-success")}>{formatHTG(bal)}</td>
                  <td className="px-4 py-3"><StatusBadge map={PAYMENT_STATUS} value={e.payment_status} /></td>
                  <td className="px-4 py-3"><StatusBadge map={ENROLLMENT_STATUS} value={e.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
