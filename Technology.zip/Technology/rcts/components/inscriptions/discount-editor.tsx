"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { ActionResult } from "@/lib/action-result";

export function DiscountEditor({ current, save }: { current: number; save: (text: string) => Promise<ActionResult> }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(String(current));
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  if (!open) {
    return <Button type="button" size="sm" variant="outline" onClick={() => setOpen(true)}>Modifier la réduction</Button>;
  }
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Input aria-label="Réduction (HTG)" inputMode="decimal" value={value} onChange={(e) => setValue(e.target.value)} className="h-8 w-32" />
        <Button
          type="button"
          size="sm"
          disabled={pending}
          onClick={() =>
            start(async () => {
              const res = await save(value);
              if (!res.ok) return setError(res.error);
              setOpen(false);
              setError(null);
              router.refresh();
            })
          }
        >
          Enregistrer
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={() => setOpen(false)}>Annuler</Button>
      </div>
      {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
