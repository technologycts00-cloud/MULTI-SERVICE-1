import * as React from "react";
import { cn } from "@/lib/utils";
import type { LabelMap, Tone } from "@/lib/labels";

const TONES: Record<Tone, string> = {
  blue: "bg-blue-50 text-primary",
  green: "bg-green-50 text-success",
  yellow: "bg-yellow-100 text-yellow-800",
  red: "bg-red-50 text-destructive",
  slate: "bg-muted text-muted-foreground",
};

export function Badge({ tone = "slate", className, ...props }: React.ComponentProps<"span"> & { tone?: Tone }) {
  return (
    <span
      className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold", TONES[tone], className)}
      {...props}
    />
  );
}

/** Badge dont le texte et la couleur viennent d'une table d'étiquettes (lib/labels). */
export function StatusBadge({ map, value }: { map: LabelMap; value: string | null | undefined }) {
  if (!value) return <span className="text-muted-foreground">—</span>;
  const entry = map[value] ?? { label: value, tone: "slate" as Tone };
  return <Badge tone={entry.tone}>{entry.label}</Badge>;
}
