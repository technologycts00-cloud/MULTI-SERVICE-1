"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  BookOpen, Boxes, Briefcase, CreditCard, FileText, GraduationCap, LayoutDashboard,
  LogOut, Menu, Package, Receipt, Settings, ShoppingCart, Truck, UserCog, Users,
  Wallet, X, ClipboardList, Landmark, Banknote, type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { PwaRegister } from "@/components/pwa/pwa-register";
import type { ModuleKey } from "@/lib/permissions";

const ICONS: Record<ModuleKey, LucideIcon> = {
  dashboard: LayoutDashboard,
  eleves: GraduationCap,
  formations: BookOpen,
  inscriptions: ClipboardList,
  paiements: CreditCard,
  caisse: Banknote,
  ventes: ShoppingCart,
  produits: Package,
  stock: Boxes,
  clients: Users,
  services: Briefcase,
  fournisseurs: Truck,
  depenses: Receipt,
  finances: Landmark,
  rapports: FileText,
  utilisateurs: UserCog,
  parametres: Settings,
};

export interface ShellNavItem {
  key: ModuleKey;
  label: string;
  href: string;
}

interface Props {
  nav: ShellNavItem[];
  userName: string;
  role: string;
  orgName?: string;
  logo?: string | null;
  logout: () => Promise<void>;
  children: React.ReactNode;
}

function NavList({ nav, onNavigate }: { nav: ShellNavItem[]; onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4" aria-label="Navigation principale">
      {nav.map((item) => {
        const Icon = ICONS[item.key] ?? Wallet;
        const active = pathname === item.href || pathname.startsWith(item.href + "/");
        return (
          <Link
            key={item.key}
            href={item.href}
            onClick={onNavigate}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              active ? "bg-accent text-accent-foreground" : "text-sidebar-foreground hover:bg-white/10",
            )}
          >
            <Icon className="size-4 shrink-0" aria-hidden />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function Brand({ logo }: { logo?: string | null }) {
  return (
    <div className="flex items-center gap-3 px-5 py-5">
      {logo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={logo} alt="Logo" className="h-10 w-10 rounded-lg bg-white object-contain" />
      ) : (
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent font-black text-accent-foreground">R</div>
      )}
      <div className="leading-tight text-white">
        <div className="text-base font-black tracking-wide">R.CTS</div>
        <div className="text-[10px] tracking-wider text-blue-200">COMPLEX TECHNOLOGY SERVICES</div>
      </div>
    </div>
  );
}

export function AppShell({ nav, userName, role, logo, logout, children }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[16rem_1fr] print:block">
      {/* Sidebar ordinateur / tablette large */}
      <aside className="no-print sticky top-0 hidden h-screen flex-col bg-sidebar lg:flex">
        <Brand logo={logo} />
        <NavList nav={nav} />
      </aside>

      {/* Menu mobile */}
      {open && (
        <div className="no-print fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-72 max-w-[85%] flex-col bg-sidebar shadow-xl">
            <div className="flex items-center justify-between">
              <Brand logo={logo} />
              <button
                aria-label="Fermer le menu"
                onClick={() => setOpen(false)}
                className="mr-3 rounded-lg p-2 text-white hover:bg-white/10"
              >
                <X className="size-5" />
              </button>
            </div>
            <NavList nav={nav} onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-col">
        <header className="no-print sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-white px-4 lg:px-8">
          <button
            aria-label="Ouvrir le menu"
            onClick={() => setOpen(true)}
            className="rounded-lg p-2 hover:bg-muted lg:hidden"
          >
            <Menu className="size-5" />
          </button>
          <div className="hidden text-sm text-muted-foreground lg:block">Plateforme de gestion R.CTS</div>
          <div className="flex items-center gap-3">
            <PwaRegister showInstall />
            <div className="text-right leading-tight">
              <div className="text-sm font-semibold">{userName}</div>
              <div className="text-xs text-muted-foreground">{role}</div>
            </div>
            <form action={logout}>
              <button
                type="submit"
                title="Déconnexion"
                aria-label="Déconnexion"
                className="rounded-lg p-2 text-destructive hover:bg-red-50"
              >
                <LogOut className="size-5" />
              </button>
            </form>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-8 print:p-0">{children}</main>
      </div>
    </div>
  );
}
