"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2 } from "lucide-react";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS } from "@/lib/labels";
import { formatHTG } from "@/lib/utils";

interface Line { product_id: string; quantity: string; unit_cost: string }

export function PurchaseForm({
  suppliers, products, defaultSupplier, create,
}: {
  suppliers: { id: string; name: string }[];
  products: { id: string; code: string; name: string; purchase_price: number }[];
  defaultSupplier?: string;
  create: (raw: unknown) => Promise<ActionResult<{ id: string; number: string }>>;
}) {
  const router = useRouter();
  const [supplier, setSupplier] = useState(defaultSupplier ?? "");
  const [lines, setLines] = useState<Line[]>([{ product_id: "", quantity: "1", unit_cost: "" }]);
  const [paid, setPaid] = useState("0");
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const total = useMemo(() => lines.reduce((s, l) => s + (Number(l.quantity) || 0) * (Number(l.unit_cost.replace(",", ".")) || 0), 0), [lines]);
  const patch = (i: number, p: Partial<Line>) => setLines((ls) => ls.map((l, k) => (k === i ? { ...l, ...p } : l)));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    setServerError(null);
    start(async () => {
      const res = await create({ supplier_id: supplier, items: lines, amount_paid: paid, method, reference, notes });
      if (!res.ok) {
        setServerError(res.error);
        setErrors(res.fieldErrors ?? {});
        return;
      }
      router.push(`/fournisseurs/achats/${res.id}`);
      router.refresh();
    });
  }

  return (
    <form onSubmit={submit} noValidate className="space-y-4">
      <Card>
        <CardContent className="space-y-4 p-6">
          <Field id="supplier_id" label="Fournisseur" required error={errors.supplier_id}>
            <Select id="supplier_id" value={supplier} onChange={(e) => setSupplier(e.target.value)}>
              <option value="">— Choisir —</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <div className="space-y-2">
            <div className="text-sm font-semibold">Produits achetés</div>
            {lines.map((l, i) => (
              <div key={i} className="grid gap-2 rounded-lg border border-border p-3 sm:grid-cols-[1fr_6rem_8rem_auto]">
                <Select aria-label="Produit" value={l.product_id} onChange={(e) => {
                  const p = products.find((x) => x.id === e.target.value);
                  patch(i, { product_id: e.target.value, unit_cost: l.unit_cost || (p ? String(p.purchase_price) : "") });
                }}>
                  <option value="">— Produit —</option>
                  {products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
                </Select>
                <Input aria-label="Quantité" inputMode="numeric" placeholder="Qté" value={l.quantity} onChange={(e) => patch(i, { quantity: e.target.value })} />
                <Input aria-label="Coût unitaire" inputMode="decimal" placeholder="Coût unitaire" value={l.unit_cost} onChange={(e) => patch(i, { unit_cost: e.target.value })} />
                <Button type="button" variant="ghost" size="icon" aria-label="Supprimer la ligne" disabled={lines.length === 1} onClick={() => setLines((ls) => ls.filter((_, k) => k !== i))}>
                  <Trash2 className="size-4 text-destructive" aria-hidden />
                </Button>
              </div>
            ))}
            {(errors.items || Object.keys(errors).some((k) => k.startsWith("items."))) && (
              <p role="alert" className="text-xs font-medium text-destructive">{errors.items ?? Object.entries(errors).find(([k]) => k.startsWith("items."))?.[1]}</p>
            )}
            <Button type="button" variant="outline" size="sm" onClick={() => setLines((ls) => [...ls, { product_id: "", quantity: "1", unit_cost: "" }])}>
              <Plus aria-hidden /> Ajouter une ligne
            </Button>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-3">
          <div className="flex items-baseline justify-between rounded-lg bg-muted px-4 py-3 md:col-span-3">
            <span className="text-sm text-muted-foreground">Total de l&apos;achat</span>
            <span className="text-2xl font-black tabular-nums">{formatHTG(total)}</span>
          </div>
          <Field id="amount_paid" label="Montant payé maintenant (HTG)" error={errors.amount_paid} hint="Un paiement en espèces sort de la caisse.">
            <Input id="amount_paid" inputMode="decimal" value={paid} onChange={(e) => setPaid(e.target.value)} />
          </Field>
          <Field id="method" label="Mode de paiement">
            <Select id="method" value={method} onChange={(e) => setMethod(e.target.value)}>
              {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </Select>
          </Field>
          <Field id="reference" label="Référence" error={errors.reference}>
            <Input id="reference" value={reference} onChange={(e) => setReference(e.target.value)} />
          </Field>
          <Field id="notes" label="Notes" className="md:col-span-3" error={errors.notes}>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
        </CardContent>
      </Card>
      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer l'achat"}</Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>Annuler</Button>
      </div>
    </form>
  );
}
