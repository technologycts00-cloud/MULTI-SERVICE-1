"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { ActionResult } from "@/lib/action-result";
import { METHOD_LABELS } from "@/lib/labels";

export function PaySupplierForm({ purchaseId, balance, pay }: { purchaseId: string; balance: number; pay: (raw: unknown) => Promise<ActionResult<{ balance: number }>> }) {
  const router = useRouter();
  const [amount, setAmount] = useState(String(balance));
  const [method, setMethod] = useState("ESPECES");
  const [reference, setReference] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-wrap items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        setMsg(null);
        start(async () => {
          const res = await pay({ purchase_id: purchaseId, amount, method, reference });
          if (!res.ok) return setMsg({ ok: false, text: res.fieldErrors?.amount ?? res.error });
          setMsg({ ok: true, text: "Paiement enregistré." });
          router.refresh();
        });
      }}
    >
      <Input aria-label="Montant" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-9 w-32" />
      <Select aria-label="Mode de paiement" value={method} onChange={(e) => setMethod(e.target.value)} className="h-9 w-32">
        {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
      </Select>
      <Input aria-label="Référence" placeholder="Référence" value={reference} onChange={(e) => setReference(e.target.value)} className="h-9 w-36" />
      <Button type="submit" size="sm" disabled={pending}>{pending ? "…" : "Payer"}</Button>
      {msg && <p role={msg.ok ? "status" : "alert"} className={msg.ok ? "w-full text-xs text-success" : "w-full text-xs text-destructive"}>{msg.text}</p>}
    </form>
  );
}
