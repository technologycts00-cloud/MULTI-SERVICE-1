"use client";

import { EntityForm } from "@/components/shared/entity-form";
import type { ActionResult } from "@/lib/action-result";
import { supplierSchema, type SupplierFormInput } from "@/lib/validations/party";

export function SupplierForm({ id, defaults, save }: { id: string | null; defaults: SupplierFormInput; save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string }>> }) {
  return (
    <EntityForm
      schema={supplierSchema}
      defaults={defaults}
      submitLabel={id ? "Enregistrer" : "Créer le fournisseur"}
      save={(raw) => save(id, raw)}
      redirectTo={(i) => `/fournisseurs/${i}`}
      fields={[
        { name: "name", label: "Nom du contact", required: true },
        { name: "company", label: "Entreprise" },
        { name: "phone", label: "Téléphone", type: "tel" },
        { name: "email", label: "E-mail", type: "email" },
        { name: "address", label: "Adresse", wide: true },
        { name: "products_supplied", label: "Produits fournis", wide: true },
        { name: "notes", label: "Notes", type: "textarea", wide: true },
      ]}
    />
  );
}
