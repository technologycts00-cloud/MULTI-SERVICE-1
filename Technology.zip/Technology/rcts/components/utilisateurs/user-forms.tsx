"use client";

import { EntityForm } from "@/components/shared/entity-form";
import type { ActionResult } from "@/lib/action-result";
import { ROLE_LABELS } from "@/lib/labels";
import { createUserSchema, updateUserSchema, type CreateUserInput, type UpdateUserInput } from "@/lib/validations/admin";
import { ROLES } from "@/types";

const roleOptions = ROLES.map((r) => ({ value: r, label: ROLE_LABELS[r] }));

export function CreateUserForm({ save }: { save: (raw: unknown) => Promise<ActionResult<{ id: string }>> }) {
  const defaults: CreateUserInput = { full_name: "", email: "", password: "", role: "SECRETAIRE" };
  return (
    <EntityForm
      schema={createUserSchema}
      defaults={defaults}
      submitLabel="Créer le compte"
      save={save}
      redirectTo={() => "/utilisateurs"}
      fields={[
        { name: "full_name", label: "Nom complet", required: true, wide: true },
        { name: "email", label: "E-mail (identifiant)", type: "email", required: true },
        { name: "role", label: "Rôle", type: "select", options: roleOptions, required: true },
        { name: "password", label: "Mot de passe provisoire", type: "password", required: true, wide: true, hint: "8 caractères minimum, avec lettres et chiffres. L'utilisateur peut le changer via « Mot de passe oublié »." },
      ]}
    />
  );
}

export function EditUserForm({ id, defaults, save, isSelf }: { id: string; defaults: UpdateUserInput; save: (id: string, raw: unknown) => Promise<ActionResult<{ id: string }>>; isSelf: boolean }) {
  return (
    <EntityForm
      schema={updateUserSchema}
      defaults={defaults}
      submitLabel="Enregistrer"
      save={(raw) => save(id, raw)}
      redirectTo={() => "/utilisateurs"}
      fields={[
        { name: "full_name", label: "Nom complet", required: true, wide: true },
        { name: "role", label: "Rôle", type: "select", options: roleOptions, hint: isSelf ? "Vous ne pouvez pas modifier votre propre rôle." : undefined },
        { name: "is_active", label: "Statut du compte", type: "select", options: [{ value: "true", label: "Actif" }, { value: "false", label: "Désactivé (connexion impossible)" }], hint: isSelf ? "Vous ne pouvez pas désactiver votre propre compte." : undefined },
      ]}
    />
  );
}
