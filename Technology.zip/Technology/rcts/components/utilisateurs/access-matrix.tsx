"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Lock, X } from "lucide-react";
import { FormBanner } from "@/components/shared/form-field";
import type { ActionResult } from "@/lib/action-result";
import { cn } from "@/lib/utils";

export interface MatrixRole { role: string; label: string; modules: { key: string; label: string; view: boolean; locked: boolean }[] }

export function AccessMatrix({ roles, save }: { roles: MatrixRole[]; save: (role: string, module: string, canView: boolean) => Promise<ActionResult> }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const toggle = (role: string, module: string, next: boolean) => {
    setError(null);
    start(async () => {
      const res = await save(role, module, next);
      if (!res.ok) setError(res.error);
      else router.refresh();
    });
  };
  return (
    <div className="space-y-4">
      <FormBanner error={error} />
      <div className="grid gap-4 md:grid-cols-2">
        {roles.map((r) => (
          <section key={r.role} className="rounded-xl border border-border bg-white p-4 shadow-sm" aria-label={r.label}>
            <h2 className="mb-3 font-bold">{r.label}</h2>
            <ul className="space-y-1.5">
              {r.modules.map((m) => (
                <li key={m.key} className="flex items-center justify-between gap-3 text-sm">
                  <span>{m.label}</span>
                  {m.locked ? (
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Lock className="size-3" aria-hidden /> Toujours actif</span>
                  ) : (
                    <button
                      type="button"
                      role="switch"
                      aria-checked={m.view}
                      aria-label={`${m.label} pour ${r.label}`}
                      disabled={pending}
                      onClick={() => toggle(r.role, m.key, !m.view)}
                      className={cn("inline-flex h-7 w-14 items-center rounded-full px-1 transition-colors disabled:opacity-60", m.view ? "justify-end bg-success" : "justify-start bg-slate-300")}
                    >
                      <span className="flex size-5 items-center justify-center rounded-full bg-white text-slate-700">
                        {m.view ? <Check className="size-3 text-success" aria-hidden /> : <X className="size-3" aria-hidden />}
                      </span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
