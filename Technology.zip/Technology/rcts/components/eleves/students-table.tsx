import Link from "next/link";
import { Avatar } from "@/components/shared/avatar";
import { StatusBadge } from "@/components/ui/badge";
import { STUDENT_STATUS, formatDate } from "@/lib/labels";
import { cn, formatHTG } from "@/lib/utils";

export interface StudentListRow {
  id: string;
  student_code: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  status: string;
  enrolled_on: string;
  is_archived: boolean;
}

export function StudentsTable({ rows, balances }: { rows: StudentListRow[]; balances?: Record<string, number> }) {
  if (rows.length === 0) {
    return <div className="rounded-xl border border-dashed border-border bg-white p-8 text-center text-sm text-muted-foreground">Aucun élève trouvé.</div>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-muted text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Élève</th>
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Téléphone</th>
              <th className="px-4 py-3">Inscrit le</th>
              <th className="px-4 py-3">Statut</th>
              {balances && <th className="px-4 py-3 text-right">Solde dû</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((s) => {
              const bal = balances?.[s.id] ?? 0;
              return (
                <tr key={s.id} className="hover:bg-muted/50">
                  <td className="px-4 py-3">
                    <Link href={`/eleves/${s.id}`} className="flex items-center gap-3 font-semibold hover:text-primary">
                      <Avatar first={s.first_name} last={s.last_name} size="sm" />
                      {s.last_name} {s.first_name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs">{s.student_code}</td>
                  <td className="px-4 py-3">{s.phone ?? "—"}</td>
                  <td className="px-4 py-3">{formatDate(s.enrolled_on)}</td>
                  <td className="px-4 py-3"><StatusBadge map={STUDENT_STATUS} value={s.status} /></td>
                  {balances && (
                    <td className={cn("px-4 py-3 text-right font-semibold tabular-nums", bal > 0 ? "text-destructive" : "text-success")}>
                      {formatHTG(bal)}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
