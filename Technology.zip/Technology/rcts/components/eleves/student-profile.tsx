import Link from "next/link";
import { Award, Banknote, HandCoins, Mail, MapPin, Phone, Wallet } from "lucide-react";
import { Avatar } from "@/components/shared/avatar";
import { Timeline, type TimelineEvent } from "@/components/shared/timeline";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ENROLLMENT_STATUS, GENDER_LABELS, METHOD_LABELS, PAYMENT_STATUS, STUDENT_STATUS, formatDate } from "@/lib/labels";
import { cn, formatDateTime, formatHTG } from "@/lib/utils";
import type { CertificatesRow, EnrollmentsRow, PaymentsRow, ReceiptsRow, StudentsRow } from "@/types/db";

export type EnrollmentWithTraining = EnrollmentsRow & { trainings: { name: string } | null };
export type CertificateWithTraining = CertificatesRow & { trainings: { name: string } | null };

function Info({ icon: Icon, children }: { icon: typeof Phone; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 text-sm">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden />
      <span className="min-w-0 break-words">{children}</span>
    </div>
  );
}

function age(birth: string | null): string | null {
  if (!birth) return null;
  const b = new Date(birth + "T00:00:00Z");
  const now = new Date();
  let years = now.getUTCFullYear() - b.getUTCFullYear();
  const m = now.getUTCMonth() - b.getUTCMonth();
  if (m < 0 || (m === 0 && now.getUTCDate() < b.getUTCDate())) years--;
  return years >= 0 ? `${years} ans` : null;
}

/** Fiche détaillée d'un élève (affichage pur : toutes les données viennent de la base). */
export function StudentProfile({
  student,
  photoUrl,
  enrollments,
  payments,
  receipts,
  certificates,
  actions,
  photoControls,
}: {
  student: StudentsRow;
  photoUrl: string | null;
  enrollments: EnrollmentWithTraining[];
  /** null = ce rôle n'a pas accès aux informations financières */
  payments: PaymentsRow[] | null;
  receipts: Record<string, ReceiptsRow>;
  certificates: CertificateWithTraining[];
  actions?: React.ReactNode;
  photoControls?: React.ReactNode;
}) {
  const showFinance = payments !== null;
  const live = enrollments.filter((e) => e.status !== "ANNULEE");
  const totalDue = live.reduce((s, e) => s + Number(e.total_due ?? 0), 0);
  const totalPaid = live.reduce((s, e) => s + Number(e.amount_paid), 0);
  const balance = live.reduce((s, e) => s + Number(e.balance ?? 0), 0);
  const trainingName = (id: string) => enrollments.find((e) => e.id === id)?.trainings?.name ?? "formation";

  const events: TimelineEvent[] = [{ at: student.created_at, title: "Élève enregistré", tone: "blue" }];
  for (const e of enrollments) {
    events.push({
      at: e.created_at,
      title: `Inscription à « ${e.trainings?.name ?? "formation"} »`,
      detail: e.enrollment_number,
      tone: e.status === "ANNULEE" ? "red" : "green",
    });
  }
  for (const p of payments ?? []) {
    const rc = receipts[p.id];
    events.push({
      at: p.paid_at,
      title: `${p.status === "ANNULE" ? "Paiement annulé" : "Paiement"} de ${formatHTG(p.amount)} (${METHOD_LABELS[p.method] ?? p.method})`,
      detail: [p.enrollment_id ? trainingName(p.enrollment_id) : null, rc ? `Reçu ${rc.receipt_number}` : null]
        .filter(Boolean)
        .join(" · "),
      tone: p.status === "ANNULE" ? "red" : "green",
    });
  }
  for (const c of certificates) {
    events.push({
      at: c.created_at,
      title: `Certificat délivré : ${c.trainings?.name ?? "formation"}`,
      detail: c.certificate_number,
      tone: "blue",
    });
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="flex flex-col gap-5 p-5 md:flex-row md:items-start">
          <div className="flex flex-col items-center gap-3">
            <Avatar first={student.first_name} last={student.last_name} src={photoUrl} size="xl" />
            {photoControls}
          </div>
          <div className="min-w-0 flex-1 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-xl font-black">
                {student.first_name} {student.last_name}
              </h2>
              <StatusBadge map={STUDENT_STATUS} value={student.status} />
              {student.is_archived && <Badge>Archivé</Badge>}
            </div>
            <div className="text-sm text-muted-foreground">
              ID {student.student_code} · inscrit le {formatDate(student.enrolled_on)}
              {student.gender && ` · ${GENDER_LABELS[student.gender]}`}
              {student.birth_date && ` · né(e) le ${formatDate(student.birth_date)} (${age(student.birth_date)})`}
            </div>
            <div className="grid gap-2 md:grid-cols-2">
              {student.phone && <Info icon={Phone}>{student.phone}</Info>}
              {student.email && <Info icon={Mail}>{student.email}</Info>}
              {student.address && <Info icon={MapPin}>{student.address}</Info>}
            </div>
            {student.notes && <p className="rounded-lg bg-muted px-3 py-2 text-sm">{student.notes}</p>}
            {actions && <div className="flex flex-wrap items-center gap-2 pt-1">{actions}</div>}
          </div>
        </CardContent>
      </Card>

      {showFinance && (
        <div className="grid grid-cols-1 gap-3 min-[480px]:grid-cols-3">
          <KpiCard label="Total dû" value={formatHTG(totalDue)} icon={Wallet} tone="blue" />
          <KpiCard label="Total payé" value={formatHTG(totalPaid)} icon={Banknote} tone="green" />
          <KpiCard label="Solde" value={formatHTG(balance)} hint={balance > 0 ? "Reste à payer" : "Tout est soldé"} icon={HandCoins} tone={balance > 0 ? "yellow" : "green"} />
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Formations et inscriptions</CardTitle>
          <CardDescription>{enrollments.length === 0 ? "Aucune inscription" : `${enrollments.length} inscription(s)`}</CardDescription>
        </CardHeader>
        <CardContent>
          {enrollments.length === 0 ? (
            <p className="rounded-lg bg-muted p-4 text-center text-sm text-muted-foreground">Cet élève n&apos;est inscrit à aucune formation.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[34rem] text-left text-sm">
                <thead className="text-xs text-muted-foreground">
                  <tr className="border-b border-border">
                    <th className="py-2 pr-3 font-semibold">Formation</th>
                    <th className="py-2 pr-3 font-semibold">Inscrit le</th>
                    <th className="py-2 pr-3 font-semibold">Statut</th>
                    {showFinance && (
                      <>
                        <th className="py-2 pr-3 text-right font-semibold">Total</th>
                        <th className="py-2 pr-3 text-right font-semibold">Payé</th>
                        <th className="py-2 pr-3 text-right font-semibold">Solde</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {enrollments.map((e) => (
                    <tr key={e.id} className="border-b border-border last:border-0">
                      <td className="py-2.5 pr-3">
                        {showFinance ? (
                          <Link href={`/inscriptions/${e.id}`} className="font-semibold text-primary hover:underline">
                            {e.trainings?.name ?? "—"}
                          </Link>
                        ) : (
                          <span className="font-semibold">{e.trainings?.name ?? "—"}</span>
                        )}
                        <div className="text-xs text-muted-foreground">{e.enrollment_number}</div>
                      </td>
                      <td className="whitespace-nowrap py-2.5 pr-3 tabular-nums">{formatDate(e.enrolled_on)}</td>
                      <td className="py-2.5 pr-3">
                        <StatusBadge map={ENROLLMENT_STATUS} value={e.status} />
                      </td>
                      {showFinance && (
                        <>
                          <td className="whitespace-nowrap py-2.5 pr-3 text-right tabular-nums">{formatHTG(e.total_due)}</td>
                          <td className="whitespace-nowrap py-2.5 pr-3 text-right tabular-nums">{formatHTG(e.amount_paid)}</td>
                          <td className="whitespace-nowrap py-2.5 pr-3 text-right">
                            {e.status === "ANNULEE" ? (
                              <span className="text-muted-foreground">—</span>
                            ) : Number(e.balance) > 0 ? (
                              <span className="font-semibold tabular-nums text-destructive">{formatHTG(e.balance)}</span>
                            ) : (
                              <StatusBadge map={PAYMENT_STATUS} value="SOLDE" />
                            )}
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {showFinance && (
        <Card>
          <CardHeader>
            <CardTitle>Paiements et reçus</CardTitle>
          </CardHeader>
          <CardContent>
            {payments.length === 0 ? (
              <p className="rounded-lg bg-muted p-4 text-center text-sm text-muted-foreground">Aucun paiement enregistré.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[36rem] text-left text-sm">
                  <thead className="text-xs text-muted-foreground">
                    <tr className="border-b border-border">
                      <th className="py-2 pr-3 font-semibold">Date</th>
                      <th className="py-2 pr-3 font-semibold">N°</th>
                      <th className="py-2 pr-3 font-semibold">Mode</th>
                      <th className="py-2 pr-3 font-semibold">Reçu</th>
                      <th className="py-2 text-right font-semibold">Montant</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((p) => {
                      const rc = receipts[p.id];
                      const voided = p.status === "ANNULE";
                      return (
                        <tr key={p.id} className="border-b border-border last:border-0">
                          <td className="whitespace-nowrap py-2.5 pr-3 tabular-nums">{formatDateTime(p.paid_at)}</td>
                          <td className="whitespace-nowrap py-2.5 pr-3">{p.payment_number}</td>
                          <td className="whitespace-nowrap py-2.5 pr-3">{METHOD_LABELS[p.method] ?? p.method}</td>
                          <td className="whitespace-nowrap py-2.5 pr-3">
                            {rc ? rc.receipt_number : "—"} {voided && <Badge tone="red">Annulé</Badge>}
                          </td>
                          <td className={cn("whitespace-nowrap py-2.5 text-right font-semibold tabular-nums", voided && "text-muted-foreground line-through")}>
                            {formatHTG(p.amount)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Certificats</CardTitle>
        </CardHeader>
        <CardContent>
          {certificates.length === 0 ? (
            <p className="rounded-lg bg-muted p-4 text-center text-sm text-muted-foreground">Aucun certificat délivré.</p>
          ) : (
            <ul className="space-y-2">
              {certificates.map((c) => (
                <li key={c.id} className="flex items-center gap-3 rounded-lg border border-border p-3 text-sm">
                  <Award className="size-5 shrink-0 text-primary" aria-hidden />
                  <div>
                    <div className="font-semibold">{c.trainings?.name ?? "Formation"}</div>
                    <div className="text-xs text-muted-foreground">
                      {c.certificate_number} · délivré le {formatDate(c.issued_on)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Historique</CardTitle>
          <CardDescription>Inscriptions, paiements et certificats, du plus récent au plus ancien</CardDescription>
        </CardHeader>
        <CardContent>
          <Timeline events={events} />
        </CardContent>
      </Card>
    </div>
  );
}

