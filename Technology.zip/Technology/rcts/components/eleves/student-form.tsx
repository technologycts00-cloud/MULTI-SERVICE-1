"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Field, FormBanner } from "@/components/shared/form-field";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/action-result";
import { GENDER_LABELS, STUDENT_STATUS, options } from "@/lib/labels";
import { studentSchema, type StudentFormInput, type StudentValues } from "@/lib/validations/student";

export function StudentForm({
  studentId,
  defaults,
  save,
}: {
  studentId: string | null;
  defaults: StudentFormInput;
  save: (id: string | null, raw: unknown) => Promise<ActionResult<{ id: string }>>;
}) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const {
    register,
    handleSubmit,
    getValues,
    setError,
    formState: { errors },
  } = useForm<StudentFormInput, unknown, StudentValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: defaults,
  });

  const onValid = () => {
    setServerError(null);
    start(async () => {
      // On envoie les valeurs brutes : le serveur revalide tout avec le même schéma.
      const res = await save(studentId, getValues());
      if (!res.ok) {
        setServerError(res.error);
        for (const [name, message] of Object.entries(res.fieldErrors ?? {})) {
          setError(name as keyof StudentFormInput, { message });
        }
        return;
      }
      router.push(`/eleves/${res.id}`);
      router.refresh();
    });
  };

  return (
    <form onSubmit={handleSubmit(onValid)} noValidate className="space-y-4">
      <Card>
        <CardContent className="grid gap-4 p-6 md:grid-cols-2">
          <Field id="first_name" label="Prénom" required error={errors.first_name?.message}>
            <Input id="first_name" autoComplete="given-name" aria-invalid={!!errors.first_name} {...register("first_name")} />
          </Field>
          <Field id="last_name" label="Nom" required error={errors.last_name?.message}>
            <Input id="last_name" autoComplete="family-name" aria-invalid={!!errors.last_name} {...register("last_name")} />
          </Field>
          <Field id="gender" label="Sexe" error={errors.gender?.message}>
            <Select id="gender" {...register("gender")}>
              <option value="">Non précisé</option>
              {Object.entries(GENDER_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="birth_date" label="Date de naissance" error={errors.birth_date?.message}>
            <Input id="birth_date" type="date" {...register("birth_date")} />
          </Field>
          <Field id="phone" label="Téléphone" hint="Ex. 3700-0000" error={errors.phone?.message}>
            <Input id="phone" type="tel" inputMode="tel" autoComplete="tel" {...register("phone")} />
          </Field>
          <Field id="email" label="E-mail" error={errors.email?.message}>
            <Input id="email" type="email" autoComplete="email" {...register("email")} />
          </Field>
          <Field id="address" label="Adresse" className="md:col-span-2" error={errors.address?.message}>
            <Input id="address" autoComplete="street-address" {...register("address")} />
          </Field>
          <Field id="enrolled_on" label="Date d'inscription" required error={errors.enrolled_on?.message}>
            <Input id="enrolled_on" type="date" {...register("enrolled_on")} />
          </Field>
          <Field id="status" label="Statut" required error={errors.status?.message}>
            <Select id="status" {...register("status")}>
              {options(STUDENT_STATUS).map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field id="notes" label="Notes" className="md:col-span-2" error={errors.notes?.message}>
            <Textarea id="notes" {...register("notes")} />
          </Field>
        </CardContent>
      </Card>

      <FormBanner error={serverError} />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" size="lg" disabled={pending}>
          {pending ? "Enregistrement…" : studentId ? "Enregistrer les modifications" : "Créer l'élève"}
        </Button>
        <Button type="button" variant="outline" size="lg" onClick={() => router.back()} disabled={pending}>
          Annuler
        </Button>
      </div>
    </form>
  );
}

