"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Camera, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ActionResult } from "@/lib/action-result";

export function PhotoUploader({
  hasPhoto,
  upload,
  remove,
}: {
  hasPhoto: boolean;
  upload: (fd: FormData) => Promise<ActionResult>;
  remove: () => Promise<ActionResult>;
}) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function run(fn: () => Promise<ActionResult>) {
    setError(null);
    start(async () => {
      const res = await fn();
      if (!res.ok) setError(res.error);
      else router.refresh();
      if (input.current) input.current.value = "";
    });
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <input
        ref={input}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="sr-only"
        aria-label="Choisir une photo"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const fd = new FormData();
          fd.set("photo", f);
          run(() => upload(fd));
        }}
      />
      <div className="flex gap-2">
        <Button type="button" size="sm" variant="outline" disabled={pending} onClick={() => input.current?.click()}>
          <Camera aria-hidden /> {hasPhoto ? "Changer" : "Ajouter une photo"}
        </Button>
        {hasPhoto && (
          <Button type="button" size="sm" variant="ghost" disabled={pending} onClick={() => run(remove)} aria-label="Retirer la photo">
            <Trash2 aria-hidden />
          </Button>
        )}
      </div>
      {error && <p role="alert" className="max-w-56 text-center text-xs text-destructive">{error}</p>}
    </div>
  );
}
