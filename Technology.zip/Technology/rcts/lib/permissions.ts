import type { Role } from "@/types";

export type ModuleKey =
  | "dashboard" | "eleves" | "formations" | "inscriptions" | "paiements"
  | "caisse" | "ventes" | "produits" | "stock" | "clients" | "services"
  | "fournisseurs" | "depenses" | "finances" | "rapports" | "utilisateurs"
  | "parametres";

export const NAV_ITEMS: { key: ModuleKey; label: string; href: string }[] = [
  { key: "dashboard", label: "Dashboard", href: "/dashboard" },
  { key: "eleves", label: "Élèves", href: "/eleves" },
  { key: "formations", label: "Formations", href: "/formations" },
  { key: "inscriptions", label: "Inscriptions", href: "/inscriptions" },
  { key: "paiements", label: "Paiements", href: "/paiements" },
  { key: "caisse", label: "Caisse", href: "/caisse" },
  { key: "ventes", label: "Ventes", href: "/ventes" },
  { key: "produits", label: "Produits", href: "/produits" },
  { key: "stock", label: "Stock", href: "/stock" },
  { key: "clients", label: "Clients", href: "/clients" },
  { key: "services", label: "Services", href: "/services" },
  { key: "fournisseurs", label: "Fournisseurs", href: "/fournisseurs" },
  { key: "depenses", label: "Dépenses", href: "/depenses" },
  { key: "finances", label: "Finances", href: "/finances" },
  { key: "rapports", label: "Rapports", href: "/rapports" },
  { key: "utilisateurs", label: "Utilisateurs", href: "/utilisateurs" },
  { key: "parametres", label: "Paramètres", href: "/parametres" },
];

const ALL = NAV_ITEMS.map((i) => i.key);

/**
 * Modules accessibles par défaut pour chaque rôle. C'est un PLAFOND aligné sur la RLS :
 * la matrice éditable par l'ADMIN (table users_roles) ne peut que restreindre ces accès, jamais les élargir.
 */
export const ROLE_MODULES: Record<Role, ModuleKey[]> = {
  ADMIN: ALL,
  CAISSIER: ["dashboard", "caisse", "ventes", "paiements", "clients", "services", "rapports"],
  SECRETAIRE: ["dashboard", "eleves", "formations", "inscriptions", "rapports"],
  GESTIONNAIRE: ["dashboard", "produits", "stock", "fournisseurs", "rapports"],
  FORMATEUR: ["dashboard", "formations", "eleves", "rapports"],
};

export function canAccess(role: Role, module: ModuleKey): boolean {
  return ROLE_MODULES[role]?.includes(module) ?? false;
}

export function navForRole(role: Role, hidden: ModuleKey[] = []) {
  return NAV_ITEMS.filter((i) => canAccess(role, i.key) && !hidden.includes(i.key));
}
