import type { SupabaseClient } from "@supabase/supabase-js";
import {
  CASH_CATEGORY, ENROLLMENT_STATUS, METHOD_LABELS, MOVEMENT_TYPES, PAYMENT_STATUS, PRODUCT_STATUS,
  RECORD_STATUS, SERVICE_ORDER_STATUS, STOCK_STATE, STUDENT_STATUS, TRAINING_STATUS,
} from "@/lib/labels";
import { formatDate } from "@/lib/labels";
import type { Role } from "@/types";
import { formatDateTime, formatHTG, formatInt } from "@/lib/utils";

export const REPORT_TYPES = [
  { key: "caisse", label: "Caisse", roles: ["ADMIN", "CAISSIER"] },
  { key: "ventes", label: "Ventes", roles: ["ADMIN", "CAISSIER"] },
  { key: "paiements", label: "Paiements", roles: ["ADMIN", "CAISSIER"] },
  { key: "formations", label: "Formations", roles: ["ADMIN", "SECRETAIRE", "FORMATEUR"] },
  { key: "inscriptions", label: "Inscriptions", roles: ["ADMIN", "SECRETAIRE", "FORMATEUR"] },
  { key: "eleves", label: "Élèves", roles: ["ADMIN", "SECRETAIRE", "FORMATEUR"] },
  { key: "stock", label: "Stock", roles: ["ADMIN", "GESTIONNAIRE"] },
  { key: "depenses", label: "Dépenses", roles: ["ADMIN"] },
  { key: "financier", label: "Rapport financier", roles: ["ADMIN"] },
] as const;
export type ReportKey = (typeof REPORT_TYPES)[number]["key"];

export function reportsForRole(role: Role) {
  return REPORT_TYPES.filter((r) => (r.roles as readonly string[]).includes(role));
}
export const isReportKey = (v: string | undefined | null): v is ReportKey => !!v && REPORT_TYPES.some((r) => r.key === v);

export type ColType = "text" | "int" | "money" | "date" | "datetime" | "status";
export interface ReportColumn { key: string; label: string; type: ColType }
export interface ReportSummary { label: string; value: number | string; type: ColType }
export interface ReportData {
  type: string;
  title: string;
  period: { from: string | null; to: string | null };
  columns: ReportColumn[];
  rows: Record<string, unknown>[];
  summary: ReportSummary[];
  truncated: boolean;
}

export async function fetchReport(db: SupabaseClient, type: ReportKey, from?: string, to?: string): Promise<ReportData> {
  const { data, error } = await db.rpc("report_data", { p_type: type, p_from: from ?? null, p_to: to ?? null });
  if (error) throw new Error(error.message);
  return data as ReportData;
}

const ENUM_LABELS: Record<string, string> = {};
for (const m of [STUDENT_STATUS, TRAINING_STATUS, ENROLLMENT_STATUS, PAYMENT_STATUS, RECORD_STATUS, SERVICE_ORDER_STATUS, PRODUCT_STATUS, STOCK_STATE, MOVEMENT_TYPES]) {
  for (const [k, v] of Object.entries(m)) ENUM_LABELS[k] ??= v.label;
}
for (const [k, v] of Object.entries(CASH_CATEGORY)) ENUM_LABELS[k] ??= v;
for (const [k, v] of Object.entries(METHOD_LABELS)) ENUM_LABELS[k] = v;

function humanize(v: string): string {
  if (ENUM_LABELS[v]) return ENUM_LABELS[v];
  return /^[A-Z_]+$/.test(v) ? v.charAt(0) + v.slice(1).toLowerCase().replace(/_/g, " ") : v;
}

/** Valeur lisible (texte) d'une cellule — la même pour l'écran, le PDF, l'Excel et le CSV. */
export function formatCell(value: unknown, type: ColType): string {
  if (value === null || value === undefined || value === "") return "—";
  switch (type) {
    case "money": return formatHTG(value as number);
    case "int": return formatInt(value as number);
    case "date": return formatDate(String(value));
    case "datetime": return formatDateTime(String(value));
    case "status": return humanize(String(value));
    default: return typeof value === "string" ? (ENUM_LABELS[value] ?? value) : String(value);
  }
}

export function periodLabel(p: ReportData["period"]): string {
  const f = (s: string) => s.split("-").reverse().join("/");
  if (!p.from && !p.to) return "Toutes les périodes";
  if (p.from && p.to) return p.from === p.to ? f(p.from) : `${f(p.from)} au ${f(p.to)}`;
  return p.from ? `Depuis le ${f(p.from)}` : `Jusqu'au ${f(p.to!)}`;
}

export function buildCsv(r: ReportData): string {
  const esc = (s: string) => (/[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  // Cellules texte commençant par = + - @ : neutralisées contre l'injection de formules à l'ouverture dans Excel
  const safe = (s: string) => (/^[=+@]/.test(s) ? "'" + s : s);
  const lines = [
    [r.title], [`Période : ${periodLabel(r.period)}`], [],
    ...r.summary.map((s) => [s.label, formatCell(s.value, s.type)]),
    [],
    r.columns.map((c) => c.label),
    ...r.rows.map((row) => r.columns.map((c) => {
      const v = row[c.key];
      if (c.type === "money" || c.type === "int") return v === null || v === undefined ? "" : String(v).replace(".", ",");
      return safe(formatCell(v, c.type));
    })),
  ];
  return "﻿" + lines.map((l) => l.map((x) => esc(String(x))).join(";")).join("\r\n") + "\r\n";
}
