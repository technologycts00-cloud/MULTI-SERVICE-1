export type Tone = "blue" | "green" | "yellow" | "red" | "slate";
export type LabelMap = Record<string, { label: string; tone: Tone }>;

export const STUDENT_STATUS: LabelMap = {
  ACTIF: { label: "Actif", tone: "green" },
  TERMINE: { label: "Terminé", tone: "blue" },
  SUSPENDU: { label: "Suspendu", tone: "red" },
  INACTIF: { label: "Inactif", tone: "slate" },
};

export const TRAINING_STATUS: LabelMap = {
  PLANIFIEE: { label: "Planifiée", tone: "yellow" },
  EN_COURS: { label: "En cours", tone: "green" },
  TERMINEE: { label: "Terminée", tone: "blue" },
  ANNULEE: { label: "Annulée", tone: "red" },
};

export const ENROLLMENT_STATUS: LabelMap = {
  ACTIVE: { label: "Active", tone: "green" },
  TERMINEE: { label: "Terminée", tone: "blue" },
  ABANDONNEE: { label: "Abandonnée", tone: "yellow" },
  ANNULEE: { label: "Annulée", tone: "red" },
};

export const PAYMENT_STATUS: LabelMap = {
  SOLDE: { label: "Soldé", tone: "green" },
  PARTIEL: { label: "Partiel", tone: "yellow" },
  IMPAYE: { label: "Impayé", tone: "red" },
  PAYEE: { label: "Payée", tone: "green" },
  PARTIELLE: { label: "Partielle", tone: "yellow" },
  IMPAYEE: { label: "Impayée", tone: "red" },
};

export const RECORD_STATUS: LabelMap = {
  VALIDE: { label: "Validé", tone: "green" },
  ANNULE: { label: "Annulé", tone: "red" },
};

export const SERVICE_ORDER_STATUS: LabelMap = {
  EN_ATTENTE: { label: "En attente", tone: "yellow" },
  EN_COURS: { label: "En cours", tone: "blue" },
  TERMINE: { label: "Terminé", tone: "green" },
  LIVRE: { label: "Livré", tone: "slate" },
  ANNULE: { label: "Annulé", tone: "red" },
};

export const CUSTOMER_TYPE: LabelMap = {
  PARTICULIER: { label: "Particulier", tone: "slate" },
  ENTREPRISE: { label: "Entreprise", tone: "blue" },
  INSTITUTION: { label: "Institution", tone: "yellow" },
};

export const PRODUCT_STATUS: LabelMap = {
  ACTIF: { label: "Actif", tone: "green" },
  INACTIF: { label: "Inactif", tone: "slate" },
};

export const STOCK_STATE: LabelMap = {
  OK: { label: "En stock", tone: "green" },
  FAIBLE: { label: "Stock faible", tone: "yellow" },
  RUPTURE: { label: "Rupture", tone: "red" },
};

export const MOVEMENT_TYPES: LabelMap = {
  ENTREE: { label: "Entrée", tone: "green" },
  SORTIE: { label: "Sortie", tone: "red" },
  AJUSTEMENT: { label: "Ajustement", tone: "yellow" },
  INVENTAIRE: { label: "Inventaire", tone: "blue" },
  VENTE: { label: "Vente", tone: "slate" },
  ACHAT: { label: "Achat", tone: "green" },
  ANNULATION: { label: "Annulation", tone: "yellow" },
};

export const CASH_CATEGORY: Record<string, string> = {
  FORMATION: "Formations",
  VENTE: "Ventes",
  SERVICE: "Services",
  DEPENSE: "Dépenses",
  ACHAT_FOURNISSEUR: "Achats fournisseurs",
  AUTRE: "Autres",
};

export const PAYMENT_KIND: Record<string, string> = {
  INSCRIPTION: "Formation",
  VENTE: "Vente",
  SERVICE: "Service",
};

export const GENDER_LABELS: Record<string, string> = { M: "Masculin", F: "Féminin" };

export const METHOD_LABELS: Record<string, string> = {
  ESPECES: "Espèces",
  MONCASH: "MonCash",
  NATCASH: "NatCash",
  VIREMENT: "Virement",
  AUTRE: "Autre",
};

export const DURATION_UNITS: Record<string, string> = {
  HEURES: "heures",
  JOURS: "jours",
  SEMAINES: "semaines",
  MOIS: "mois",
};

export const ROLE_LABELS: Record<string, string> = {
  ADMIN: "Direction (Admin)",
  CAISSIER: "Caissier",
  SECRETAIRE: "Secrétaire",
  GESTIONNAIRE: "Gestionnaire",
  FORMATEUR: "Formateur",
};

/** Convertit une table d'étiquettes en options de liste déroulante. */
export function options(map: LabelMap | Record<string, string>): { value: string; label: string }[] {
  return Object.entries(map).map(([value, v]) => ({ value, label: typeof v === "string" ? v : v.label }));
}

/** « 2026-03-05 » ou horodatage ISO → « 05/03/2026 » (fuseau d'Haïti pour les horodatages). */
export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (dateOnly) return `${dateOnly[3]}/${dateOnly[2]}/${dateOnly[1]}`;
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: "America/Port-au-Prince",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date(value));
}
