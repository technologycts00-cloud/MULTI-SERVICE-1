import { todayHaiti } from "@/lib/utils";

export const PERIOD_PRESETS = {
  today: "Aujourd'hui",
  week: "Cette semaine",
  month: "Ce mois",
  year: "Cette année",
  custom: "Période personnalisée",
} as const;
export type PeriodPreset = keyof typeof PERIOD_PRESETS;

export interface Period {
  preset: PeriodPreset;
  from: string; // AAAA-MM-JJ (heure d'Haïti)
  to: string;
  label: string;
}

const isDate = (v: string | undefined): v is string => !!v && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v + "T00:00:00Z"));
const ymd = (d: Date) => d.toISOString().slice(0, 10);
const fr = (s: string) => s.split("-").reverse().join("/");

/** Calcule la période à partir des paramètres d'URL (`periode`, `from`, `to`). Défaut : ce mois. */
export function resolvePeriod(get: (k: string) => string | undefined): Period {
  const today = todayHaiti();
  const t = new Date(today + "T00:00:00Z");
  const raw = get("periode");
  const preset: PeriodPreset = raw && raw in PERIOD_PRESETS ? (raw as PeriodPreset) : isDate(get("from")) || isDate(get("to")) ? "custom" : "month";
  let from = today;
  let to = today;
  if (preset === "week") {
    const dow = (t.getUTCDay() + 6) % 7; // lundi = 0
    from = ymd(new Date(t.getTime() - dow * 86400000));
    to = ymd(new Date(t.getTime() + (6 - dow) * 86400000));
  } else if (preset === "month") {
    from = `${today.slice(0, 7)}-01`;
    to = ymd(new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)));
  } else if (preset === "year") {
    from = `${t.getUTCFullYear()}-01-01`;
    to = `${t.getUTCFullYear()}-12-31`;
  } else if (preset === "custom") {
    const f = get("from");
    const e = get("to");
    from = isDate(f) ? f : isDate(e) ? e : today;
    to = isDate(e) ? e : isDate(f) ? f : today;
    if (to < from) [from, to] = [to, from];
  }
  const label = from === to ? fr(from) : `${fr(from)} → ${fr(to)}`;
  return { preset, from, to, label };
}
