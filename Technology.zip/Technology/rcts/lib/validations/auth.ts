import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().trim().email("Adresse e-mail invalide"),
  password: z.string().min(6, "Minimum 6 caractères"),
});

export const forgotSchema = z.object({
  email: z.string().trim().email("Adresse e-mail invalide"),
});

export const resetSchema = z
  .object({
    password: z.string().min(8, "Minimum 8 caractères"),
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, {
    path: ["confirm"],
    message: "Les mots de passe ne correspondent pas",
  });
