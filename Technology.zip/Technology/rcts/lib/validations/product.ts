import { z } from "zod";
import { money, optionalText, optionalUuid, requiredText } from "./common";

const count = (label: string) =>
  z
    .string()
    .trim()
    .transform((v, ctx) => {
      if (v === "") return 0;
      if (!/^\d+$/.test(v) || Number(v) > 10_000_000) {
        ctx.addIssue({ code: "custom", message: `${label} invalide (entier positif)` });
        return z.NEVER;
      }
      return Number(v);
    });

export const productSchema = z
  .object({
    name: requiredText("Nom du produit", 120),
    category_id: optionalUuid,
    description: optionalText(500),
    purchase_price: money("Prix d'achat"),
    sale_price: money("Prix de vente"),
    min_stock: count("Stock minimum"),
    supplier_id: optionalUuid,
    status: z.enum(["ACTIF", "INACTIF"]),
    /** Stock de départ (création seulement) : enregistré comme un mouvement d'entrée. */
    initial_stock: count("Stock initial"),
  });

export type ProductFormInput = z.input<typeof productSchema>;
export type ProductValues = z.output<typeof productSchema>;

export const movementSchema = z.object({
  product_id: z.uuid({ error: "Choisissez un produit" }),
  type: z.enum(["ENTREE", "SORTIE", "AJUSTEMENT", "INVENTAIRE"]),
  quantity: z
    .string({ error: "Quantité requise" })
    .trim()
    .transform((v, ctx) => {
      if (!/^-?\d+$/.test(v) || Number(v) > 10_000_000 || Number(v) < -10_000_000) {
        ctx.addIssue({ code: "custom", message: "Quantité invalide (nombre entier)" });
        return z.NEVER;
      }
      return Number(v);
    }),
  reason: optionalText(200),
  reference: optionalText(80),
});
