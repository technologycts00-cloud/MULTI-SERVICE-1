import { z } from "zod";
import { optionalDate, optionalText, requiredDate, requiredText } from "./common";

export const STUDENT_STATUSES = ["ACTIF", "TERMINE", "SUSPENDU", "INACTIF"] as const;

export const studentSchema = z.object({
  first_name: requiredText("Prénom", 80),
  last_name: requiredText("Nom", 80),
  gender: z.enum(["", "M", "F"]).transform((v) => (v === "" ? null : v)),
  birth_date: optionalDate("Date de naissance").refine((v) => v === null || v < new Date().toISOString().slice(0, 10), {
    message: "La date de naissance doit être dans le passé",
  }),
  phone: optionalText(30).refine((v) => v === null || /^[0-9+()\-.\s]{6,30}$/.test(v), { message: "Numéro de téléphone invalide" }),
  email: optionalText(120).refine((v) => v === null || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), { message: "Adresse e-mail invalide" }),
  address: optionalText(200),
  enrolled_on: requiredDate("Date d'inscription"),
  status: z.enum(STUDENT_STATUSES),
  notes: optionalText(1000),
});

export type StudentFormInput = z.input<typeof studentSchema>;
export type StudentValues = z.output<typeof studentSchema>;
