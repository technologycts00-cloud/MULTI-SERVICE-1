import { z } from "zod";

/** Montant saisi en texte (« 1 500,50 ») → nombre ≥ 0, 2 décimales maximum. */
export function money(label: string, opts: { allowZero?: boolean } = { allowZero: true }) {
  return z
    .string({ error: `${label} requis` })
    .trim()
    .transform((v, ctx) => {
      const t = v.replace(/\s/g, "").replace(",", ".");
      if (!/^\d+(\.\d{1,2})?$/.test(t)) {
        ctx.addIssue({ code: "custom", message: `${label} invalide (nombre positif, 2 décimales maximum)` });
        return z.NEVER;
      }
      const n = Number(t);
      if (n > 999_999_999.99) {
        ctx.addIssue({ code: "custom", message: `${label} trop élevé` });
        return z.NEVER;
      }
      if (n === 0 && opts.allowZero === false) {
        ctx.addIssue({ code: "custom", message: `${label} doit être supérieur à zéro` });
        return z.NEVER;
      }
      return n;
    });
}

/** Entier positif saisi en texte. */
export function positiveInt(label: string, opts: { max?: number } = {}) {
  return z
    .string({ error: `${label} requise` })
    .trim()
    .transform((v, ctx) => {
      if (!/^\d+$/.test(v) || Number(v) < 1) {
        ctx.addIssue({ code: "custom", message: `${label} invalide (entier supérieur à zéro)` });
        return z.NEVER;
      }
      const n = Number(v);
      if (n > (opts.max ?? 1_000_000)) {
        ctx.addIssue({ code: "custom", message: `${label} trop élevée` });
        return z.NEVER;
      }
      return n;
    });
}

/** Texte obligatoire. */
export function requiredText(label: string, max = 200) {
  return z
    .string({ error: `${label} requis` })
    .trim()
    .min(1, `${label} requis`)
    .max(max, `${label} trop long (${max} caractères maximum)`);
}

/** Texte facultatif : vide → null. */
export function optionalText(max = 500) {
  return z
    .string()
    .trim()
    .max(max, `Texte trop long (${max} caractères maximum)`)
    .transform((v) => (v === "" ? null : v));
}

/** Date AAAA-MM-JJ facultative : vide → null. */
export function optionalDate(label = "Date") {
  return z
    .string()
    .trim()
    .transform((v, ctx) => {
      if (v === "") return null;
      const d = new Date(v + "T00:00:00Z");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== v) {
        ctx.addIssue({ code: "custom", message: `${label} invalide` });
        return z.NEVER;
      }
      return v;
    });
}

/** Date AAAA-MM-JJ obligatoire. */
export function requiredDate(label = "Date") {
  return optionalDate(label).refine((v): v is string => v !== null, { message: `${label} requise` });
}

/** UUID facultatif : vide → null. */
export const optionalUuid = z
  .string()
  .trim()
  .transform((v, ctx) => {
    if (v === "") return null;
    if (!z.uuid().safeParse(v).success) {
      ctx.addIssue({ code: "custom", message: "Sélection invalide" });
      return z.NEVER;
    }
    return v;
  });

export const PAYMENT_METHODS = ["ESPECES", "MONCASH", "NATCASH", "VIREMENT", "AUTRE"] as const;
