import { z } from "zod";
import { PAYMENT_METHODS, money, optionalText } from "./common";

export const ENROLLMENT_STATUSES = ["ACTIVE", "TERMINEE", "ABANDONNEE", "ANNULEE"] as const;

export const enrollmentSchema = z.object({
  student_id: z.uuid({ error: "Choisissez un élève" }),
  training_id: z.uuid({ error: "Choisissez une formation" }),
  discount: money("Réduction"),
  amount_paid: money("Montant payé"),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
  notes: optionalText(500),
});

export type EnrollmentFormInput = z.input<typeof enrollmentSchema>;
export type EnrollmentValues = z.output<typeof enrollmentSchema>;
