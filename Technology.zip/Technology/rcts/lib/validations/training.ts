import { z } from "zod";
import { money, optionalDate, optionalText, optionalUuid, positiveInt, requiredText } from "./common";

export const TRAINING_STATUSES = ["PLANIFIEE", "EN_COURS", "TERMINEE", "ANNULEE"] as const;
export const DURATION_UNIT_VALUES = ["HEURES", "JOURS", "SEMAINES", "MOIS"] as const;

const duration = z
  .string({ error: "Durée requise" })
  .trim()
  .transform((v, ctx) => {
    const t = v.replace(",", ".");
    const n = Number(t);
    if (!/^\d+(\.\d)?$/.test(t) || n <= 0 || n > 9999) {
      ctx.addIssue({ code: "custom", message: "Durée invalide (nombre supérieur à zéro)" });
      return z.NEVER;
    }
    return n;
  });

export const trainingSchema = z
  .object({
    name: requiredText("Nom de la formation", 120),
    description: optionalText(1000),
    duration_value: duration,
    duration_unit: z.enum(DURATION_UNIT_VALUES),
    price: money("Prix"),
    registration_fee: money("Frais d'inscription"),
    max_students: z
      .string()
      .trim()
      .transform((v, ctx) => {
        if (v === "") return null;
        const r = positiveInt("Capacité", { max: 10000 }).safeParse(v);
        if (!r.success) {
          ctx.addIssue({ code: "custom", message: r.error.issues[0]?.message ?? "Capacité invalide" });
          return z.NEVER;
        }
        return r.data;
      }),
    start_date: optionalDate("Date de début"),
    end_date: optionalDate("Date de fin"),
    schedule: optionalText(200),
    trainer_id: optionalUuid,
    status: z.enum(TRAINING_STATUSES),
  })
  .superRefine((v, ctx) => {
    if (v.start_date && v.end_date && v.end_date < v.start_date) {
      ctx.addIssue({ code: "custom", path: ["end_date"], message: "La fin doit être après le début" });
    }
  });

export type TrainingFormInput = z.input<typeof trainingSchema>;
export type TrainingValues = z.output<typeof trainingSchema>;
