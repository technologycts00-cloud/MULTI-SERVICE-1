import { z } from "zod";
import { requiredText } from "./common";
import { ROLES } from "@/types";

const email = z
  .string({ error: "E-mail requis" })
  .trim()
  .toLowerCase()
  .max(120, "E-mail trop long")
  .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Adresse e-mail invalide");

const role = z.enum(ROLES, { error: "Rôle invalide" });

export const createUserSchema = z.object({
  full_name: requiredText("Nom complet", 120),
  email,
  password: z
    .string({ error: "Mot de passe requis" })
    .min(8, "8 caractères minimum")
    .max(72, "72 caractères maximum")
    .regex(/[A-Za-z]/, "Au moins une lettre")
    .regex(/\d/, "Au moins un chiffre"),
  role,
});
export type CreateUserInput = z.input<typeof createUserSchema>;

export const updateUserSchema = z.object({
  full_name: requiredText("Nom complet", 120),
  role,
  is_active: z.enum(["true", "false"]).transform((v) => v === "true"),
});
export type UpdateUserInput = z.input<typeof updateUserSchema>;

const optionalEmail = z
  .string()
  .trim()
  .max(120)
  .refine((v) => v === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), "Adresse e-mail invalide");
const optionalUrl = z
  .string()
  .trim()
  .max(500)
  .refine((v) => v === "" || /^https:\/\/[^\s]+$/.test(v), "Lien https:// invalide");
const prefix = (label: string) =>
  z
    .string({ error: `${label} requis` })
    .trim()
    .toUpperCase()
    .regex(/^[A-Z0-9]{2,8}$/, `${label} : 2 à 8 caractères (lettres et chiffres)`);

export const settingsSchema = z.object({
  org_name: requiredText("Nom commercial", 80),
  org_legal_name: requiredText("Raison sociale", 120),
  phone: z.string().trim().max(40),
  email: optionalEmail,
  address: z.string().trim().max(200),
  logo_url: optionalUrl,
  receipt_prefix: prefix("Préfixe des reçus"),
  invoice_prefix: prefix("Préfixe des factures"),
  invoice_footer: z.string().trim().max(300),
});
export type SettingsInput = z.input<typeof settingsSchema>;
export const SETTING_KEYS = Object.keys(settingsSchema.shape) as (keyof SettingsInput)[];
