import { z } from "zod";
import { PAYMENT_METHODS, money, optionalDate, optionalText, optionalUuid, positiveInt, requiredText } from "./common";

const phone = optionalText(30);
const email = z
  .string()
  .trim()
  .max(120)
  .transform((v, ctx) => {
    if (v === "") return null;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
      ctx.addIssue({ code: "custom", message: "Adresse e-mail invalide" });
      return z.NEVER;
    }
    return v;
  });

export const customerSchema = z.object({
  name: requiredText("Nom du client", 120),
  phone,
  email,
  address: optionalText(200),
  customer_type: z.enum(["PARTICULIER", "ENTREPRISE", "INSTITUTION"]),
  notes: optionalText(500),
});
export type CustomerFormInput = z.input<typeof customerSchema>;
export type CustomerValues = z.output<typeof customerSchema>;

export const supplierSchema = z.object({
  name: requiredText("Nom du fournisseur", 120),
  company: optionalText(120),
  phone,
  email,
  address: optionalText(200),
  products_supplied: optionalText(300),
  notes: optionalText(500),
});
export type SupplierFormInput = z.input<typeof supplierSchema>;
export type SupplierValues = z.output<typeof supplierSchema>;

export const serviceSchema = z.object({
  name: requiredText("Nom du service", 120),
  category: optionalText(60),
  description: optionalText(500),
  unit_price: money("Prix unitaire"),
  unit: requiredText("Unité", 30),
  is_active: z.enum(["true", "false"]).transform((v) => v === "true"),
});
export type ServiceFormInput = z.input<typeof serviceSchema>;
export type ServiceValues = z.output<typeof serviceSchema>;

export const serviceOrderSchema = z.object({
  customer_id: z.uuid({ error: "Choisissez un client" }),
  service_id: z.uuid({ error: "Choisissez un service" }),
  quantity: positiveInt("Quantité", { max: 100_000 }),
  unit_price: z
    .string()
    .trim()
    .transform((v, ctx) => {
      if (v === "") return null;
      const r = money("Prix unitaire").safeParse(v);
      if (!r.success) {
        ctx.addIssue({ code: "custom", message: r.error.issues[0]?.message ?? "Prix invalide" });
        return z.NEVER;
      }
      return r.data;
    }),
  due_date: optionalDate("Date d'échéance"),
  responsible_id: optionalUuid,
  comment: optionalText(300),
  amount_paid: money("Acompte"),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
});
export type ServiceOrderFormInput = z.input<typeof serviceOrderSchema>;
export type ServiceOrderValues = z.output<typeof serviceOrderSchema>;

export const purchaseSchema = z.object({
  supplier_id: z.uuid({ error: "Choisissez un fournisseur" }),
  items: z
    .array(
      z.object({
        product_id: z.uuid({ error: "Choisissez un produit" }),
        quantity: positiveInt("Quantité", { max: 1_000_000 }),
        unit_cost: money("Coût unitaire"),
      }),
    )
    .min(1, "Ajoutez au moins une ligne"),
  amount_paid: money("Montant payé"),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
  notes: optionalText(300),
});
export type PurchaseFormInput = z.input<typeof purchaseSchema>;
export type PurchaseValues = z.output<typeof purchaseSchema>;

export const supplierPaymentSchema = z.object({
  purchase_id: z.uuid(),
  amount: money("Montant", { allowZero: false }),
  method: z.enum(PAYMENT_METHODS),
  reference: optionalText(80),
});
