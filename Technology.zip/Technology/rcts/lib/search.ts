export const PAGE_SIZE = 20;

/**
 * Nettoie un texte de recherche avant de l'insérer dans un filtre PostgREST `.or(...)` :
 * retire les caractères qui ont un sens dans la syntaxe (virgule, parenthèses, jokers, échappement).
 */
export function sanitizeSearch(raw: string | undefined): string {
  return (raw ?? "")
    .replace(/[,()%*\\"'`;:]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60);
}

/** Construit « col1.ilike.%q%,col2.ilike.%q% » pour `.or()`. Renvoie null si la recherche est vide. */
export function ilikeOr(columns: string[], raw: string | undefined): string | null {
  const q = sanitizeSearch(raw);
  if (!q) return null;
  return columns.map((c) => `${c}.ilike.%${q}%`).join(",");
}

/** « marie jean » → ["marie", "jean"] : chaque mot doit être trouvé (dans n'importe quelle colonne). */
export function searchTerms(raw: string | undefined): string[] {
  return sanitizeSearch(raw)
    .split(" ")
    .filter(Boolean)
    .slice(0, 4);
}

export function parsePage(raw: string | undefined): number {
  const n = Number(raw);
  return Number.isInteger(n) && n >= 1 && n <= 10_000 ? n : 1;
}

export function pageRange(page: number): { from: number; to: number } {
  const from = (page - 1) * PAGE_SIZE;
  return { from, to: from + PAGE_SIZE - 1 };
}

/** Valeur de paramètre d'URL toujours en texte (Next peut renvoyer un tableau). */
export function firstParam(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}
