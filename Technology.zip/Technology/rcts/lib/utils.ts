import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const TZ = "America/Port-au-Prince";
const MONTHS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];

/** Formate un montant en gourdes haïtiennes (HTG). */
export function formatHTG(amount: number | string | null | undefined): string {
  const n = Number(amount ?? 0);
  return (
    new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) + " HTG"
  );
}

export function formatInt(n: number | string | null | undefined): string {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(Number(n ?? 0));
}

/** 12 500 → "12,5 k" ; 2 300 000 → "2,3 M" (axes des graphiques). */
export function formatCompact(n: number): string {
  const abs = Math.abs(n);
  const f = (v: number) => new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(v);
  if (abs >= 1_000_000) return f(n / 1_000_000) + " M";
  if (abs >= 1_000) return f(n / 1_000) + " k";
  return f(n);
}

/** "2026-03" → "mars 26" */
export function monthLabel(ym: string): string {
  const [y, m] = ym.split("-");
  return `${MONTHS[Number(m) - 1] ?? m} ${y.slice(2)}`;
}

/** Date et heure en fuseau d'Haïti, ex. « 04/10/2026 10:41 ». */
export function formatDateTime(iso: string): string {
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: TZ,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}

/** Date du jour en Haïti au format AAAA-MM-JJ (valeur par défaut des champs date). */
export function todayHaiti(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(new Date());
}

/** Début (ISO UTC) de la journée « YYYY-MM-DD » en fuseau d'Haïti, heure d'été comprise. */
export function haitiDayStartISO(ymd: string): string {
  const [y, m, d] = ymd.split("-").map(Number);
  const guess = Date.UTC(y, m - 1, d, 5, 0, 0);
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Port-au-Prince", hour: "numeric", hourCycle: "h23", year: "numeric", month: "numeric", day: "numeric",
  }).formatToParts(new Date(guess));
  const hour = Number(parts.find((p) => p.type === "hour")?.value ?? 0);
  // À 05:00 UTC il est 00:00 (UTC-5) ou 01:00 (UTC-4) en Haïti.
  return new Date(guess - hour * 3600_000).toISOString();
}

/** Jour suivant « YYYY-MM-DD ». */
export function nextDay(ymd: string): string {
  return new Date(new Date(ymd + "T00:00:00Z").getTime() + 86400000).toISOString().slice(0, 10);
}
