import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { canAccess, type ModuleKey } from "@/lib/permissions";
import type { Profile, Role } from "@/types";

/** Profil de l'utilisateur connecté (une seule lecture par requête), ou redirection vers /login. */
export const requireProfile = cache(async (): Promise<Profile> => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, full_name, email, role, is_active")
    .eq("id", user.id)
    .single<Profile>();

  if (!profile || !profile.is_active) {
    await supabase.auth.signOut();
    redirect("/login?error=compte-inactif");
  }
  return profile;
});

/** Modules masqués par l'ADMIN pour ce rôle (matrice users_roles). Ne peut que restreindre. */
export const hiddenModules = cache(async (role: Role): Promise<ModuleKey[]> => {
  if (role === "ADMIN") return [];
  const supabase = await createClient();
  const { data } = await supabase.from("users_roles").select("module, can_view").eq("role", role);
  return (data ?? []).filter((r) => !r.can_view).map((r) => r.module as ModuleKey);
});

/** Page réservée à un module : redirige vers le Dashboard si le rôle n'y a pas accès. */
export async function requireModule(module: ModuleKey): Promise<Profile> {
  const profile = await requireProfile();
  if (!canAccess(profile.role, module)) redirect("/dashboard");
  if ((await hiddenModules(profile.role)).includes(module)) redirect("/dashboard");
  return profile;
}

/** Page réservée à certains rôles (ex. création) : redirige vers le Dashboard sinon. */
export async function requireRole(...roles: Role[]): Promise<Profile> {
  const profile = await requireProfile();
  if (!roles.includes(profile.role)) redirect("/dashboard");
  return profile;
}

export type Authorized =
  | { ok: true; supabase: SupabaseClient; profile: Profile }
  | { ok: false; error: string };

/** Pour les Server Actions : vérifie la session ET le rôle, sans jamais lever d'exception. */
export async function authorize(...roles: Role[]): Promise<Authorized> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Session expirée : reconnectez-vous." };

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, full_name, email, role, is_active")
    .eq("id", user.id)
    .single<Profile>();
  if (!profile || !profile.is_active) return { ok: false, error: "Compte désactivé." };
  if (roles.length > 0 && !roles.includes(profile.role)) {
    return { ok: false, error: "Accès refusé : cette action n'est pas autorisée pour votre rôle." };
  }
  return { ok: true, supabase, profile };
}
