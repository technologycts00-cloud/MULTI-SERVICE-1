import type { ZodError } from "zod";

/** Résultat standard d'une Server Action : jamais d'exception vers l'interface. */
export type ActionResult<T = object> =
  | ({ ok: true } & T)
  | { ok: false; error: string; fieldErrors?: Record<string, string> };

export function zodFieldErrors(err: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = issue.path.join(".") || "_";
    if (!(key in out)) out[key] = issue.message;
  }
  return out;
}

/** Traduit une erreur PostgreSQL / PostgREST en message compréhensible. */
export function dbErrorMessage(error: { code?: string; message: string }): string {
  const code = error.code ?? "";
  const msg = error.message ?? "";
  // Messages métier levés par nos fonctions et triggers (en français)
  if (code === "P0001" || msg.startsWith("Accès refusé")) return msg;
  if (code === "42501") return "Accès refusé : cette action n'est pas autorisée pour votre rôle.";
  if (code === "23505") return "Cet enregistrement existe déjà (doublon).";
  if (code === "23503") return "Cet enregistrement est lié à d'autres données et ne peut pas être modifié ainsi.";
  if (code === "23514") return "Une valeur est hors des limites autorisées.";
  if (code === "23502") return "Un champ obligatoire est manquant.";
  if (code === "22P02" || code === "22003" || code === "22007") return "Une valeur saisie est invalide.";
  return "Opération impossible pour le moment. Réessayez dans un instant.";
}
