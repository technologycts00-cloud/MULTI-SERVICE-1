import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { METHOD_LABELS, formatDate } from "@/lib/labels";
import { formatDateTime } from "@/lib/utils";
import type { InvoiceData, OrgInfo, ReceiptData } from "@/services/documents";

/** jsPDF (polices standard WinAnsi) ne sait pas afficher les espaces insécables d'Intl : on les remplace. */
export function pdfText(s: string | number | null | undefined): string {
  return String(s ?? "").replace(/[   ]/g, " ").replace(/[−–]/g, "-").replace(/[’]/g, "'");
}
export function pdfMoney(n: number | string | null | undefined): string {
  const v = new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n ?? 0));
  return pdfText(v) + " HTG";
}

const BLUE: [number, number, number] = [29, 78, 216];
const RED: [number, number, number] = [185, 28, 28];

function header(doc: jsPDF, org: OrgInfo, x: number, y: number, align: "left" | "center" = "left") {
  doc.setTextColor(...BLUE).setFont("helvetica", "bold").setFontSize(14);
  doc.text(pdfText((org.org_name || "R.CTS").toUpperCase()), x, y, { align });
  doc.setTextColor(60).setFont("helvetica", "normal").setFontSize(8);
  let yy = y + 4;
  for (const l of [org.org_legal_name, org.address, [org.phone, org.email].filter(Boolean).join(" - ")]) {
    if (l) {
      doc.text(pdfText(l), x, yy, { align });
      yy += 3.6;
    }
  }
  return yy;
}

export function buildReceiptPdf(d: ReceiptData, format: "a5" | "ticket"): ArrayBuffer {
  const ticket = format === "ticket";
  const w = ticket ? 80 : 148;
  const items = d.context.items ?? [];
  const h = ticket ? 120 + items.length * 8 : 210;
  const doc = new jsPDF({ unit: "mm", format: [w, h], orientation: "portrait" });
  const m = ticket ? 5 : 10;
  let y = header(doc, d.org, ticket ? w / 2 : m, m + 4, ticket ? "center" : "left") + 3;

  doc.setDrawColor(...BLUE).setLineWidth(0.5).line(m, y, w - m, y);
  y += 6;
  doc.setTextColor(0).setFont("helvetica", "bold").setFontSize(12).text("RECU DE PAIEMENT", w / 2, y, { align: "center" });
  y += 5;
  doc.setFont("courier", "bold").setFontSize(10).text(d.receipt.receipt_number, w / 2, y, { align: "center" });
  y += 4;
  doc.setFont("helvetica", "normal").setFontSize(8).setTextColor(90).text(pdfText(formatDateTime(d.receipt.issued_at)), w / 2, y, { align: "center" });
  y += 6;
  doc.setTextColor(0);

  if (d.receipt.status === "ANNULE") {
    doc.setTextColor(...RED).setFont("helvetica", "bold").setFontSize(10).text("RECU ANNULE", w / 2, y, { align: "center" });
    doc.setTextColor(0);
    y += 6;
  }

  const kv: [string, string][] = [["Recu de", d.receipt.payer_name]];
  if (d.context.student_code) kv.push(["ID etudiant", d.context.student_code]);
  if (d.context.reference_number) kv.push(["Reference", d.context.reference_number]);
  kv.push(["Objet", d.context.label ?? d.receipt.description ?? "-"]);
  doc.setFontSize(9);
  for (const [k, v] of kv) {
    doc.setFont("helvetica", "bold").text(pdfText(k), m, y);
    const lines = doc.splitTextToSize(pdfText(v), w - 2 * m - 24);
    doc.setFont("helvetica", "normal").text(lines, m + 24, y);
    y += 4.5 * lines.length;
  }
  y += 1;

  if (items.length) {
    autoTable(doc, {
      startY: y,
      margin: { left: m, right: m },
      head: [["Article", "Qte", "Total"]],
      body: items.map((i) => [pdfText(i.description), String(i.quantity), pdfMoney(i.line_total)]),
      styles: { fontSize: 8, cellPadding: 1 },
      headStyles: { fillColor: BLUE },
      columnStyles: { 1: { halign: "right" }, 2: { halign: "right" } },
    });
    y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4;
  }

  const rows: [string, string, boolean?][] = [];
  if (Number(d.context.discount ?? 0) > 0) rows.push(["Reduction", "- " + pdfMoney(d.context.discount)]);
  rows.push(["Total a payer", pdfMoney(d.receipt.total_due)]);
  rows.push([`Montant paye (${METHOD_LABELS[d.receipt.method] ?? d.receipt.method})`, pdfMoney(d.receipt.amount), true]);
  rows.push(["Solde restant", pdfMoney(d.receipt.balance_after)]);
  for (const [k, v, bold] of rows) {
    doc.setFont("helvetica", bold ? "bold" : "normal").setFontSize(bold ? 10 : 9);
    doc.text(pdfText(k), m, y);
    doc.text(v, w - m, y, { align: "right" });
    y += 5;
  }
  y += 3;
  doc.setFont("helvetica", "normal").setFontSize(8).setTextColor(90);
  doc.text(pdfText(`Encaisse par : ${d.issuer ?? "-"}`), m, y);
  doc.text("Merci de votre confiance.", m, y + 4);
  return doc.output("arraybuffer");
}

export function buildInvoicePdf(d: InvoiceData): ArrayBuffer {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const m = 14;
  let y = header(doc, d.org, m, m + 4) + 4;
  doc.setTextColor(...BLUE).setFont("helvetica", "bold").setFontSize(20).text("FACTURE", 196, m + 6, { align: "right" });
  doc.setTextColor(0).setFont("courier", "bold").setFontSize(10).text(d.invoice.invoice_number, 196, m + 12, { align: "right" });
  doc.setFont("helvetica", "normal").setFontSize(8).setTextColor(90);
  doc.text(pdfText(`Emise le ${formatDateTime(d.invoice.issued_at)}`), 196, m + 17, { align: "right" });
  if (d.invoice.due_date) doc.text(pdfText(`Echeance : ${formatDate(d.invoice.due_date)}`), 196, m + 21, { align: "right" });

  y = Math.max(y, m + 28);
  doc.setTextColor(0).setFont("helvetica", "bold").setFontSize(8).text("FACTURE A", m, y);
  doc.setFontSize(10).text(pdfText(d.invoice.client_name), m, y + 5);
  doc.setFont("helvetica", "normal").setFontSize(8);
  let yy = y + 9;
  for (const l of [d.client.code && `ID : ${d.client.code}`, d.client.phone, d.client.address]) {
    if (l) {
      doc.text(pdfText(l), m, yy);
      yy += 4;
    }
  }
  if (d.invoice.status === "ANNULE") {
    doc.setTextColor(...RED).setFont("helvetica", "bold").setFontSize(14).text("FACTURE ANNULEE", 196, yy, { align: "right" });
    doc.setTextColor(0);
  }

  autoTable(doc, {
    startY: yy + 4,
    margin: { left: m, right: m },
    head: [["Description", "Qte", "Prix unitaire", "Total"]],
    body: d.lines.map((l) => [pdfText(l.description), String(l.quantity), pdfMoney(l.unit_price), pdfMoney(l.line_total)]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: BLUE },
    columnStyles: { 1: { halign: "right" }, 2: { halign: "right" }, 3: { halign: "right" } },
  });
  y = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 8;

  const t = d.totals;
  const rows: [string, string, boolean][] = [];
  if (Number(t.discount) > 0) rows.push(["Reduction", "- " + pdfMoney(t.discount), false]);
  rows.push(["Total", pdfMoney(t.total), true], ["Deja paye", pdfMoney(t.paid), false], ["Reste a payer", pdfMoney(t.balance), true]);
  for (const [k, v, bold] of rows) {
    doc.setFont("helvetica", bold ? "bold" : "normal").setFontSize(10);
    doc.text(k, 130, y);
    doc.text(v, 196, y, { align: "right" });
    y += 6;
  }
  if (d.payments.length) {
    y += 2;
    doc.setFont("helvetica", "bold").setFontSize(8).text("PAIEMENTS RECUS", m, y);
    y += 4;
    doc.setFont("helvetica", "normal");
    for (const p of d.payments) {
      doc.text(pdfText(`${formatDateTime(p.paid_at)} - ${METHOD_LABELS[p.method] ?? p.method}`), m, y);
      doc.text(pdfMoney(p.amount), 100, y, { align: "right" });
      y += 4;
    }
  }
  doc.setFontSize(8).setTextColor(90).text(pdfText(d.org.invoice_footer || "Merci de votre confiance."), 105, 285, { align: "center" });
  return doc.output("arraybuffer");
}
