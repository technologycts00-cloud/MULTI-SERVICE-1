import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { DashboardStats } from "@/types/dashboard";

export type DashboardResult =
  | { ok: true; data: DashboardStats }
  | { ok: false; message: string };

/** Charge tous les indicateurs en un seul appel RPC (soumis à la RLS). */
export async function getDashboardStats(): Promise<DashboardResult> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("dashboard_stats");

  if (error) {
    const missing = error.code === "PGRST202" || error.code === "42883";
    return {
      ok: false,
      message: missing
        ? "La base de données n'est pas à jour : exécutez les migrations SQL (jusqu'à 0007_dashboard.sql) dans Supabase."
        : "Impossible de charger les indicateurs pour le moment. Réessayez dans un instant.",
    };
  }
  return { ok: true, data: data as unknown as DashboardStats };
}
