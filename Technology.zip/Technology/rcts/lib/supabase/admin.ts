import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * Client à privilèges élevés (SERVICE_ROLE) — contourne la RLS.
 * À utiliser UNIQUEMENT dans du code serveur (Server Actions, routes API),
 * après vérification du rôle de l'utilisateur. Jamais côté navigateur.
 */
export function createAdminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY manquante");

  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, key, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
