import ExcelJS from "exceljs";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { pdfText } from "@/lib/pdf";
import { formatCell, periodLabel, type ReportData } from "@/lib/reports";
import { formatDateTime } from "@/lib/utils";
import type { OrgInfo } from "@/services/documents";

const BLUE: [number, number, number] = [29, 78, 216];

export function buildReportPdf(r: ReportData, org: OrgInfo, by: string): ArrayBuffer {
  const doc = new jsPDF({ unit: "mm", format: "a4", orientation: r.columns.length > 6 ? "landscape" : "portrait" });
  const W = doc.internal.pageSize.getWidth();
  const m = 12;
  doc.setTextColor(...BLUE).setFont("helvetica", "bold").setFontSize(14).text(pdfText((org.org_name || "R.CTS").toUpperCase()), m, 14);
  doc.setTextColor(60).setFont("helvetica", "normal").setFontSize(8).text(pdfText(org.org_legal_name || ""), m, 18);
  doc.setTextColor(0).setFont("helvetica", "bold").setFontSize(13).text(pdfText(r.title), W - m, 14, { align: "right" });
  doc.setFont("helvetica", "normal").setFontSize(8).setTextColor(90);
  doc.text(pdfText(`Periode : ${periodLabel(r.period)}`), W - m, 18, { align: "right" });
  doc.text(pdfText(`Genere le ${formatDateTime(new Date().toISOString())} par ${by}`), W - m, 22, { align: "right" });
  doc.setDrawColor(...BLUE).setLineWidth(0.5).line(m, 25, W - m, 25);

  let y = 31;
  doc.setTextColor(0).setFontSize(9);
  for (const s of r.summary) {
    doc.setFont("helvetica", "normal").text(pdfText(s.label), m, y);
    doc.setFont("helvetica", "bold").text(pdfText(formatCell(s.value, s.type)), m + 80, y, { align: "right" });
    y += 4.8;
  }
  const right = new Set(r.columns.filter((c) => c.type === "money" || c.type === "int").map((c) => c.key));
  autoTable(doc, {
    startY: y + 3,
    margin: { left: m, right: m, bottom: 14 },
    head: [r.columns.map((c) => pdfText(c.label))],
    body: r.rows.map((row) => r.columns.map((c) => pdfText(formatCell(row[c.key], c.type)))),
    styles: { fontSize: 7.5, cellPadding: 1.4 },
    headStyles: { fillColor: BLUE },
    alternateRowStyles: { fillColor: [244, 247, 252] },
    columnStyles: Object.fromEntries(r.columns.map((c, i) => [i, { halign: right.has(c.key) ? "right" : "left" }])),
    didDrawPage: () => {
      const n = doc.getNumberOfPages();
      doc.setFontSize(7).setTextColor(120).text(pdfText(`${org.org_name || "R.CTS"} - ${r.title} - page ${n}`), W / 2, doc.internal.pageSize.getHeight() - 6, { align: "center" });
    },
  });
  if (r.truncated) {
    doc.setFontSize(8).setTextColor(185, 28, 28).text("Rapport tronque aux 5 000 premieres lignes : reduisez la periode.", m, doc.internal.pageSize.getHeight() - 10);
  }
  return doc.output("arraybuffer");
}

export async function buildReportXlsx(r: ReportData, org: OrgInfo, by: string): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = org.org_name || "R.CTS";
  const ws = wb.addWorksheet(r.title.slice(0, 31).replace(/[\\/?*[\]:]/g, " "));
  const text = (s: string) => (/^[=+\-@]/.test(s) ? "'" + s : s); // pas de formule injectée
  ws.addRow([(org.org_legal_name || org.org_name || "R.CTS").toString()]).font = { bold: true, size: 13, color: { argb: "FF1D4ED8" } };
  ws.addRow([r.title]).font = { bold: true, size: 12 };
  ws.addRow([`Période : ${periodLabel(r.period)}`, "", `Généré le ${formatDateTime(new Date().toISOString())} par ${by}`]);
  ws.addRow([]);
  for (const s of r.summary) {
    const row = ws.addRow([s.label, s.type === "money" || s.type === "int" ? Number(s.value) : formatCell(s.value, s.type)]);
    row.getCell(1).font = { bold: true };
    if (s.type === "money") row.getCell(2).numFmt = '#,##0.00 "HTG"';
  }
  ws.addRow([]);
  const head = ws.addRow(r.columns.map((c) => c.label));
  head.eachCell((c) => {
    c.font = { bold: true, color: { argb: "FFFFFFFF" } };
    c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1D4ED8" } };
  });
  for (const row of r.rows) {
    const xr = ws.addRow(r.columns.map((c) => {
      const v = row[c.key];
      if (v === null || v === undefined || v === "") return "";
      if (c.type === "money" || c.type === "int") return Number(v);
      return text(formatCell(v, c.type));
    }));
    r.columns.forEach((c, i) => {
      if (c.type === "money") xr.getCell(i + 1).numFmt = '#,##0.00';
      if (c.type === "int") xr.getCell(i + 1).numFmt = "#,##0";
    });
  }
  r.columns.forEach((c, i) => {
    const w = Math.max(c.label.length, ...r.rows.slice(0, 200).map((row) => formatCell(row[c.key], c.type).length));
    ws.getColumn(i + 1).width = Math.min(45, Math.max(12, w + 2));
  });
  ws.views = [{ state: "frozen", ySplit: head.number }];
  return Buffer.from(await wb.xlsx.writeBuffer());
}
