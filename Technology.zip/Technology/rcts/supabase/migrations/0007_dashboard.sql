-- PHASE 3 — Dashboard : toutes les données viennent de la base.
-- Fonction SECURITY INVOKER : la RLS de l'utilisateur s'applique aux lectures.
-- Les sections non autorisées pour le rôle sont renvoyées à null (pas de zéros trompeurs).
--
-- Définitions :
--   Chiffre d'affaires / revenus = entrées de caisse valides (paiements encaissés, toutes méthodes)
--   Solde de caisse              = espèces uniquement (entrées - sorties)
--   Créances                     = soldes restants des inscriptions, ventes et commandes non annulées
--   Jours et mois                = fuseau America/Port-au-Prince

create function public.dashboard_stats()
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  tz         constant text := 'America/Port-au-Prince';
  v_role     public.user_role := public.current_role();
  v_now      timestamp := now() at time zone tz;
  v_today_ts timestamptz := date_trunc('day', v_now) at time zone tz;
  v_month_ts timestamptz := date_trunc('month', v_now) at time zone tz;
  v_from     timestamp := date_trunc('month', v_now) - interval '11 months';
  v_from_ts  timestamptz := (date_trunc('month', v_now) - interval '11 months') at time zone tz;
  v_admin    boolean := v_role = 'ADMIN';
  v_see_fin  boolean := v_role in ('ADMIN', 'CAISSIER');
  v_see_sch  boolean := v_role in ('ADMIN', 'SECRETAIRE', 'FORMATEUR');
  v_see_stk  boolean := v_role in ('ADMIN', 'GESTIONNAIRE', 'CAISSIER');
  v_finance  jsonb;
  v_school   jsonb;
  v_stock    jsonb;
  v_recent   jsonb;
  v_rev      jsonb;
  v_exp      jsonb;
  v_enr      jsonb;
  v_sal      jsonb;
  v_cat      jsonb;
begin
  if v_role is null then
    raise exception 'Accès refusé' using errcode = '42501';
  end if;

  -- ------------------------------------------------------------------ Finances
  if v_see_fin then
    v_finance := jsonb_build_object(
      'revenue_today', (select coalesce(sum(amount), 0) from public.cash_transactions
                         where direction = 'IN' and status = 'VALIDE' and occurred_at >= v_today_ts),
      'revenue_month', (select coalesce(sum(amount), 0) from public.cash_transactions
                         where direction = 'IN' and status = 'VALIDE' and occurred_at >= v_month_ts),
      'total_payments', (select coalesce(sum(amount), 0) from public.payments where status = 'VALIDE'),
      'cash_balance',   (select cash_on_hand from public.v_cash_balance),
      'receivables',
        (select coalesce(sum(balance), 0) from public.enrollments where status <> 'ANNULEE')
      + (select coalesce(sum(balance), 0) from public.sales where status = 'VALIDE')
      + (select coalesce(sum(balance), 0) from public.service_orders where status <> 'ANNULE'),
      'pending_count',
        (select count(*) from public.enrollments where status <> 'ANNULEE' and balance > 0)
      + (select count(*) from public.sales where status = 'VALIDE' and balance > 0)
      + (select count(*) from public.service_orders where status <> 'ANNULE' and balance > 0),
      'total_expenses', case when v_admin then
        (select coalesce(sum(amount), 0) from public.expenses where status = 'VALIDE') end,
      'expenses_month', case when v_admin then
        (select coalesce(sum(amount), 0) from public.expenses
          where status = 'VALIDE' and expense_date >= v_month_ts::date) end
    );

    select jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'), 'total', coalesce(x.total, 0)) order by m)
      into v_rev
      from generate_series(v_from, date_trunc('month', v_now), interval '1 month') m
      left join (select date_trunc('month', occurred_at at time zone tz) as mm, sum(amount) as total
                   from public.cash_transactions
                  where direction = 'IN' and status = 'VALIDE' and occurred_at >= v_from_ts
                  group by 1) x on x.mm = m;

    select jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'),
                                        'total', coalesce(x.total, 0), 'count', coalesce(x.n, 0)) order by m)
      into v_sal
      from generate_series(v_from, date_trunc('month', v_now), interval '1 month') m
      left join (select date_trunc('month', sale_date at time zone tz) as mm, sum(total) as total, count(*) as n
                   from public.sales
                  where status = 'VALIDE' and sale_date >= v_from_ts
                  group by 1) x on x.mm = m;

    select coalesce(jsonb_agg(jsonb_build_object('category', category, 'total', total) order by total desc), '[]')
      into v_cat
      from (select category, sum(amount) as total
              from public.cash_transactions
             where direction = 'IN' and status = 'VALIDE' and occurred_at >= v_from_ts
             group by category) c;

    select coalesce(jsonb_agg(to_jsonb(r) order by r.occurred_at desc), '[]')
      into v_recent
      from (select ct.id, ct.occurred_at, ct.direction, ct.category, ct.description,
                   ct.amount, ct.method, ct.status, s.full_name as user_name
              from public.cash_transactions ct
              left join public.v_staff s on s.id = ct.created_by
             order by ct.occurred_at desc
             limit 10) r;
  end if;

  if v_admin then
    select jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'), 'total', coalesce(x.total, 0)) order by m)
      into v_exp
      from generate_series(v_from, date_trunc('month', v_now), interval '1 month') m
      left join (select date_trunc('month', expense_date::timestamp) as mm, sum(amount) as total
                   from public.expenses
                  where status = 'VALIDE' and expense_date >= v_from::date
                  group by 1) x on x.mm = m;
  end if;

  -- --------------------------------------------------------------------- Élèves
  if v_see_sch then
    v_school := jsonb_build_object(
      'students_total',  (select count(*) from public.students where not is_archived),
      'students_active', (select count(*) from public.students where not is_archived and status = 'ACTIF'),
      'new_enrollments_month', (select count(*) from public.enrollments
                                 where status <> 'ANNULEE' and enrolled_on >= v_month_ts::date),
      'unpaid_enrollments', (select count(*) from public.enrollments
                              where status <> 'ANNULEE' and balance > 0),
      'enrollment_receivables', (select coalesce(sum(balance), 0) from public.enrollments
                                  where status <> 'ANNULEE'));

    select jsonb_agg(jsonb_build_object('month', to_char(m, 'YYYY-MM'), 'count', coalesce(x.n, 0)) order by m)
      into v_enr
      from generate_series(v_from, date_trunc('month', v_now), interval '1 month') m
      left join (select date_trunc('month', enrolled_on::timestamp) as mm, count(*) as n
                   from public.enrollments
                  where status <> 'ANNULEE' and enrolled_on >= v_from::date
                  group by 1) x on x.mm = m;
  end if;

  -- ---------------------------------------------------------------------- Stock
  if v_see_stk then
    v_stock := jsonb_build_object(
      'low_stock',    (select count(*) from public.products where status = 'ACTIF' and stock_state = 'FAIBLE'),
      'out_of_stock', (select count(*) from public.products where status = 'ACTIF' and stock_state = 'RUPTURE'),
      'alerts', (select coalesce(jsonb_agg(to_jsonb(a) order by a.current_stock, a.name), '[]')
                   from (select id, code, name, current_stock, min_stock, stock_state
                           from public.products
                          where status = 'ACTIF' and stock_state <> 'OK'
                          order by current_stock, name
                          limit 8) a));
  end if;

  return jsonb_build_object(
    'role',         v_role,
    'generated_at', now(),
    'finance',      v_finance,
    'school',       v_school,
    'stock',        v_stock,
    'recent',       v_recent,
    'charts', jsonb_build_object(
      'revenue',     v_rev,
      'expenses',    v_exp,
      'enrollments', v_enr,
      'sales',       v_sal,
      'by_category', v_cat));
end $$;

revoke all on function public.dashboard_stats() from public, anon;
grant execute on function public.dashboard_stats() to authenticated;
