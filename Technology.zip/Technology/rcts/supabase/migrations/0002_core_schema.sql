-- PHASE 2 — Schéma métier R.CTS
-- Montants : numeric(14,2) en HTG. Identifiants : UUID. Aucune suppression des
-- données financières : annulation (status = 'ANNULE') ou archivage.

-- ---------------------------------------------------------------------------
-- Schéma privé : fonctions internes non exposées par l'API (PostgREST)
-- ---------------------------------------------------------------------------
create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;
alter default privileges in schema private revoke execute on functions from public;

-- ---------------------------------------------------------------------------
-- Types énumérés
-- ---------------------------------------------------------------------------
create type public.payment_method   as enum ('ESPECES','MONCASH','NATCASH','VIREMENT','AUTRE');
create type public.gender           as enum ('M','F');
create type public.student_status   as enum ('ACTIF','TERMINE','SUSPENDU','INACTIF');
create type public.training_status  as enum ('PLANIFIEE','EN_COURS','TERMINEE','ANNULEE');
create type public.enrollment_status as enum ('ACTIVE','TERMINEE','ABANDONNEE','ANNULEE');
create type public.record_status    as enum ('VALIDE','ANNULE');
create type public.payment_kind     as enum ('INSCRIPTION','VENTE','SERVICE');
create type public.stock_movement_type as enum ('ENTREE','SORTIE','AJUSTEMENT','INVENTAIRE','VENTE','ACHAT','ANNULATION');
create type public.cash_direction   as enum ('IN','OUT');
create type public.cash_category    as enum ('FORMATION','VENTE','SERVICE','DEPENSE','ACHAT_FOURNISSEUR','AUTRE');
create type public.service_order_status as enum ('EN_ATTENTE','EN_COURS','TERMINE','LIVRE','ANNULE');
create type public.customer_type    as enum ('PARTICULIER','ENTREPRISE','INSTITUTION');
create type public.product_status   as enum ('ACTIF','INACTIF');

-- ---------------------------------------------------------------------------
-- Paramètres, compteurs de numérotation, matrice de rôles
-- ---------------------------------------------------------------------------
create table public.settings (
  key         text primary key,
  value       jsonb not null,
  description text,
  updated_by  uuid references public.profiles(id) on delete set null,
  updated_at  timestamptz not null default now()
);

-- Compteurs annuels (reçus, ventes, etc.) : accès uniquement via private.next_number()
create table public.counters (
  key   text   not null,
  year  int    not null,
  value bigint not null default 0,
  primary key (key, year)
);

-- Matrice des permissions par rôle et par module (éditable par l'ADMIN)
create table public.users_roles (
  role       public.user_role not null,
  module     text not null,
  can_view   boolean not null default false,
  can_create boolean not null default false,
  can_edit   boolean not null default false,
  can_delete boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (role, module)
);

-- ---------------------------------------------------------------------------
-- Formation : élèves, formations, inscriptions, certificats
-- ---------------------------------------------------------------------------
create table public.students (
  id           uuid primary key default gen_random_uuid(),
  student_code text not null unique,
  first_name   text not null check (length(trim(first_name)) > 0),
  last_name    text not null check (length(trim(last_name)) > 0),
  gender       public.gender,
  birth_date   date check (birth_date is null or birth_date < current_date),
  phone        text,
  email        text,
  address      text,
  photo_url    text,
  enrolled_on  date not null default current_date,
  status       public.student_status not null default 'ACTIF',
  is_archived  boolean not null default false,
  notes        text,
  created_by   uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table public.trainings (
  id               uuid primary key default gen_random_uuid(),
  name             text not null check (length(trim(name)) > 0),
  description      text,
  duration_value   numeric(6,1) not null check (duration_value > 0),
  duration_unit    text not null default 'MOIS' check (duration_unit in ('HEURES','JOURS','SEMAINES','MOIS')),
  price            numeric(14,2) not null check (price >= 0),
  registration_fee numeric(14,2) not null default 0 check (registration_fee >= 0),
  max_students     int check (max_students is null or max_students > 0),
  start_date       date,
  end_date         date,
  schedule         text,
  trainer_id       uuid references public.profiles(id) on delete set null,
  status           public.training_status not null default 'PLANIFIEE',
  is_archived      boolean not null default false,
  created_by       uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  check (end_date is null or start_date is null or end_date >= start_date)
);

create table public.enrollments (
  id                uuid primary key default gen_random_uuid(),
  enrollment_number text not null unique,
  student_id        uuid not null references public.students(id) on delete restrict,
  training_id       uuid not null references public.trainings(id) on delete restrict,
  enrolled_on       date not null default current_date,
  -- Montants figés à l'inscription (un changement de tarif n'affecte pas l'existant)
  training_price    numeric(14,2) not null check (training_price >= 0),
  registration_fee  numeric(14,2) not null default 0 check (registration_fee >= 0),
  discount          numeric(14,2) not null default 0 check (discount >= 0),
  amount_paid       numeric(14,2) not null default 0 check (amount_paid >= 0),
  -- SOLDE = prix total - réduction - total payé
  total_due         numeric(14,2) generated always as (training_price + registration_fee - discount) stored,
  balance           numeric(14,2) generated always as (training_price + registration_fee - discount - amount_paid) stored,
  payment_status    text generated always as (
    case when amount_paid >= training_price + registration_fee - discount then 'SOLDE'
         when amount_paid > 0 then 'PARTIEL'
         else 'IMPAYE' end) stored,
  status            public.enrollment_status not null default 'ACTIVE',
  notes             text,
  created_by        uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (discount <= training_price + registration_fee),
  check (amount_paid <= training_price + registration_fee - discount)
);
create unique index enrollments_active_unique
  on public.enrollments (student_id, training_id) where status <> 'ANNULEE';

create table public.certificates (
  id                 uuid primary key default gen_random_uuid(),
  certificate_number text not null unique,
  enrollment_id      uuid not null unique references public.enrollments(id) on delete restrict,
  student_id         uuid not null references public.students(id) on delete restrict,
  training_id        uuid not null references public.trainings(id) on delete restrict,
  issued_on          date not null default current_date,
  issued_by          uuid references public.profiles(id) on delete set null default auth.uid(),
  notes              text,
  created_at         timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Clients, fournisseurs, catalogue de services
-- ---------------------------------------------------------------------------
create table public.customers (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (length(trim(name)) > 0),
  phone         text,
  email         text,
  address       text,
  customer_type public.customer_type not null default 'PARTICULIER',
  notes         text,
  is_archived   boolean not null default false,
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table public.suppliers (
  id                uuid primary key default gen_random_uuid(),
  name              text not null check (length(trim(name)) > 0),
  company           text,
  phone             text,
  email             text,
  address           text,
  products_supplied text,
  notes             text,
  is_archived       boolean not null default false,
  created_by        uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create table public.services (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique check (length(trim(name)) > 0),
  category    text,
  description text,
  unit_price  numeric(14,2) not null default 0 check (unit_price >= 0),
  unit        text not null default 'unité',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.service_orders (
  id             uuid primary key default gen_random_uuid(),
  order_number   text not null unique,
  customer_id    uuid not null references public.customers(id) on delete restrict,
  service_id     uuid not null references public.services(id) on delete restrict,
  quantity       int not null check (quantity > 0),
  unit_price     numeric(14,2) not null check (unit_price >= 0),
  amount_paid    numeric(14,2) not null default 0 check (amount_paid >= 0),
  total          numeric(14,2) generated always as (quantity * unit_price) stored,
  balance        numeric(14,2) generated always as (quantity * unit_price - amount_paid) stored,
  order_date     date not null default current_date,
  due_date       date,
  status         public.service_order_status not null default 'EN_ATTENTE',
  responsible_id uuid references public.profiles(id) on delete set null,
  comment        text,
  created_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (due_date is null or due_date >= order_date),
  check (amount_paid <= quantity * unit_price)
);

-- ---------------------------------------------------------------------------
-- Produits et stock
-- ---------------------------------------------------------------------------
create table public.product_categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique check (length(trim(name)) > 0),
  description text,
  created_at  timestamptz not null default now()
);

create table public.products (
  id             uuid primary key default gen_random_uuid(),
  code           text not null unique,
  name           text not null check (length(trim(name)) > 0),
  category_id    uuid references public.product_categories(id) on delete set null,
  description    text,
  purchase_price numeric(14,2) not null default 0 check (purchase_price >= 0),
  sale_price     numeric(14,2) not null check (sale_price >= 0),
  current_stock  int not null default 0 check (current_stock >= 0),
  min_stock      int not null default 0 check (min_stock >= 0),
  supplier_id    uuid references public.suppliers(id) on delete set null,
  status         public.product_status not null default 'ACTIF',
  stock_state    text generated always as (
    case when current_stock <= 0 then 'RUPTURE'
         when current_stock <= min_stock then 'FAIBLE'
         else 'OK' end) stored,
  created_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table public.stock_movements (
  id              uuid primary key default gen_random_uuid(),
  product_id      uuid not null references public.products(id) on delete restrict,
  movement_type   public.stock_movement_type not null,
  quantity_change int not null check (quantity_change <> 0),   -- signé : + entrée, - sortie
  stock_before    int not null default 0,
  stock_after     int not null default 0,
  reason          text,
  reference       text,
  source_type     text,
  source_id       uuid,
  created_by      uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Ventes
-- ---------------------------------------------------------------------------
create table public.sales (
  id             uuid primary key default gen_random_uuid(),
  sale_number    text not null unique,
  customer_id    uuid references public.customers(id) on delete restrict,
  sale_date      timestamptz not null default now(),
  subtotal       numeric(14,2) not null check (subtotal >= 0),
  discount       numeric(14,2) not null default 0 check (discount >= 0),
  amount_paid    numeric(14,2) not null default 0 check (amount_paid >= 0),
  -- TOTAL = SOUS-TOTAL - RÉDUCTION
  total          numeric(14,2) generated always as (subtotal - discount) stored,
  balance        numeric(14,2) generated always as (subtotal - discount - amount_paid) stored,
  payment_status text generated always as (
    case when amount_paid >= subtotal - discount then 'PAYEE'
         when amount_paid > 0 then 'PARTIELLE'
         else 'IMPAYEE' end) stored,
  payment_method public.payment_method not null default 'ESPECES',
  status         public.record_status not null default 'VALIDE',
  notes          text,
  seller_id      uuid references public.profiles(id) on delete set null,
  voided_at      timestamptz,
  voided_by      uuid references public.profiles(id) on delete set null,
  void_reason    text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (discount <= subtotal),
  check (amount_paid <= subtotal - discount)
);

create table public.sale_items (
  id          uuid primary key default gen_random_uuid(),
  sale_id     uuid not null references public.sales(id) on delete restrict,
  product_id  uuid references public.products(id) on delete restrict,
  service_id  uuid references public.services(id) on delete restrict,
  description text not null,
  quantity    int not null check (quantity > 0),
  unit_price  numeric(14,2) not null check (unit_price >= 0),
  line_total  numeric(14,2) generated always as (quantity * unit_price) stored,
  created_at  timestamptz not null default now(),
  check (num_nonnulls(product_id, service_id) = 1)
);

-- ---------------------------------------------------------------------------
-- Paiements, caisse, reçus, factures
-- ---------------------------------------------------------------------------
create table public.payments (
  id               uuid primary key default gen_random_uuid(),
  payment_number   text not null unique,
  kind             public.payment_kind not null,
  student_id       uuid references public.students(id) on delete restrict,
  customer_id      uuid references public.customers(id) on delete restrict,
  enrollment_id    uuid references public.enrollments(id) on delete restrict,
  sale_id          uuid references public.sales(id) on delete restrict,
  service_order_id uuid references public.service_orders(id) on delete restrict,
  amount           numeric(14,2) not null check (amount > 0),
  method           public.payment_method not null default 'ESPECES',
  reference        text,
  description      text,
  paid_at          timestamptz not null default now(),
  status           public.record_status not null default 'VALIDE',
  created_by       uuid references public.profiles(id) on delete set null default auth.uid(),
  voided_at        timestamptz,
  voided_by        uuid references public.profiles(id) on delete set null,
  void_reason      text,
  created_at       timestamptz not null default now(),
  check (num_nonnulls(enrollment_id, sale_id, service_order_id) = 1),
  check ((kind = 'INSCRIPTION' and enrollment_id is not null)
      or (kind = 'VENTE'       and sale_id is not null)
      or (kind = 'SERVICE'     and service_order_id is not null))
);

-- Journal de caisse / flux financiers (toutes méthodes). Le solde de caisse
-- physique = somme des mouvements ESPECES valides.
create table public.cash_transactions (
  id          uuid primary key default gen_random_uuid(),
  direction   public.cash_direction not null,
  category    public.cash_category not null,
  amount      numeric(14,2) not null check (amount > 0),
  method      public.payment_method not null,
  description text,
  occurred_at timestamptz not null default now(),
  source_type text not null check (source_type in ('PAYMENT','EXPENSE','SUPPLIER_PAYMENT','MANUAL')),
  source_id   uuid,
  status      public.record_status not null default 'VALIDE',
  created_by  uuid references public.profiles(id) on delete set null default auth.uid(),
  voided_at   timestamptz,
  created_at  timestamptz not null default now()
);
create unique index cash_transactions_source_unique
  on public.cash_transactions (source_type, source_id) where source_id is not null;

create table public.receipts (
  id             uuid primary key default gen_random_uuid(),
  receipt_number text not null unique,        -- ex. RCTS-2026-000001
  payment_id     uuid not null unique references public.payments(id) on delete restrict,
  issued_at      timestamptz not null default now(),
  issued_by      uuid references public.profiles(id) on delete set null,
  payer_name     text not null,
  description    text,
  amount         numeric(14,2) not null check (amount > 0),
  method         public.payment_method not null,
  total_due      numeric(14,2) not null,
  balance_after  numeric(14,2) not null,
  status         public.record_status not null default 'VALIDE'
);

create table public.invoices (
  id               uuid primary key default gen_random_uuid(),
  invoice_number   text not null unique,
  kind             public.payment_kind not null,
  student_id       uuid references public.students(id) on delete restrict,
  customer_id      uuid references public.customers(id) on delete restrict,
  enrollment_id    uuid references public.enrollments(id) on delete restrict,
  sale_id          uuid references public.sales(id) on delete restrict,
  service_order_id uuid references public.service_orders(id) on delete restrict,
  client_name      text not null,
  description      text,
  total            numeric(14,2) not null check (total >= 0),
  issued_at        timestamptz not null default now(),
  due_date         date,
  notes            text,
  status           public.record_status not null default 'VALIDE',
  issued_by        uuid references public.profiles(id) on delete set null,
  check (num_nonnulls(enrollment_id, sale_id, service_order_id) = 1)
);
create unique index invoices_target_unique
  on public.invoices ((coalesce(enrollment_id, sale_id, service_order_id))) where status = 'VALIDE';

-- ---------------------------------------------------------------------------
-- Dépenses
-- ---------------------------------------------------------------------------
create table public.expense_categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique check (length(trim(name)) > 0),
  is_active  boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.expenses (
  id             uuid primary key default gen_random_uuid(),
  expense_number text not null unique,
  expense_date   date not null default current_date,
  category_id    uuid not null references public.expense_categories(id) on delete restrict,
  description    text not null check (length(trim(description)) > 0),
  amount         numeric(14,2) not null check (amount > 0),
  method         public.payment_method not null default 'ESPECES',
  responsible_id uuid references public.profiles(id) on delete set null,
  receipt_url    text,                       -- justificatif (Supabase Storage)
  status         public.record_status not null default 'VALIDE',
  voided_at      timestamptz,
  voided_by      uuid references public.profiles(id) on delete set null,
  void_reason    text,
  created_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Achats fournisseurs
-- ---------------------------------------------------------------------------
create table public.purchases (
  id              uuid primary key default gen_random_uuid(),
  purchase_number text not null unique,
  supplier_id     uuid not null references public.suppliers(id) on delete restrict,
  purchase_date   date not null default current_date,
  total_amount    numeric(14,2) not null check (total_amount >= 0),
  amount_paid     numeric(14,2) not null default 0 check (amount_paid >= 0),
  balance         numeric(14,2) generated always as (total_amount - amount_paid) stored,
  status          public.record_status not null default 'VALIDE',
  notes           text,
  created_by      uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at      timestamptz not null default now(),
  check (amount_paid <= total_amount)
);

create table public.purchase_items (
  id          uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  product_id  uuid not null references public.products(id) on delete restrict,
  quantity    int not null check (quantity > 0),
  unit_cost   numeric(14,2) not null check (unit_cost >= 0),
  line_total  numeric(14,2) generated always as (quantity * unit_cost) stored
);

create table public.supplier_payments (
  id             uuid primary key default gen_random_uuid(),
  payment_number text not null unique,
  purchase_id    uuid not null references public.purchases(id) on delete restrict,
  supplier_id    uuid not null references public.suppliers(id) on delete restrict,
  amount         numeric(14,2) not null check (amount > 0),
  method         public.payment_method not null default 'ESPECES',
  reference      text,
  paid_at        timestamptz not null default now(),
  status         public.record_status not null default 'VALIDE',
  created_by     uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at     timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Journal d'audit (immuable)
-- ---------------------------------------------------------------------------
create table public.audit_logs (
  id          bigint generated always as identity primary key,
  user_id     uuid,
  user_email  text,
  action      text not null,          -- INSERT / UPDATE / DELETE
  module      text not null,          -- nom de la table
  record_id   text,
  old_value   jsonb,
  new_value   jsonb,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Index (clés étrangères, filtres courants, recherche)
-- ---------------------------------------------------------------------------
create index students_status_idx          on public.students (status) where not is_archived;
create index students_last_name_idx       on public.students (lower(last_name), lower(first_name));
create index trainings_trainer_idx        on public.trainings (trainer_id);
create index trainings_status_idx         on public.trainings (status);
create index enrollments_student_idx      on public.enrollments (student_id);
create index enrollments_training_idx     on public.enrollments (training_id);
create index enrollments_date_idx         on public.enrollments (enrolled_on);
create index certificates_student_idx     on public.certificates (student_id);
create index products_category_idx        on public.products (category_id);
create index products_supplier_idx        on public.products (supplier_id);
create index products_stock_state_idx     on public.products (stock_state) where stock_state <> 'OK';
create index stock_movements_product_idx  on public.stock_movements (product_id, created_at desc);
create index sales_customer_idx           on public.sales (customer_id);
create index sales_date_idx               on public.sales (sale_date desc);
create index sale_items_sale_idx          on public.sale_items (sale_id);
create index sale_items_product_idx       on public.sale_items (product_id);
create index service_orders_customer_idx  on public.service_orders (customer_id);
create index service_orders_status_idx    on public.service_orders (status);
create index payments_enrollment_idx      on public.payments (enrollment_id);
create index payments_sale_idx            on public.payments (sale_id);
create index payments_service_order_idx   on public.payments (service_order_id);
create index payments_student_idx         on public.payments (student_id);
create index payments_customer_idx        on public.payments (customer_id);
create index payments_date_idx            on public.payments (paid_at desc);
create index cash_transactions_date_idx   on public.cash_transactions (occurred_at desc);
create index expenses_date_idx            on public.expenses (expense_date desc);
create index expenses_category_idx        on public.expenses (category_id);
create index purchases_supplier_idx       on public.purchases (supplier_id);
create index purchase_items_purchase_idx  on public.purchase_items (purchase_id);
create index supplier_payments_purchase_idx on public.supplier_payments (purchase_id);
create index audit_logs_module_idx        on public.audit_logs (module, created_at desc);
create index audit_logs_user_idx          on public.audit_logs (user_id, created_at desc);

-- Recherche rapide par sous-chaîne (pg_trgm) : élèves, produits, clients, fournisseurs
do $$
declare
  s text;
  r record;
begin
  select n.nspname into s
    from pg_extension e join pg_namespace n on n.oid = e.extnamespace
   where e.extname = 'pg_trgm';
  if s is null then
    create schema if not exists extensions;
    create extension pg_trgm with schema extensions;
    s := 'extensions';
  end if;

  for r in select * from (values
    ('students',  'students_search_idx',  $e$(first_name || ' ' || last_name || ' ' || student_code)$e$),
    ('products',  'products_search_idx',  $e$(name || ' ' || code)$e$),
    ('customers', 'customers_search_idx', $e$(name || ' ' || coalesce(phone, ''))$e$),
    ('suppliers', 'suppliers_search_idx', $e$(name || ' ' || coalesce(company, ''))$e$)
  ) as t(tbl, idx, expr)
  loop
    execute format('create index %I on public.%I using gin (%s %I.gin_trgm_ops)', r.idx, r.tbl, r.expr, s);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Vues (security_invoker : la RLS de l'utilisateur s'applique)
-- ---------------------------------------------------------------------------
create view public.v_cash_balance with (security_invoker = true) as
select
  coalesce(sum(case when direction = 'IN'  and method = 'ESPECES' then amount end), 0)
- coalesce(sum(case when direction = 'OUT' and method = 'ESPECES' then amount end), 0) as cash_on_hand,
  coalesce(sum(case when direction = 'IN'  then amount end), 0) as total_in,
  coalesce(sum(case when direction = 'OUT' then amount end), 0) as total_out
from public.cash_transactions
where status = 'VALIDE';

create view public.v_student_balances with (security_invoker = true) as
select student_id,
       sum(total_due)   as total_due,
       sum(amount_paid) as total_paid,
       sum(balance)     as balance
from public.enrollments
where status <> 'ANNULEE'
group by student_id;

create view public.v_customer_balances with (security_invoker = true) as
select customer_id,
       sum(total)       as total,
       sum(amount_paid) as total_paid,
       sum(balance)     as balance
from (
  select customer_id, total, amount_paid, balance
    from public.sales where status = 'VALIDE' and customer_id is not null
  union all
  select customer_id, total, amount_paid, balance
    from public.service_orders where status <> 'ANNULE'
) x
group by customer_id;

create view public.v_supplier_balances with (security_invoker = true) as
select supplier_id,
       sum(total_amount) as total_purchased,
       sum(amount_paid)  as total_paid,
       sum(balance)      as amount_due
from public.purchases
where status = 'VALIDE'
group by supplier_id;

-- Annuaire minimal du personnel (nom + rôle) visible par tout utilisateur connecté
create view public.v_staff as
select id, full_name, role from public.profiles where is_active;
