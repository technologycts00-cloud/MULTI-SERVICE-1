-- PHASE 4 (suite) — Intégrité des formations

-- Une capacité ne peut pas être fixée en dessous du nombre de places déjà occupées,
-- et une formation qui a des inscriptions actives ne peut pas être archivée.
create function private.guard_training_change()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_seats  int;
  v_active int;
begin
  if new.max_students is not null and new.max_students is distinct from old.max_students then
    select count(*) into v_seats from public.enrollments
     where training_id = new.id and status in ('ACTIVE', 'TERMINEE');
    if v_seats > new.max_students then
      raise exception 'Capacité impossible : % place(s) sont déjà occupées (minimum %)', v_seats, v_seats;
    end if;
  end if;

  if new.is_archived and not old.is_archived then
    select count(*) into v_active from public.enrollments
     where training_id = new.id and status = 'ACTIVE';
    if v_active > 0 then
      raise exception 'Cette formation a % inscription(s) active(s) : terminez-les ou annulez-les avant d''archiver', v_active;
    end if;
  end if;
  return new;
end $$;

create trigger trainings_guard_change before update on public.trainings
  for each row execute function private.guard_training_change();

-- Réactiver une inscription abandonnée occupe de nouveau une place : la capacité doit le permettre.
create function private.guard_enrollment_seat()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_max   int;
  v_seats int;
begin
  if new.status in ('ACTIVE', 'TERMINEE') and old.status not in ('ACTIVE', 'TERMINEE') then
    select max_students into v_max from public.trainings where id = new.training_id for update;
    if v_max is not null then
      select count(*) into v_seats from public.enrollments
       where training_id = new.training_id and status in ('ACTIVE', 'TERMINEE') and id <> new.id;
      if v_seats >= v_max then
        raise exception 'Formation complète (% places) : impossible de réactiver cette inscription', v_max;
      end if;
    end if;
  end if;
  return new;
end $$;

create trigger enrollments_guard_seat before update of status on public.enrollments
  for each row execute function private.guard_enrollment_seat();

