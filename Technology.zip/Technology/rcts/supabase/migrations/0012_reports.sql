-- PHASE 9 : rapports (9 types) — données tabulaires prêtes pour PDF / Excel / CSV / impression
--
-- report_data(type, du, au) renvoie :
--   { type, title, period:{from,to}, columns:[{key,label,type}], rows:[{…}], summary:[{label,value,type}], truncated }
-- Types de colonnes : text | int | money | date | datetime | status
-- La RLS de chaque table s'applique (security invoker) ; le rôle est en plus vérifié par type de rapport.
-- Maximum 5 000 lignes par rapport (le résumé, lui, porte sur toutes les lignes de la période).

create function public.report_data(p_type text, p_from date default null, p_to date default null)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  c_max   constant int := 5000;
  v_from  timestamptz := case when p_from is null then null else private.day_start(p_from) end;
  v_to    timestamptz := case when p_to   is null then null else private.day_start(p_to + 1) end;
  v_title text;
  v_cols  jsonb;
  v_rows  jsonb := '[]'::jsonb;
  v_sum   jsonb := '[]'::jsonb;
  v_count int := 0;
begin
  if p_from is not null and p_to is not null and p_to < p_from then
    raise exception 'La date de fin précède la date de début';
  end if;

  -- Contrôle d'accès par type de rapport
  if not private.has_role(
       variadic case p_type
         when 'caisse'       then array['ADMIN','CAISSIER']::public.user_role[]
         when 'ventes'       then array['ADMIN','CAISSIER']::public.user_role[]
         when 'paiements'    then array['ADMIN','CAISSIER']::public.user_role[]
         when 'formations'   then array['ADMIN','SECRETAIRE','FORMATEUR']::public.user_role[]
         when 'inscriptions' then array['ADMIN','SECRETAIRE','FORMATEUR']::public.user_role[]
         when 'eleves'       then array['ADMIN','SECRETAIRE','FORMATEUR']::public.user_role[]
         when 'stock'        then array['ADMIN','GESTIONNAIRE']::public.user_role[]
         when 'depenses'     then array['ADMIN']::public.user_role[]
         when 'financier'    then array['ADMIN']::public.user_role[]
         else array[]::public.user_role[] end) then
    raise exception 'Accès refusé : rapport indisponible pour votre rôle' using errcode = '42501';
  end if;

  if p_type = 'caisse' then
    v_title := 'Rapport de caisse';
    v_cols := '[{"key":"date","label":"Date","type":"datetime"},{"key":"sens","label":"Sens","type":"text"},{"key":"categorie","label":"Catégorie","type":"text"},{"key":"description","label":"Description","type":"text"},{"key":"mode","label":"Mode","type":"text"},{"key":"montant","label":"Montant","type":"money"},{"key":"statut","label":"Statut","type":"status"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.sort desc), '[]'::jsonb), count(*) into v_rows, v_count
      from (select t.occurred_at as sort,
                   t.occurred_at as date,
                   case t.direction when 'IN' then 'Entrée' else 'Sortie' end as sens,
                   t.category::text as categorie, t.description, t.method::text as mode,
                   t.amount as montant, t.status::text as statut
              from public.cash_transactions t
             where (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
             order by t.occurred_at desc limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Entrées','type','money','value', coalesce(sum(amount) filter (where direction='IN'),0)),
        jsonb_build_object('label','Sorties','type','money','value', coalesce(sum(amount) filter (where direction='OUT'),0)),
        jsonb_build_object('label','Solde de la période','type','money','value',
          coalesce(sum(amount) filter (where direction='IN'),0) - coalesce(sum(amount) filter (where direction='OUT'),0)),
        jsonb_build_object('label','Espèces en caisse (actuel)','type','money','value',
          (select cash_on_hand from public.v_cash_balance)))
      from public.cash_transactions t
     where t.status = 'VALIDE' and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to));

  elsif p_type = 'ventes' then
    v_title := 'Rapport des ventes';
    v_cols := '[{"key":"numero","label":"N°","type":"text"},{"key":"date","label":"Date","type":"datetime"},{"key":"client","label":"Client","type":"text"},{"key":"total","label":"Total","type":"money"},{"key":"paye","label":"Payé","type":"money"},{"key":"solde","label":"Solde","type":"money"},{"key":"mode","label":"Mode","type":"text"},{"key":"statut","label":"Statut","type":"status"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.sort desc), '[]'::jsonb), count(*) into v_rows, v_count
      from (select s.sale_date as sort, s.sale_number as numero, s.sale_date as date,
                   coalesce(c.name, 'Client comptoir') as client, s.total, s.amount_paid as paye,
                   s.balance as solde, s.payment_method::text as mode, s.status::text as statut
              from public.sales s left join public.customers c on c.id = s.customer_id
             where (v_from is null or s.sale_date >= v_from) and (v_to is null or s.sale_date < v_to)
             order by s.sale_date desc limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Ventes valides','type','int','value', count(*) filter (where status='VALIDE')),
        jsonb_build_object('label','Total des ventes','type','money','value', coalesce(sum(total) filter (where status='VALIDE'),0)),
        jsonb_build_object('label','Total encaissé','type','money','value', coalesce(sum(amount_paid) filter (where status='VALIDE'),0)),
        jsonb_build_object('label','Soldes à recevoir','type','money','value', coalesce(sum(balance) filter (where status='VALIDE'),0)),
        jsonb_build_object('label','Ventes annulées','type','int','value', count(*) filter (where status='ANNULE')))
      from public.sales s
     where (v_from is null or s.sale_date >= v_from) and (v_to is null or s.sale_date < v_to));

  elsif p_type = 'paiements' then
    v_title := 'Rapport des paiements';
    v_cols := '[{"key":"numero","label":"N°","type":"text"},{"key":"date","label":"Date","type":"datetime"},{"key":"type","label":"Type","type":"text"},{"key":"payeur","label":"Payeur","type":"text"},{"key":"montant","label":"Montant","type":"money"},{"key":"mode","label":"Mode","type":"text"},{"key":"reference","label":"Référence","type":"text"},{"key":"statut","label":"Statut","type":"status"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.sort desc), '[]'::jsonb), count(*) into v_rows, v_count
      from (select p.paid_at as sort, p.payment_number as numero, p.paid_at as date,
                   case p.kind when 'INSCRIPTION' then 'Formation' when 'VENTE' then 'Vente' else 'Service' end as type,
                   coalesce(st.first_name || ' ' || st.last_name, cu.name, cs.name, 'Client comptoir') as payeur,
                   p.amount as montant, p.method::text as mode, p.reference as reference, p.status::text as statut
              from public.payments p
              left join public.enrollments e on e.id = p.enrollment_id
              left join public.students st on st.id = e.student_id
              left join public.sales sa on sa.id = p.sale_id
              left join public.customers cu on cu.id = sa.customer_id
              left join public.service_orders so on so.id = p.service_order_id
              left join public.customers cs on cs.id = so.customer_id
             where (v_from is null or p.paid_at >= v_from) and (v_to is null or p.paid_at < v_to)
             order by p.paid_at desc limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Paiements valides','type','int','value', count(*) filter (where status='VALIDE')),
        jsonb_build_object('label','Total encaissé','type','money','value', coalesce(sum(amount) filter (where status='VALIDE'),0)),
        jsonb_build_object('label','dont formations','type','money','value', coalesce(sum(amount) filter (where status='VALIDE' and kind='INSCRIPTION'),0)),
        jsonb_build_object('label','dont ventes','type','money','value', coalesce(sum(amount) filter (where status='VALIDE' and kind='VENTE'),0)),
        jsonb_build_object('label','dont services','type','money','value', coalesce(sum(amount) filter (where status='VALIDE' and kind='SERVICE'),0)),
        jsonb_build_object('label','Paiements annulés','type','int','value', count(*) filter (where status='ANNULE')))
      from public.payments p
     where (v_from is null or p.paid_at >= v_from) and (v_to is null or p.paid_at < v_to));

  elsif p_type = 'formations' then
    v_title := 'Rapport des formations';
    v_cols := '[{"key":"formation","label":"Formation","type":"text"},{"key":"formateur","label":"Formateur","type":"text"},{"key":"statut","label":"Statut","type":"status"},{"key":"prix","label":"Prix","type":"money"},{"key":"inscrits","label":"Inscriptions (période)","type":"int"},{"key":"du","label":"Total dû","type":"money"},{"key":"paye","label":"Total payé","type":"money"},{"key":"solde","label":"Solde","type":"money"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.formation), '[]'::jsonb), count(*) into v_rows, v_count
      from (select t.name as formation, coalesce(pr.full_name, '—') as formateur, t.status::text as statut,
                   t.price as prix,
                   count(e.id) as inscrits,
                   coalesce(sum(e.total_due), 0) as du,
                   coalesce(sum(e.amount_paid), 0) as paye,
                   coalesce(sum(e.balance), 0) as solde
              from public.trainings t
              left join public.profiles pr on pr.id = t.trainer_id
              left join public.enrollments e on e.training_id = t.id and e.status <> 'ANNULEE'
                   and (p_from is null or e.enrolled_on >= p_from) and (p_to is null or e.enrolled_on <= p_to)
             where not t.is_archived
             group by t.id, pr.full_name
             order by t.name limit c_max + 1) r;
    v_sum := jsonb_build_array(
      jsonb_build_object('label','Formations','type','int','value', v_count),
      jsonb_build_object('label','Inscriptions (période)','type','int','value', (select coalesce(sum((x->>'inscrits')::int),0) from jsonb_array_elements(v_rows) x)),
      jsonb_build_object('label','Total payé','type','money','value', (select coalesce(sum((x->>'paye')::numeric),0) from jsonb_array_elements(v_rows) x)),
      jsonb_build_object('label','Solde à recevoir','type','money','value', (select coalesce(sum((x->>'solde')::numeric),0) from jsonb_array_elements(v_rows) x)));

  elsif p_type = 'inscriptions' then
    v_title := 'Rapport des inscriptions';
    v_cols := '[{"key":"numero","label":"N°","type":"text"},{"key":"date","label":"Date","type":"date"},{"key":"eleve","label":"Élève","type":"text"},{"key":"formation","label":"Formation","type":"text"},{"key":"du","label":"Total dû","type":"money"},{"key":"paye","label":"Payé","type":"money"},{"key":"solde","label":"Solde","type":"money"},{"key":"statut","label":"Statut","type":"status"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.date desc, r.numero), '[]'::jsonb), count(*) into v_rows, v_count
      from (select e.enrollment_number as numero, e.enrolled_on as date,
                   s.first_name || ' ' || s.last_name as eleve, t.name as formation,
                   e.total_due as du, e.amount_paid as paye, e.balance as solde, e.status::text as statut
              from public.enrollments e
              join public.students s on s.id = e.student_id
              join public.trainings t on t.id = e.training_id
             where (p_from is null or e.enrolled_on >= p_from) and (p_to is null or e.enrolled_on <= p_to)
             order by e.enrolled_on desc, e.enrollment_number limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Inscriptions','type','int','value', count(*) filter (where status <> 'ANNULEE')),
        jsonb_build_object('label','Total dû','type','money','value', coalesce(sum(total_due) filter (where status <> 'ANNULEE'),0)),
        jsonb_build_object('label','Total payé','type','money','value', coalesce(sum(amount_paid) filter (where status <> 'ANNULEE'),0)),
        jsonb_build_object('label','Solde à recevoir','type','money','value', coalesce(sum(balance) filter (where status <> 'ANNULEE'),0)),
        jsonb_build_object('label','Inscriptions annulées','type','int','value', count(*) filter (where status = 'ANNULEE')))
      from public.enrollments e
     where (p_from is null or e.enrolled_on >= p_from) and (p_to is null or e.enrolled_on <= p_to));

  elsif p_type = 'eleves' then
    v_title := 'Rapport des élèves';
    v_cols := '[{"key":"code","label":"Code","type":"text"},{"key":"nom","label":"Nom","type":"text"},{"key":"telephone","label":"Téléphone","type":"text"},{"key":"date","label":"Inscrit le","type":"date"},{"key":"statut","label":"Statut","type":"status"},{"key":"formations","label":"Formations","type":"int"},{"key":"solde","label":"Solde","type":"money"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.nom), '[]'::jsonb), count(*) into v_rows, v_count
      from (select s.student_code as code, s.last_name || ' ' || s.first_name as nom, s.phone as telephone,
                   s.enrolled_on as date, s.status::text as statut,
                   (select count(*) from public.enrollments e where e.student_id = s.id and e.status <> 'ANNULEE') as formations,
                   coalesce((select b.balance from public.v_student_balances b where b.student_id = s.id), 0) as solde
              from public.students s
             where not s.is_archived
               and (p_from is null or s.enrolled_on >= p_from) and (p_to is null or s.enrolled_on <= p_to)
             order by s.last_name, s.first_name limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Élèves','type','int','value', count(*)),
        jsonb_build_object('label','Actifs','type','int','value', count(*) filter (where status = 'ACTIF'))
      ) from public.students s
       where not s.is_archived and (p_from is null or s.enrolled_on >= p_from) and (p_to is null or s.enrolled_on <= p_to));

  elsif p_type = 'stock' then
    v_title := 'Rapport de stock';
    v_cols := '[{"key":"code","label":"Code","type":"text"},{"key":"produit","label":"Produit","type":"text"},{"key":"categorie","label":"Catégorie","type":"text"},{"key":"stock","label":"Stock","type":"int"},{"key":"minimum","label":"Minimum","type":"int"},{"key":"etat","label":"État","type":"status"},{"key":"entrees","label":"Entrées (période)","type":"int"},{"key":"sorties","label":"Sorties (période)","type":"int"},{"key":"valeur","label":"Valeur (achat)","type":"money"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.produit), '[]'::jsonb), count(*) into v_rows, v_count
      from (select p.code, p.name as produit, coalesce(pc.name, '—') as categorie,
                   p.current_stock as stock, p.min_stock as minimum, p.stock_state as etat,
                   coalesce(m.entrees, 0) as entrees, coalesce(m.sorties, 0) as sorties,
                   p.current_stock * p.purchase_price as valeur
              from public.products p
              left join public.product_categories pc on pc.id = p.category_id
              left join lateral (
                select sum(quantity_change) filter (where quantity_change > 0) as entrees,
                       -sum(quantity_change) filter (where quantity_change < 0) as sorties
                  from public.stock_movements sm
                 where sm.product_id = p.id
                   and (v_from is null or sm.created_at >= v_from) and (v_to is null or sm.created_at < v_to)) m on true
             where p.status = 'ACTIF'
             order by p.name limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Produits actifs','type','int','value', count(*)),
        jsonb_build_object('label','Stock faible','type','int','value', count(*) filter (where stock_state = 'FAIBLE')),
        jsonb_build_object('label','En rupture','type','int','value', count(*) filter (where stock_state = 'RUPTURE')),
        jsonb_build_object('label','Valeur du stock (prix d''achat)','type','money','value', coalesce(sum(current_stock * purchase_price),0)),
        jsonb_build_object('label','Valeur du stock (prix de vente)','type','money','value', coalesce(sum(current_stock * sale_price),0)))
      from public.products where status = 'ACTIF');

  elsif p_type = 'depenses' then
    v_title := 'Rapport des dépenses';
    v_cols := '[{"key":"numero","label":"N°","type":"text"},{"key":"date","label":"Date","type":"date"},{"key":"categorie","label":"Catégorie","type":"text"},{"key":"description","label":"Description","type":"text"},{"key":"mode","label":"Mode","type":"text"},{"key":"montant","label":"Montant","type":"money"},{"key":"statut","label":"Statut","type":"status"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.date desc, r.numero), '[]'::jsonb), count(*) into v_rows, v_count
      from (select e.expense_number as numero, e.expense_date as date, c.name as categorie, e.description,
                   e.method::text as mode, e.amount as montant, e.status::text as statut
              from public.expenses e join public.expense_categories c on c.id = e.category_id
             where (p_from is null or e.expense_date >= p_from) and (p_to is null or e.expense_date <= p_to)
             order by e.expense_date desc, e.expense_number limit c_max + 1) r;
    v_sum := jsonb_build_array(
      jsonb_build_object('label','Dépenses valides','type','int','value',
        (select count(*) from public.expenses e where e.status='VALIDE' and (p_from is null or e.expense_date >= p_from) and (p_to is null or e.expense_date <= p_to))),
      jsonb_build_object('label','Total des dépenses','type','money','value',
        (select coalesce(sum(amount),0) from public.expenses e where e.status='VALIDE' and (p_from is null or e.expense_date >= p_from) and (p_to is null or e.expense_date <= p_to))),
      jsonb_build_object('label','dont en espèces','type','money','value',
        (select coalesce(sum(amount),0) from public.expenses e where e.status='VALIDE' and e.method='ESPECES' and (p_from is null or e.expense_date >= p_from) and (p_to is null or e.expense_date <= p_to))));

  elsif p_type = 'financier' then
    v_title := 'Rapport financier';
    v_cols := '[{"key":"mois","label":"Mois","type":"text"},{"key":"recettes","label":"Recettes","type":"money"},{"key":"depenses","label":"Dépenses","type":"money"},{"key":"solde","label":"Solde","type":"money"}]';
    select coalesce(jsonb_agg(to_jsonb(r) order by r.mois), '[]'::jsonb), count(*) into v_rows, v_count
      from (select to_char(t.occurred_at at time zone 'America/Port-au-Prince', 'YYYY-MM') as mois,
                   coalesce(sum(t.amount) filter (where t.direction = 'IN'), 0) as recettes,
                   coalesce(sum(t.amount) filter (where t.direction = 'OUT'), 0) as depenses,
                   coalesce(sum(t.amount) filter (where t.direction = 'IN'), 0)
                     - coalesce(sum(t.amount) filter (where t.direction = 'OUT'), 0) as solde
              from public.cash_transactions t
             where t.status = 'VALIDE' and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
             group by 1 order by 1 limit c_max + 1) r;
    v_sum := (select jsonb_build_array(
        jsonb_build_object('label','Recettes','type','money','value', coalesce(sum(amount) filter (where direction='IN'),0)),
        jsonb_build_object('label','Dépenses','type','money','value', coalesce(sum(amount) filter (where direction='OUT'),0)),
        jsonb_build_object('label','Solde (recettes − dépenses)','type','money','value',
          coalesce(sum(amount) filter (where direction='IN'),0) - coalesce(sum(amount) filter (where direction='OUT'),0)),
        jsonb_build_object('label','Créances (toutes périodes)','type','money','value',
          (select coalesce(sum(balance),0) from public.enrollments where status <> 'ANNULEE')
          + (select coalesce(sum(balance),0) from public.sales where status = 'VALIDE')
          + (select coalesce(sum(balance),0) from public.service_orders where status <> 'ANNULE')),
        jsonb_build_object('label','Dettes fournisseurs (toutes périodes)','type','money','value',
          (select coalesce(sum(balance),0) from public.purchases where status = 'VALIDE')))
      from public.cash_transactions t
     where t.status = 'VALIDE' and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to));

  else
    raise exception 'Type de rapport inconnu';
  end if;

  -- Retire la colonne technique de tri et applique le plafond de lignes
  if v_count > c_max then
    v_rows := (select coalesce(jsonb_agg(x), '[]'::jsonb) from (select x from jsonb_array_elements(v_rows) with ordinality t(x, n) order by n limit c_max) q);
  end if;
  v_rows := (select coalesce(jsonb_agg(x - 'sort' order by n), '[]'::jsonb) from jsonb_array_elements(v_rows) with ordinality t(x, n));

  return jsonb_build_object(
    'type', p_type, 'title', v_title,
    'period', jsonb_build_object('from', p_from, 'to', p_to),
    'columns', v_cols, 'rows', v_rows, 'summary', v_sum, 'truncated', v_count > c_max);
end $$;

revoke all on function public.report_data(text, date, date) from public, anon;
grant execute on function public.report_data(text, date, date) to authenticated;
