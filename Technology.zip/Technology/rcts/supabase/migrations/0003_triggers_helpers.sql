-- PHASE 2 — Fonctions internes (schéma private) et triggers d'intégrité

-- ---------------------------------------------------------------------------
-- Helpers de rôle
-- ---------------------------------------------------------------------------
create function private.has_role(variadic p_roles public.user_role[])
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(public.current_role() = any (p_roles), false)
$$;
grant execute on function private.has_role(public.user_role[]) to authenticated;

create function private.require_role(variadic p_roles public.user_role[])
returns void
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not private.has_role(variadic p_roles) then
    raise exception 'Accès refusé : permission insuffisante' using errcode = '42501';
  end if;
end $$;

-- Formateur assigné à une formation / à un élève (utilisé par la RLS)
create function private.is_trainer_of_training(p_training_id uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from public.trainings t
                  where t.id = p_training_id and t.trainer_id = auth.uid())
$$;
grant execute on function private.is_trainer_of_training(uuid) to authenticated;

create function private.is_trainer_of_student(p_student_id uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1
                   from public.enrollments e
                   join public.trainings t on t.id = e.training_id
                  where e.student_id = p_student_id and t.trainer_id = auth.uid())
$$;
grant execute on function private.is_trainer_of_student(uuid) to authenticated;

-- ---------------------------------------------------------------------------
-- Paramètres et numérotation
-- ---------------------------------------------------------------------------
create function private.setting_text(p_key text, p_default text)
returns text
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce((select value #>> '{}' from public.settings where key = p_key), p_default)
$$;

-- Numéro unique sans trou : PREFIXE-ANNEE-000001 (compteur annuel, verrou de ligne)
create function private.next_number(p_key text, p_prefix text)
returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_year int := extract(year from (now() at time zone 'America/Port-au-Prince'))::int;
  v_val  bigint;
begin
  insert into public.counters as c (key, year, value)
  values (p_key, v_year, 1)
  on conflict (key, year) do update set value = c.value + 1
  returning value into v_val;
  return p_prefix || '-' || v_year || '-' || lpad(v_val::text, 6, '0');
end $$;

-- Trigger : attribue un numéro si la colonne est vide. Args : colonne, clé, préfixe
create function private.assign_number()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if to_jsonb(new) ->> tg_argv[0] is null then
    new := jsonb_populate_record(
      new, jsonb_build_object(tg_argv[0], private.next_number(tg_argv[1], tg_argv[2])));
  end if;
  return new;
end $$;

create function private.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Solde de caisse physique (espèces) et verrou pour éviter les doubles sorties
create function private.cash_on_hand()
returns numeric
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(sum(case when direction = 'IN' then amount else -amount end), 0)
    from public.cash_transactions
   where status = 'VALIDE' and method = 'ESPECES'
$$;

create function private.lock_cash()
returns void language sql as $$ select pg_advisory_xact_lock(7734001) $$;

-- ---------------------------------------------------------------------------
-- Triggers updated_at
-- ---------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['profiles','students','trainings','enrollments','customers','suppliers',
                           'services','service_orders','products','sales','expenses']
  loop
    execute format('create trigger %I before update on public.%I
                    for each row execute function private.set_updated_at()', t || '_updated_at', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Numéros automatiques pour les insertions directes (élèves, produits, certificats)
-- ---------------------------------------------------------------------------
create trigger students_number before insert on public.students
  for each row execute function private.assign_number('student_code', 'student', 'STU');
create trigger products_code before insert on public.products
  for each row execute function private.assign_number('code', 'product', 'PRD');
create trigger certificates_number before insert on public.certificates
  for each row execute function private.assign_number('certificate_number', 'certificate', 'CERT');

-- ---------------------------------------------------------------------------
-- Formateur : doit être un FORMATEUR (ou un ADMIN)
-- ---------------------------------------------------------------------------
create function private.check_trainer()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.trainer_id is not null and not exists (
       select 1 from public.profiles p
        where p.id = new.trainer_id and p.role in ('FORMATEUR','ADMIN') and p.is_active) then
    raise exception 'Le formateur sélectionné doit être un utilisateur actif de rôle FORMATEUR';
  end if;
  return new;
end $$;
create trigger trainings_check_trainer before insert or update of trainer_id on public.trainings
  for each row execute function private.check_trainer();

-- ---------------------------------------------------------------------------
-- Totaux payés : recalculés depuis les paiements VALIDES (source de vérité)
-- ---------------------------------------------------------------------------
create function private.refresh_paid_totals()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.enrollment_id is not null then
    update public.enrollments
       set amount_paid = (select coalesce(sum(amount), 0) from public.payments
                           where enrollment_id = new.enrollment_id and status = 'VALIDE')
     where id = new.enrollment_id;
  elsif new.sale_id is not null then
    update public.sales
       set amount_paid = (select coalesce(sum(amount), 0) from public.payments
                           where sale_id = new.sale_id and status = 'VALIDE')
     where id = new.sale_id;
  elsif new.service_order_id is not null then
    update public.service_orders
       set amount_paid = (select coalesce(sum(amount), 0) from public.payments
                           where service_order_id = new.service_order_id and status = 'VALIDE')
     where id = new.service_order_id;
  end if;
  return null;
end $$;
create trigger payments_refresh_totals after insert or update on public.payments
  for each row execute function private.refresh_paid_totals();

create function private.refresh_supplier_paid()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update public.purchases
     set amount_paid = (select coalesce(sum(amount), 0) from public.supplier_payments
                         where purchase_id = new.purchase_id and status = 'VALIDE')
   where id = new.purchase_id;
  return null;
end $$;
create trigger supplier_payments_refresh after insert or update on public.supplier_payments
  for each row execute function private.refresh_supplier_paid();

-- Impossible d'annuler une inscription / commande qui a des paiements valides
create function private.guard_cancel()
returns trigger language plpgsql as $$
begin
  if new.status::text in ('ANNULEE','ANNULE') and old.status::text not in ('ANNULEE','ANNULE')
     and new.amount_paid > 0 then
    raise exception 'Annulez d''abord les paiements associés avant d''annuler cet enregistrement';
  end if;
  return new;
end $$;
create trigger enrollments_guard_cancel before update on public.enrollments
  for each row execute function private.guard_cancel();
create trigger service_orders_guard_cancel before update on public.service_orders
  for each row execute function private.guard_cancel();

-- ---------------------------------------------------------------------------
-- Stock : seul point de modification de products.current_stock
-- ---------------------------------------------------------------------------
create function private.apply_stock_movement()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_product public.products;
begin
  select * into v_product from public.products where id = new.product_id for update;
  if not found then
    raise exception 'Produit introuvable';
  end if;

  new.stock_before := v_product.current_stock;
  new.stock_after  := v_product.current_stock + new.quantity_change;

  if new.stock_after < 0 then
    raise exception 'Stock insuffisant pour « % » (disponible : %, demandé : %)',
      v_product.name, v_product.current_stock, -new.quantity_change
      using errcode = 'P0001';
  end if;

  update public.products set current_stock = new.stock_after where id = new.product_id;
  return new;
end $$;
create trigger stock_movements_apply before insert on public.stock_movements
  for each row execute function private.apply_stock_movement();

-- ---------------------------------------------------------------------------
-- Immuabilité des données financières
-- ---------------------------------------------------------------------------
create function private.protect_payment()
returns trigger language plpgsql as $$
begin
  if (new.id, new.payment_number, new.kind, new.student_id, new.customer_id, new.enrollment_id,
      new.sale_id, new.service_order_id, new.amount, new.method, new.reference, new.description,
      new.paid_at, new.created_by)
     is distinct from
     (old.id, old.payment_number, old.kind, old.student_id, old.customer_id, old.enrollment_id,
      old.sale_id, old.service_order_id, old.amount, old.method, old.reference, old.description,
      old.paid_at, old.created_by) then
    raise exception 'Un paiement enregistré ne peut pas être modifié : annulez-le puis ressaisissez-le';
  end if;
  if old.status = 'ANNULE' and new.status = 'VALIDE' then
    raise exception 'Un paiement annulé ne peut pas être réactivé';
  end if;
  return new;
end $$;
create trigger payments_protect before update on public.payments
  for each row execute function private.protect_payment();

create function private.protect_cash_transaction()
returns trigger language plpgsql as $$
begin
  if (new.id, new.direction, new.category, new.amount, new.method, new.description,
      new.occurred_at, new.source_type, new.source_id, new.created_by)
     is distinct from
     (old.id, old.direction, old.category, old.amount, old.method, old.description,
      old.occurred_at, old.source_type, old.source_id, old.created_by) then
    raise exception 'Une transaction de caisse ne peut pas être modifiée';
  end if;
  if old.status = 'ANNULE' and new.status = 'VALIDE' then
    raise exception 'Une transaction annulée ne peut pas être réactivée';
  end if;
  return new;
end $$;
create trigger cash_transactions_protect before update on public.cash_transactions
  for each row execute function private.protect_cash_transaction();

create function private.forbid_delete()
returns trigger language plpgsql as $$
begin
  raise exception 'Suppression interdite sur % : utilisez l''annulation ou l''archivage', tg_table_name
    using errcode = '42501';
end $$;

create function private.forbid_change()
returns trigger language plpgsql as $$
begin
  raise exception 'Le journal d''audit est immuable' using errcode = '42501';
end $$;

do $$
declare t text;
begin
  foreach t in array array['payments','cash_transactions','receipts','invoices','sales','sale_items',
                           'expenses','stock_movements','purchases','purchase_items',
                           'supplier_payments','enrollments','audit_logs']
  loop
    execute format('create trigger %I before delete on public.%I
                    for each row execute function private.forbid_delete()', t || '_no_delete', t);
  end loop;
end $$;

create trigger audit_logs_no_update before update on public.audit_logs
  for each row execute function private.forbid_change();

-- ---------------------------------------------------------------------------
-- Audit : qui a fait quoi, avec ancienne et nouvelle valeur
-- ---------------------------------------------------------------------------
create function private.audit_row()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_old jsonb;
  v_new jsonb;
  v_row jsonb;
begin
  if tg_op = 'DELETE' then
    v_old := to_jsonb(old);
    v_row := v_old;
  elsif tg_op = 'UPDATE' then
    v_old := to_jsonb(old);
    v_new := to_jsonb(new);
    if v_old - 'updated_at' = v_new - 'updated_at' then
      return null;                       -- aucun changement réel
    end if;
    v_row := v_new;
  else
    v_new := to_jsonb(new);
    v_row := v_new;
  end if;

  insert into public.audit_logs (user_id, user_email, action, module, record_id, old_value, new_value)
  values (auth.uid(),
          (select email from public.profiles where id = auth.uid()),
          tg_op,
          tg_table_name,
          coalesce(v_row ->> 'id', v_row ->> 'key', v_row ->> 'role'),
          v_old,
          v_new);
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','students','trainings','enrollments','certificates','payments',
                           'receipts','invoices','customers','suppliers','services','service_orders',
                           'products','stock_movements','sales','expenses','cash_transactions',
                           'purchases','supplier_payments','settings','users_roles',
                           'product_categories','expense_categories']
  loop
    execute format('create trigger %I after insert or update or delete on public.%I
                    for each row execute function private.audit_row()', t || '_audit', t);
  end loop;
end $$;
