-- PHASE 2 — Fonctions transactionnelles
-- Chaque fonction s'exécute dans UNE transaction : en cas d'erreur, rien n'est enregistré.
-- Les écritures financières ne passent QUE par ces fonctions (aucun INSERT direct autorisé).

-- ===========================================================================
-- Fonctions internes
-- ===========================================================================

-- Encaisse un paiement : paiement + transaction de caisse + reçu (+ mise à jour du solde par trigger)
create function private.post_payment(
  p_kind        public.payment_kind,
  p_target      uuid,
  p_amount      numeric,
  p_method      public.payment_method,
  p_reference   text,
  p_description text
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_uid     uuid := auth.uid();
  v_amount  numeric := round(p_amount, 2);
  v_total   numeric;
  v_paid    numeric;
  v_student uuid;
  v_customer uuid;
  v_name    text;
  v_desc    text;
  v_cat     public.cash_category;
  v_e       public.enrollments;
  v_s       public.sales;
  v_o       public.service_orders;
  v_pay     public.payments;
  v_rec     public.receipts;
begin
  if v_amount is null or v_amount <= 0 then
    raise exception 'Le montant doit être supérieur à zéro';
  end if;

  if p_kind = 'INSCRIPTION' then
    select * into v_e from public.enrollments where id = p_target for update;
    if not found then raise exception 'Inscription introuvable'; end if;
    if v_e.status = 'ANNULEE' then raise exception 'Cette inscription est annulée'; end if;
    v_total := v_e.total_due; v_paid := v_e.amount_paid; v_student := v_e.student_id;
    select trim(s.first_name || ' ' || s.last_name) into v_name from public.students s where s.id = v_e.student_id;
    select 'Formation : ' || t.name into v_desc from public.trainings t where t.id = v_e.training_id;
    v_cat := 'FORMATION';

  elsif p_kind = 'VENTE' then
    select * into v_s from public.sales where id = p_target for update;
    if not found then raise exception 'Vente introuvable'; end if;
    if v_s.status <> 'VALIDE' then raise exception 'Cette vente est annulée'; end if;
    v_total := v_s.total; v_paid := v_s.amount_paid; v_customer := v_s.customer_id;
    select c.name into v_name from public.customers c where c.id = v_s.customer_id;
    v_name := coalesce(v_name, 'Client comptoir');
    v_desc := 'Vente ' || v_s.sale_number;
    v_cat := 'VENTE';

  elsif p_kind = 'SERVICE' then
    select * into v_o from public.service_orders where id = p_target for update;
    if not found then raise exception 'Commande de service introuvable'; end if;
    if v_o.status = 'ANNULE' then raise exception 'Cette commande est annulée'; end if;
    v_total := v_o.total; v_paid := v_o.amount_paid; v_customer := v_o.customer_id;
    select c.name into v_name from public.customers c where c.id = v_o.customer_id;
    select 'Service : ' || sv.name || ' (' || v_o.order_number || ')' into v_desc
      from public.services sv where sv.id = v_o.service_id;
    v_cat := 'SERVICE';
  end if;

  if v_amount > v_total - v_paid then
    raise exception 'Le montant (%) dépasse le solde restant (%)', v_amount, v_total - v_paid;
  end if;

  insert into public.payments (payment_number, kind, student_id, customer_id, enrollment_id, sale_id,
                               service_order_id, amount, method, reference, description, created_by)
  values (private.next_number('payment', 'PAY'), p_kind, v_student, v_customer,
          v_e.id, v_s.id, v_o.id, v_amount, p_method, p_reference,
          coalesce(p_description, v_desc), v_uid)
  returning * into v_pay;

  insert into public.cash_transactions (direction, category, amount, method, description,
                                        source_type, source_id, created_by)
  values ('IN', v_cat, v_amount, p_method, coalesce(p_description, v_desc) || ' — ' || v_name,
          'PAYMENT', v_pay.id, v_uid);

  insert into public.receipts (receipt_number, payment_id, issued_by, payer_name, description,
                               amount, method, total_due, balance_after)
  values (private.next_number('receipt', private.setting_text('receipt_prefix', 'RCTS')),
          v_pay.id, v_uid, v_name, coalesce(p_description, v_desc), v_amount, p_method,
          v_total, v_total - v_paid - v_amount)
  returning * into v_rec;

  return jsonb_build_object(
    'payment_id',     v_pay.id,
    'payment_number', v_pay.payment_number,
    'receipt_id',     v_rec.id,
    'receipt_number', v_rec.receipt_number,
    'amount',         v_amount,
    'balance',        v_total - v_paid - v_amount);
end $$;

-- Annule un paiement (+ transaction de caisse + reçu). Le solde est recalculé par trigger.
create function private.void_payment_core(p_payment_id uuid, p_reason text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_p public.payments;
begin
  select * into v_p from public.payments where id = p_payment_id for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if v_p.status = 'ANNULE' then raise exception 'Ce paiement est déjà annulé'; end if;

  update public.payments
     set status = 'ANNULE', voided_at = now(), voided_by = auth.uid(), void_reason = p_reason
   where id = p_payment_id;
  update public.cash_transactions
     set status = 'ANNULE', voided_at = now()
   where source_type = 'PAYMENT' and source_id = p_payment_id;
  update public.receipts set status = 'ANNULE' where payment_id = p_payment_id;
end $$;

-- Paiement fournisseur : sortie de caisse (contrôle du solde si espèces)
create function private.post_supplier_payment(
  p_purchase  uuid,
  p_amount    numeric,
  p_method    public.payment_method,
  p_reference text
) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_amount numeric := round(p_amount, 2);
  v_pu     public.purchases;
  v_sp     public.supplier_payments;
  v_name   text;
begin
  if v_amount is null or v_amount <= 0 then
    raise exception 'Le montant doit être supérieur à zéro';
  end if;

  select * into v_pu from public.purchases where id = p_purchase for update;
  if not found then raise exception 'Achat introuvable'; end if;
  if v_pu.status <> 'VALIDE' then raise exception 'Cet achat est annulé'; end if;
  if v_amount > v_pu.balance then
    raise exception 'Le montant (%) dépasse le montant dû (%)', v_amount, v_pu.balance;
  end if;

  if p_method = 'ESPECES' then
    perform private.lock_cash();
    if private.cash_on_hand() < v_amount then
      raise exception 'Solde de caisse insuffisant (disponible : %)', private.cash_on_hand();
    end if;
  end if;

  insert into public.supplier_payments (payment_number, purchase_id, supplier_id, amount, method, reference)
  values (private.next_number('supplier_payment', 'PFO'), p_purchase, v_pu.supplier_id,
          v_amount, p_method, p_reference)
  returning * into v_sp;

  select name into v_name from public.suppliers where id = v_pu.supplier_id;
  insert into public.cash_transactions (direction, category, amount, method, description,
                                        source_type, source_id)
  values ('OUT', 'ACHAT_FOURNISSEUR', v_amount, p_method,
          'Paiement fournisseur ' || coalesce(v_name, '') || ' — ' || v_pu.purchase_number,
          'SUPPLIER_PAYMENT', v_sp.id);
  return v_sp.id;
end $$;

-- ===========================================================================
-- Fonctions publiques (appelées via supabase.rpc)
-- ===========================================================================

-- Inscription d'un élève (+ paiement initial optionnel → reçu)
create function public.enroll_student(
  p_student_id  uuid,
  p_training_id uuid,
  p_discount    numeric default 0,
  p_amount_paid numeric default 0,
  p_method      public.payment_method default 'ESPECES',
  p_reference   text default null,
  p_notes       text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_t     public.trainings;
  v_s     public.students;
  v_e     public.enrollments;
  v_count int;
  v_pay   jsonb;
begin
  perform private.require_role('ADMIN', 'SECRETAIRE', 'CAISSIER');
  p_discount := coalesce(round(p_discount, 2), 0);
  p_amount_paid := coalesce(round(p_amount_paid, 2), 0);
  if p_amount_paid > 0 then
    perform private.require_role('ADMIN', 'CAISSIER');   -- seul le caissier encaisse
  end if;
  if p_discount < 0 then raise exception 'La réduction ne peut pas être négative'; end if;

  select * into v_t from public.trainings where id = p_training_id for update;   -- verrou : capacité
  if not found then raise exception 'Formation introuvable'; end if;
  if v_t.is_archived or v_t.status in ('TERMINEE', 'ANNULEE') then
    raise exception 'Cette formation n''accepte plus d''inscriptions';
  end if;

  select * into v_s from public.students where id = p_student_id;
  if not found then raise exception 'Élève introuvable'; end if;
  if v_s.is_archived or v_s.status = 'SUSPENDU' then
    raise exception 'Cet élève est archivé ou suspendu';
  end if;

  if exists (select 1 from public.enrollments
              where student_id = p_student_id and training_id = p_training_id and status <> 'ANNULEE') then
    raise exception 'Cet élève est déjà inscrit à cette formation';
  end if;

  if v_t.max_students is not null then
    select count(*) into v_count from public.enrollments
     where training_id = p_training_id and status in ('ACTIVE', 'TERMINEE');
    if v_count >= v_t.max_students then
      raise exception 'Formation complète (% places)', v_t.max_students;
    end if;
  end if;

  if p_discount > v_t.price + v_t.registration_fee then
    raise exception 'La réduction dépasse le prix total de la formation';
  end if;

  insert into public.enrollments (enrollment_number, student_id, training_id, training_price,
                                  registration_fee, discount, notes, created_by)
  values (private.next_number('enrollment', 'INS'), p_student_id, p_training_id, v_t.price,
          v_t.registration_fee, p_discount, p_notes, auth.uid())
  returning * into v_e;

  update public.students set status = 'ACTIF'
   where id = p_student_id and status in ('INACTIF', 'TERMINE');

  if p_amount_paid > 0 then
    v_pay := private.post_payment('INSCRIPTION', v_e.id, p_amount_paid, p_method, p_reference, null);
  end if;

  select * into v_e from public.enrollments where id = v_e.id;
  return jsonb_build_object(
    'enrollment_id',     v_e.id,
    'enrollment_number', v_e.enrollment_number,
    'total_due',         v_e.total_due,
    'amount_paid',       v_e.amount_paid,
    'balance',           v_e.balance,
    'payment',           v_pay);
end $$;

-- Encaissement d'un paiement sur une inscription, une vente à crédit ou une commande de service
create function public.record_payment(
  p_kind        public.payment_kind,
  p_target_id   uuid,
  p_amount      numeric,
  p_method      public.payment_method default 'ESPECES',
  p_reference   text default null,
  p_description text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform private.require_role('ADMIN', 'CAISSIER');
  return private.post_payment(p_kind, p_target_id, p_amount, p_method, p_reference, p_description);
end $$;

-- Vente en caisse : vente + lignes + sortie de stock + paiement + caisse + reçu
-- p_items : [{"product_id":"…","quantity":2} | {"service_id":"…","quantity":1,"unit_price":150}]
-- Les prix des produits viennent TOUJOURS de la base ; le prix d'un service peut être précisé.
create function public.create_sale(
  p_customer_id     uuid,
  p_items           jsonb,
  p_discount        numeric default 0,
  p_amount_tendered numeric default 0,
  p_method          public.payment_method default 'ESPECES',
  p_reference       text default null,
  p_notes           text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_uid      uuid := auth.uid();
  v_it       record;
  v_product  public.products;
  v_service  public.services;
  v_price    numeric;
  v_subtotal numeric := 0;
  v_total    numeric;
  v_paid     numeric;
  v_tendered numeric := coalesce(round(p_amount_tendered, 2), 0);
  v_discount numeric := coalesce(round(p_discount, 2), 0);
  v_sale     public.sales;
  v_lines    numeric;
  v_pay      jsonb;
begin
  perform private.require_role('ADMIN', 'CAISSIER');

  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Le panier est vide';
  end if;

  -- Passe 1 : validation et sous-total
  for v_it in
    select * from jsonb_to_recordset(p_items)
      as x(product_id uuid, service_id uuid, quantity int, unit_price numeric)
  loop
    if num_nonnulls(v_it.product_id, v_it.service_id) <> 1 then
      raise exception 'Chaque ligne doit référencer un produit ou un service';
    end if;
    if coalesce(v_it.quantity, 0) <= 0 then
      raise exception 'Quantité invalide';
    end if;

    if v_it.product_id is not null then
      select * into v_product from public.products where id = v_it.product_id;
      if not found then raise exception 'Produit introuvable'; end if;
      if v_product.status <> 'ACTIF' then raise exception 'Le produit « % » est inactif', v_product.name; end if;
      v_price := v_product.sale_price;
    else
      select * into v_service from public.services where id = v_it.service_id;
      if not found then raise exception 'Service introuvable'; end if;
      if not v_service.is_active then raise exception 'Le service « % » est inactif', v_service.name; end if;
      v_price := coalesce(v_it.unit_price, v_service.unit_price);
      if v_price < 0 then raise exception 'Prix invalide'; end if;
    end if;
    v_subtotal := v_subtotal + v_price * v_it.quantity;
  end loop;

  if v_discount < 0 or v_discount > v_subtotal then
    raise exception 'Réduction invalide (maximum : %)', v_subtotal;
  end if;
  v_total := v_subtotal - v_discount;
  v_paid  := least(v_tendered, v_total);

  if v_paid < v_total and p_customer_id is null then
    raise exception 'Un client est requis pour une vente à crédit (paiement incomplet)';
  end if;
  if p_customer_id is not null
     and not exists (select 1 from public.customers where id = p_customer_id and not is_archived) then
    raise exception 'Client introuvable ou archivé';
  end if;

  insert into public.sales (sale_number, customer_id, subtotal, discount, payment_method, notes, seller_id)
  values (private.next_number('sale', 'VTE'), p_customer_id, v_subtotal, v_discount, p_method, p_notes, v_uid)
  returning * into v_sale;

  -- Passe 2 : lignes + sorties de stock (ordre stable pour limiter les verrous croisés)
  for v_it in
    select * from jsonb_to_recordset(p_items)
      as x(product_id uuid, service_id uuid, quantity int, unit_price numeric)
    order by product_id nulls last, service_id
  loop
    if v_it.product_id is not null then
      select * into v_product from public.products where id = v_it.product_id;
      insert into public.sale_items (sale_id, product_id, description, quantity, unit_price)
      values (v_sale.id, v_product.id, v_product.name, v_it.quantity, v_product.sale_price);
      insert into public.stock_movements (product_id, movement_type, quantity_change, reason,
                                          reference, source_type, source_id, created_by)
      values (v_product.id, 'VENTE', -v_it.quantity, 'Vente ' || v_sale.sale_number,
              v_sale.sale_number, 'SALE', v_sale.id, v_uid);
    else
      select * into v_service from public.services where id = v_it.service_id;
      insert into public.sale_items (sale_id, service_id, description, quantity, unit_price)
      values (v_sale.id, v_service.id, v_service.name, v_it.quantity,
              coalesce(v_it.unit_price, v_service.unit_price));
    end if;
  end loop;

  select coalesce(sum(line_total), 0) into v_lines from public.sale_items where sale_id = v_sale.id;
  if v_lines <> v_subtotal then
    raise exception 'Les prix ont changé pendant la vente, veuillez réessayer';
  end if;

  if v_paid > 0 then
    v_pay := private.post_payment('VENTE', v_sale.id, v_paid, p_method, p_reference, null);
  end if;

  select * into v_sale from public.sales where id = v_sale.id;
  return jsonb_build_object(
    'sale_id',     v_sale.id,
    'sale_number', v_sale.sale_number,
    'subtotal',    v_sale.subtotal,
    'discount',    v_sale.discount,
    'total',       v_sale.total,
    'amount_paid', v_sale.amount_paid,
    'change',      greatest(v_tendered - v_total, 0),   -- MONNAIE = MONTANT PAYÉ - TOTAL
    'balance',     v_sale.balance,
    'payment',     v_pay);
end $$;

-- Commande de service (impression, photocopie, etc.) + acompte optionnel
create function public.create_service_order(
  p_customer_id    uuid,
  p_service_id     uuid,
  p_quantity       int,
  p_unit_price     numeric default null,
  p_due_date       date default null,
  p_responsible_id uuid default null,
  p_comment        text default null,
  p_amount_paid    numeric default 0,
  p_method         public.payment_method default 'ESPECES',
  p_reference      text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_sv  public.services;
  v_o   public.service_orders;
  v_pay jsonb;
begin
  perform private.require_role('ADMIN', 'CAISSIER');

  select * into v_sv from public.services where id = p_service_id;
  if not found or not v_sv.is_active then raise exception 'Service introuvable ou inactif'; end if;
  if not exists (select 1 from public.customers where id = p_customer_id and not is_archived) then
    raise exception 'Client introuvable ou archivé';
  end if;

  insert into public.service_orders (order_number, customer_id, service_id, quantity, unit_price,
                                     due_date, responsible_id, comment, created_by)
  values (private.next_number('service_order', 'CMD'), p_customer_id, p_service_id, p_quantity,
          coalesce(p_unit_price, v_sv.unit_price), p_due_date, p_responsible_id, p_comment, auth.uid())
  returning * into v_o;

  if coalesce(p_amount_paid, 0) > 0 then
    v_pay := private.post_payment('SERVICE', v_o.id, p_amount_paid, p_method, p_reference, null);
  end if;

  select * into v_o from public.service_orders where id = v_o.id;
  return jsonb_build_object(
    'order_id',     v_o.id,
    'order_number', v_o.order_number,
    'total',        v_o.total,
    'amount_paid',  v_o.amount_paid,
    'balance',      v_o.balance,
    'payment',      v_pay);
end $$;

-- Annulation d'un paiement (ADMIN, motif obligatoire) — jamais de suppression
create function public.void_payment(p_payment_id uuid, p_reason text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  perform private.require_role('ADMIN');
  if coalesce(trim(p_reason), '') = '' then raise exception 'Le motif d''annulation est obligatoire'; end if;
  perform private.void_payment_core(p_payment_id, p_reason);
end $$;

-- Annulation d'une vente : paiements annulés, stock réintégré
create function public.void_sale(p_sale_id uuid, p_reason text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_sale public.sales;
  v_p    record;
  v_i    record;
begin
  perform private.require_role('ADMIN');
  if coalesce(trim(p_reason), '') = '' then raise exception 'Le motif d''annulation est obligatoire'; end if;

  select * into v_sale from public.sales where id = p_sale_id for update;
  if not found then raise exception 'Vente introuvable'; end if;
  if v_sale.status = 'ANNULE' then raise exception 'Cette vente est déjà annulée'; end if;

  for v_p in select id from public.payments where sale_id = p_sale_id and status = 'VALIDE' loop
    perform private.void_payment_core(v_p.id, 'Annulation de la vente : ' || p_reason);
  end loop;

  for v_i in select product_id, quantity from public.sale_items
              where sale_id = p_sale_id and product_id is not null order by product_id loop
    insert into public.stock_movements (product_id, movement_type, quantity_change, reason,
                                        reference, source_type, source_id, created_by)
    values (v_i.product_id, 'ANNULATION', v_i.quantity, 'Annulation vente ' || v_sale.sale_number,
            v_sale.sale_number, 'SALE', p_sale_id, auth.uid());
  end loop;

  update public.sales
     set status = 'ANNULE', voided_at = now(), voided_by = auth.uid(), void_reason = p_reason
   where id = p_sale_id;
end $$;

-- Dépense (sortie de caisse). Contrôle le solde si payée en espèces.
create function public.record_expense(
  p_category_id    uuid,
  p_description    text,
  p_amount         numeric,
  p_method         public.payment_method default 'ESPECES',
  p_expense_date   date default current_date,
  p_responsible_id uuid default null,
  p_receipt_url    text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_amount numeric := round(p_amount, 2);
  v_cat    public.expense_categories;
  v_exp    public.expenses;
begin
  perform private.require_role('ADMIN');
  if v_amount is null or v_amount <= 0 then raise exception 'Le montant doit être supérieur à zéro'; end if;

  select * into v_cat from public.expense_categories where id = p_category_id;
  if not found or not v_cat.is_active then raise exception 'Catégorie de dépense introuvable ou inactive'; end if;

  if p_method = 'ESPECES' then
    perform private.lock_cash();
    if private.cash_on_hand() < v_amount then
      raise exception 'Solde de caisse insuffisant (disponible : %)', private.cash_on_hand();
    end if;
  end if;

  insert into public.expenses (expense_number, expense_date, category_id, description, amount,
                               method, responsible_id, receipt_url, created_by)
  values (private.next_number('expense', 'DEP'), p_expense_date, p_category_id, p_description,
          v_amount, p_method, coalesce(p_responsible_id, auth.uid()), p_receipt_url, auth.uid())
  returning * into v_exp;

  insert into public.cash_transactions (direction, category, amount, method, description,
                                        source_type, source_id)
  values ('OUT', 'DEPENSE', v_amount, p_method, v_cat.name || ' — ' || p_description, 'EXPENSE', v_exp.id);

  return jsonb_build_object('expense_id', v_exp.id, 'expense_number', v_exp.expense_number,
                            'amount', v_amount, 'cash_on_hand', private.cash_on_hand());
end $$;

create function public.void_expense(p_expense_id uuid, p_reason text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_e public.expenses;
begin
  perform private.require_role('ADMIN');
  if coalesce(trim(p_reason), '') = '' then raise exception 'Le motif d''annulation est obligatoire'; end if;

  select * into v_e from public.expenses where id = p_expense_id for update;
  if not found then raise exception 'Dépense introuvable'; end if;
  if v_e.status = 'ANNULE' then raise exception 'Cette dépense est déjà annulée'; end if;

  update public.expenses
     set status = 'ANNULE', voided_at = now(), voided_by = auth.uid(), void_reason = p_reason
   where id = p_expense_id;
  update public.cash_transactions set status = 'ANNULE', voided_at = now()
   where source_type = 'EXPENSE' and source_id = p_expense_id;
end $$;

-- Mouvement de stock manuel.
--   ENTREE / SORTIE : p_quantity > 0 (quantité à ajouter / retirer)
--   AJUSTEMENT      : p_quantity signé non nul (+/-)
--   INVENTAIRE      : p_quantity = quantité comptée (le système calcule l'écart)
create function public.record_stock_movement(
  p_product_id uuid,
  p_type       public.stock_movement_type,
  p_quantity   int,
  p_reason     text default null,
  p_reference  text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_cur   int;
  v_delta int;
  v_mv    public.stock_movements;
begin
  perform private.require_role('ADMIN', 'GESTIONNAIRE');
  if p_type not in ('ENTREE', 'SORTIE', 'AJUSTEMENT', 'INVENTAIRE') then
    raise exception 'Type de mouvement manuel invalide : %', p_type;
  end if;
  if p_quantity is null then raise exception 'Quantité requise'; end if;

  select current_stock into v_cur from public.products where id = p_product_id for update;
  if not found then raise exception 'Produit introuvable'; end if;

  if p_type = 'ENTREE' then
    if p_quantity <= 0 then raise exception 'La quantité d''une entrée doit être positive'; end if;
    v_delta := p_quantity;
  elsif p_type = 'SORTIE' then
    if p_quantity <= 0 then raise exception 'La quantité d''une sortie doit être positive'; end if;
    if coalesce(trim(p_reason), '') = '' then raise exception 'Le motif est obligatoire pour une sortie'; end if;
    v_delta := -p_quantity;
  elsif p_type = 'AJUSTEMENT' then
    if p_quantity = 0 then raise exception 'L''ajustement ne peut pas être nul'; end if;
    if coalesce(trim(p_reason), '') = '' then raise exception 'Le motif est obligatoire pour un ajustement'; end if;
    v_delta := p_quantity;
  else
    if p_quantity < 0 then raise exception 'La quantité comptée ne peut pas être négative'; end if;
    v_delta := p_quantity - v_cur;
  end if;

  if v_delta = 0 then
    return jsonb_build_object('changed', false, 'current_stock', v_cur);
  end if;

  insert into public.stock_movements (product_id, movement_type, quantity_change, reason,
                                      reference, source_type, created_by)
  values (p_product_id, p_type, v_delta, p_reason, p_reference, 'MANUAL', auth.uid())
  returning * into v_mv;

  return jsonb_build_object('changed', true, 'movement_id', v_mv.id,
                            'stock_before', v_mv.stock_before, 'stock_after', v_mv.stock_after);
end $$;

-- Achat fournisseur : achat + lignes + entrées de stock + paiement éventuel
-- p_items : [{"product_id":"…","quantity":10,"unit_cost":50}]
create function public.create_purchase(
  p_supplier_id uuid,
  p_items       jsonb,
  p_amount_paid numeric default 0,
  p_method      public.payment_method default 'ESPECES',
  p_reference   text default null,
  p_notes       text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_it    record;
  v_total numeric := 0;
  v_pu    public.purchases;
begin
  perform private.require_role('ADMIN', 'GESTIONNAIRE');
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'L''achat ne contient aucune ligne';
  end if;
  if not exists (select 1 from public.suppliers where id = p_supplier_id and not is_archived) then
    raise exception 'Fournisseur introuvable ou archivé';
  end if;

  for v_it in select * from jsonb_to_recordset(p_items) as x(product_id uuid, quantity int, unit_cost numeric) loop
    if v_it.product_id is null or coalesce(v_it.quantity, 0) <= 0 or coalesce(v_it.unit_cost, -1) < 0 then
      raise exception 'Ligne d''achat invalide';
    end if;
    if not exists (select 1 from public.products where id = v_it.product_id) then
      raise exception 'Produit introuvable';
    end if;
    v_total := v_total + v_it.quantity * v_it.unit_cost;
  end loop;

  if coalesce(p_amount_paid, 0) < 0 or coalesce(p_amount_paid, 0) > v_total then
    raise exception 'Le montant payé doit être compris entre 0 et %', v_total;
  end if;

  insert into public.purchases (purchase_number, supplier_id, total_amount, notes, created_by)
  values (private.next_number('purchase', 'ACH'), p_supplier_id, v_total, p_notes, auth.uid())
  returning * into v_pu;

  for v_it in select * from jsonb_to_recordset(p_items) as x(product_id uuid, quantity int, unit_cost numeric)
               order by product_id loop
    insert into public.purchase_items (purchase_id, product_id, quantity, unit_cost)
    values (v_pu.id, v_it.product_id, v_it.quantity, v_it.unit_cost);
    insert into public.stock_movements (product_id, movement_type, quantity_change, reason,
                                        reference, source_type, source_id, created_by)
    values (v_it.product_id, 'ACHAT', v_it.quantity, 'Achat ' || v_pu.purchase_number,
            v_pu.purchase_number, 'PURCHASE', v_pu.id, auth.uid());
  end loop;

  if coalesce(p_amount_paid, 0) > 0 then
    perform private.post_supplier_payment(v_pu.id, p_amount_paid, p_method, p_reference);
  end if;

  select * into v_pu from public.purchases where id = v_pu.id;
  return jsonb_build_object('purchase_id', v_pu.id, 'purchase_number', v_pu.purchase_number,
                            'total_amount', v_pu.total_amount, 'amount_paid', v_pu.amount_paid,
                            'balance', v_pu.balance);
end $$;

create function public.pay_supplier(
  p_purchase_id uuid,
  p_amount      numeric,
  p_method      public.payment_method default 'ESPECES',
  p_reference   text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_pu public.purchases;
begin
  perform private.require_role('ADMIN', 'GESTIONNAIRE');
  perform private.post_supplier_payment(p_purchase_id, p_amount, p_method, p_reference);
  select * into v_pu from public.purchases where id = p_purchase_id;
  return jsonb_build_object('purchase_number', v_pu.purchase_number,
                            'amount_paid', v_pu.amount_paid, 'balance', v_pu.balance);
end $$;

-- Facture pour une inscription, une vente ou une commande de service (une seule facture valide par cible)
create function public.issue_invoice(
  p_kind      public.payment_kind,
  p_target_id uuid,
  p_due_date  date default null,
  p_notes     text default null
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_e     public.enrollments;
  v_s     public.sales;
  v_o     public.service_orders;
  v_inv   public.invoices;
  v_name  text;
  v_desc  text;
  v_total numeric;
  v_student uuid;
  v_customer uuid;
begin
  perform private.require_role('ADMIN', 'CAISSIER', 'SECRETAIRE');

  select * into v_inv from public.invoices
   where status = 'VALIDE' and coalesce(enrollment_id, sale_id, service_order_id) = p_target_id;
  if found then
    return jsonb_build_object('invoice_id', v_inv.id, 'invoice_number', v_inv.invoice_number, 'existing', true);
  end if;

  if p_kind = 'INSCRIPTION' then
    select * into v_e from public.enrollments where id = p_target_id;
    if not found then raise exception 'Inscription introuvable'; end if;
    select trim(first_name || ' ' || last_name) into v_name from public.students where id = v_e.student_id;
    select 'Formation : ' || name into v_desc from public.trainings where id = v_e.training_id;
    v_total := v_e.total_due; v_student := v_e.student_id;
  elsif p_kind = 'VENTE' then
    perform private.require_role('ADMIN', 'CAISSIER');
    select * into v_s from public.sales where id = p_target_id;
    if not found then raise exception 'Vente introuvable'; end if;
    select name into v_name from public.customers where id = v_s.customer_id;
    v_name := coalesce(v_name, 'Client comptoir');
    v_desc := 'Vente ' || v_s.sale_number; v_total := v_s.total; v_customer := v_s.customer_id;
  else
    perform private.require_role('ADMIN', 'CAISSIER');
    select * into v_o from public.service_orders where id = p_target_id;
    if not found then raise exception 'Commande introuvable'; end if;
    select name into v_name from public.customers where id = v_o.customer_id;
    select 'Service : ' || name into v_desc from public.services where id = v_o.service_id;
    v_total := v_o.total; v_customer := v_o.customer_id;
  end if;

  insert into public.invoices (invoice_number, kind, student_id, customer_id, enrollment_id, sale_id,
                               service_order_id, client_name, description, total, due_date, notes, issued_by)
  values (private.next_number('invoice', private.setting_text('invoice_prefix', 'FAC')), p_kind,
          v_student, v_customer, v_e.id, v_s.id, v_o.id, v_name, v_desc, v_total, p_due_date, p_notes, auth.uid())
  returning * into v_inv;

  return jsonb_build_object('invoice_id', v_inv.id, 'invoice_number', v_inv.invoice_number, 'existing', false);
end $$;

-- ===========================================================================
-- Droits d'exécution : utilisateurs connectés uniquement (jamais anon / public)
-- ===========================================================================
do $$
declare r record;
begin
  for r in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = any (array['enroll_student','record_payment','create_sale','create_service_order',
                                  'void_payment','void_sale','record_expense','void_expense',
                                  'record_stock_movement','create_purchase','pay_supplier',
                                  'issue_invoice','current_role'])
  loop
    execute format('revoke all on function %s from public, anon', r.sig);
    execute format('grant execute on function %s to authenticated', r.sig);
  end loop;
end $$;
