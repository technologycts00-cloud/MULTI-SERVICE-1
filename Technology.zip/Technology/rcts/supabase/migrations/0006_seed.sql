-- PHASE 2 — Données initiales (paramètres, matrice de rôles, catégories de dépenses)
-- Aucune donnée fictive : seulement la configuration nécessaire au fonctionnement.

insert into public.settings (key, value, description) values
  ('org_name',         to_jsonb('R.CTS'::text),                       'Nom commercial'),
  ('org_legal_name',   to_jsonb('R.COMPLEX TECHNOLOGY SERVICES'::text), 'Raison sociale (en-tête des documents)'),
  ('phone',            to_jsonb(''::text),                            'Téléphone'),
  ('email',            to_jsonb(''::text),                            'E-mail'),
  ('address',          to_jsonb(''::text),                            'Adresse'),
  ('logo_url',         to_jsonb(''::text),                            'URL du logo'),
  ('currency',         to_jsonb('HTG'::text),                         'Devise principale (HTG / GDES)'),
  ('receipt_prefix',   to_jsonb('RCTS'::text),                        'Préfixe des numéros de reçu (RCTS-2026-000001)'),
  ('invoice_prefix',   to_jsonb('FAC'::text),                         'Préfixe des numéros de facture'),
  ('invoice_footer',   to_jsonb(''::text),                            'Mentions de bas de facture')
on conflict (key) do nothing;

-- Matrice de permissions par défaut (reflète les règles RLS)
insert into public.users_roles (role, module, can_view, can_create, can_edit, can_delete)
select r.role::public.user_role, m.module, true, true, true, (r.role = 'ADMIN')
from (values
  ('ADMIN',        array['dashboard','eleves','formations','inscriptions','paiements','caisse','ventes','produits',
                         'stock','clients','services','fournisseurs','depenses','finances','rapports',
                         'utilisateurs','parametres']),
  ('CAISSIER',     array['dashboard','caisse','ventes','paiements']),
  ('SECRETAIRE',   array['dashboard','eleves','formations','inscriptions']),
  ('GESTIONNAIRE', array['dashboard','produits','stock','fournisseurs']),
  ('FORMATEUR',    array['dashboard','formations','eleves'])
) as r(role, modules)
cross join lateral unnest(r.modules) as m(module)
on conflict (role, module) do nothing;

insert into public.expense_categories (name) values
  ('Loyer'), ('Électricité'), ('Internet'), ('Salaires'), ('Fournitures'),
  ('Transport'), ('Maintenance'), ('Achat marchandises'), ('Matériel'), ('Autres')
on conflict (name) do nothing;
