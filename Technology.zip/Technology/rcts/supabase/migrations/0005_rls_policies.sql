-- PHASE 2 — Row Level Security et droits d'accès
-- Principe : lecture selon le rôle ; écriture directe seulement sur les données "maître"
-- (élèves, produits, clients…). Toute écriture financière passe par les fonctions RPC.

-- ---------------------------------------------------------------------------
-- 1. Droits de base (RLS reste la barrière principale)
-- ---------------------------------------------------------------------------
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- Tables financières / d'audit : AUCUNE écriture directe (uniquement via RPC SECURITY DEFINER)
revoke insert, update, delete on
  public.payments, public.cash_transactions, public.receipts, public.invoices,
  public.sales, public.sale_items, public.expenses, public.stock_movements,
  public.purchases, public.purchase_items, public.supplier_payments,
  public.audit_logs, public.counters
from authenticated;
revoke all on public.counters from authenticated;

-- Inscriptions : insertion via RPC ; modification limitée à quelques colonnes
revoke insert, update, delete on public.enrollments from authenticated;
grant update (discount, status, notes) on public.enrollments to authenticated;

-- Commandes de service : insertion via RPC ; seules colonnes opérationnelles modifiables
revoke insert, update, delete on public.service_orders from authenticated;
grant update (status, due_date, responsible_id, comment) on public.service_orders to authenticated;

-- Suppressions : jamais sur les tables de référence liées à l'historique
revoke delete on
  public.students, public.trainings, public.customers, public.suppliers, public.services,
  public.certificates, public.profiles, public.users_roles, public.settings,
  public.expense_categories
from authenticated;

-- Profils : un utilisateur ne modifie que son nom (le reste = ADMIN)
revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;
-- (l'ADMIN modifie rôle/statut via une fonction dédiée en Phase 10 ou le service_role)

grant select on public.v_cash_balance, public.v_student_balances, public.v_customer_balances,
                public.v_supplier_balances, public.v_staff to authenticated;

-- ---------------------------------------------------------------------------
-- 2. Activation de la RLS
-- ---------------------------------------------------------------------------
alter table public.settings            enable row level security;
alter table public.counters            enable row level security;
alter table public.users_roles         enable row level security;
alter table public.students            enable row level security;
alter table public.trainings           enable row level security;
alter table public.enrollments         enable row level security;
alter table public.certificates        enable row level security;
alter table public.customers           enable row level security;
alter table public.suppliers           enable row level security;
alter table public.services            enable row level security;
alter table public.service_orders      enable row level security;
alter table public.product_categories  enable row level security;
alter table public.products            enable row level security;
alter table public.stock_movements     enable row level security;
alter table public.sales               enable row level security;
alter table public.sale_items          enable row level security;
alter table public.payments            enable row level security;
alter table public.cash_transactions   enable row level security;
alter table public.receipts            enable row level security;
alter table public.invoices            enable row level security;
alter table public.expense_categories  enable row level security;
alter table public.expenses            enable row level security;
alter table public.purchases           enable row level security;
alter table public.purchase_items      enable row level security;
alter table public.supplier_payments   enable row level security;
alter table public.audit_logs          enable row level security;
-- counters : aucune politique = inaccessible à l'API

-- ---------------------------------------------------------------------------
-- 3. Politiques
-- ---------------------------------------------------------------------------

-- Profils : le secrétariat doit pouvoir lister les formateurs
create policy profiles_select_staff on public.profiles
  for select to authenticated using (private.has_role('SECRETAIRE'));

-- Paramètres et matrice de rôles : lecture pour tous les connectés, écriture ADMIN
create policy settings_select on public.settings for select to authenticated using (true);
create policy settings_write  on public.settings for all to authenticated
  using (private.has_role('ADMIN')) with check (private.has_role('ADMIN'));
create policy users_roles_select on public.users_roles for select to authenticated using (true);
create policy users_roles_write  on public.users_roles for all to authenticated
  using (private.has_role('ADMIN')) with check (private.has_role('ADMIN'));

-- Élèves
create policy students_select on public.students for select to authenticated using (
  private.has_role('ADMIN', 'SECRETAIRE', 'CAISSIER')
  or (private.has_role('FORMATEUR') and private.is_trainer_of_student(id)));
create policy students_insert on public.students for insert to authenticated
  with check (private.has_role('ADMIN', 'SECRETAIRE'));
create policy students_update on public.students for update to authenticated
  using (private.has_role('ADMIN', 'SECRETAIRE')) with check (private.has_role('ADMIN', 'SECRETAIRE'));

-- Formations
create policy trainings_select on public.trainings for select to authenticated using (
  private.has_role('ADMIN', 'SECRETAIRE', 'CAISSIER')
  or (private.has_role('FORMATEUR') and trainer_id = auth.uid()));
create policy trainings_insert on public.trainings for insert to authenticated
  with check (private.has_role('ADMIN', 'SECRETAIRE'));
create policy trainings_update on public.trainings for update to authenticated
  using (private.has_role('ADMIN', 'SECRETAIRE')) with check (private.has_role('ADMIN', 'SECRETAIRE'));

-- Inscriptions
create policy enrollments_select on public.enrollments for select to authenticated using (
  private.has_role('ADMIN', 'SECRETAIRE', 'CAISSIER')
  or (private.has_role('FORMATEUR') and private.is_trainer_of_training(training_id)));
create policy enrollments_update on public.enrollments for update to authenticated
  using (private.has_role('ADMIN', 'SECRETAIRE')) with check (private.has_role('ADMIN', 'SECRETAIRE'));

-- Certificats
create policy certificates_select on public.certificates for select to authenticated using (
  private.has_role('ADMIN', 'SECRETAIRE')
  or (private.has_role('FORMATEUR') and private.is_trainer_of_training(training_id)));
create policy certificates_insert on public.certificates for insert to authenticated
  with check (private.has_role('ADMIN', 'SECRETAIRE'));
create policy certificates_update on public.certificates for update to authenticated
  using (private.has_role('ADMIN', 'SECRETAIRE')) with check (private.has_role('ADMIN', 'SECRETAIRE'));

-- Clients
create policy customers_select on public.customers for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));
create policy customers_insert on public.customers for insert to authenticated
  with check (private.has_role('ADMIN', 'CAISSIER'));
create policy customers_update on public.customers for update to authenticated
  using (private.has_role('ADMIN', 'CAISSIER')) with check (private.has_role('ADMIN', 'CAISSIER'));

-- Fournisseurs, achats, paiements fournisseurs
create policy suppliers_select on public.suppliers for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy suppliers_insert on public.suppliers for insert to authenticated
  with check (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy suppliers_update on public.suppliers for update to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE')) with check (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy purchases_select on public.purchases for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy purchase_items_select on public.purchase_items for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy supplier_payments_select on public.supplier_payments for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));

-- Catalogue de services (lecture caisse, écriture ADMIN) et commandes
create policy services_select on public.services for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));
create policy services_write on public.services for all to authenticated
  using (private.has_role('ADMIN')) with check (private.has_role('ADMIN'));
create policy service_orders_select on public.service_orders for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));
create policy service_orders_update on public.service_orders for update to authenticated
  using (private.has_role('ADMIN', 'CAISSIER')) with check (private.has_role('ADMIN', 'CAISSIER'));

-- Produits, catégories, mouvements de stock
create policy product_categories_select on public.product_categories for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE', 'CAISSIER'));
create policy product_categories_write on public.product_categories for all to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE')) with check (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy products_select on public.products for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE', 'CAISSIER'));
-- Le stock ne se modifie JAMAIS directement : il est maintenu par les mouvements (trigger)
create policy products_insert on public.products for insert to authenticated
  with check (private.has_role('ADMIN', 'GESTIONNAIRE') and current_stock = 0);
create policy products_update on public.products for update to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE')) with check (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy products_delete on public.products for delete to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));
create policy stock_movements_select on public.stock_movements for select to authenticated
  using (private.has_role('ADMIN', 'GESTIONNAIRE'));

-- Ventes
create policy sales_select on public.sales for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));
create policy sale_items_select on public.sale_items for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));

-- Paiements, caisse, reçus, factures
create policy payments_select on public.payments for select to authenticated using (
  private.has_role('ADMIN', 'CAISSIER')
  or (private.has_role('SECRETAIRE') and kind = 'INSCRIPTION'));
create policy cash_transactions_select on public.cash_transactions for select to authenticated
  using (private.has_role('ADMIN', 'CAISSIER'));
create policy receipts_select on public.receipts for select to authenticated using (
  private.has_role('ADMIN', 'CAISSIER')
  or (private.has_role('SECRETAIRE')
      and exists (select 1 from public.payments p where p.id = payment_id and p.kind = 'INSCRIPTION')));
create policy invoices_select on public.invoices for select to authenticated using (
  private.has_role('ADMIN', 'CAISSIER')
  or (private.has_role('SECRETAIRE') and kind = 'INSCRIPTION'));

-- Dépenses
create policy expense_categories_select on public.expense_categories for select to authenticated
  using (private.has_role('ADMIN'));
create policy expense_categories_write on public.expense_categories for all to authenticated
  using (private.has_role('ADMIN')) with check (private.has_role('ADMIN'));
create policy expenses_select on public.expenses for select to authenticated
  using (private.has_role('ADMIN'));

-- Audit : lecture ADMIN uniquement
create policy audit_logs_select on public.audit_logs for select to authenticated
  using (private.has_role('ADMIN'));
