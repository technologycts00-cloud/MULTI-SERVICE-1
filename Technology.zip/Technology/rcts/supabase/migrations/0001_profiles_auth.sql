-- PHASE 1 : socle d'authentification (le schéma complet suit en Phase 2)

do $$ begin
  create type public.user_role as enum
    ('ADMIN','CAISSIER','SECRETAIRE','GESTIONNAIRE','FORMATEUR');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  email       text,
  role        public.user_role not null default 'SECRETAIRE',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists profiles_role_idx on public.profiles(role);

-- Fonction utilitaire : rôle de l'utilisateur courant (SECURITY DEFINER évite la récursion RLS)
create or replace function public.current_role()
returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and is_active
$$;

-- Création automatique du profil à l'inscription Supabase Auth.
-- Le rôle n'est JAMAIS lu depuis les métadonnées client : tout nouveau compte
-- démarre en SECRETAIRE, seul un ADMIN peut changer le rôle.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), new.email);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.current_role() = 'ADMIN');

drop policy if exists "profiles_admin_all" on public.profiles;
create policy "profiles_admin_all" on public.profiles
  for all to authenticated
  using (public.current_role() = 'ADMIN')
  with check (public.current_role() = 'ADMIN');

-- Un utilisateur peut modifier son nom, mais pas son rôle ni son statut
drop policy if exists "profiles_update_own_name" on public.profiles;
create policy "profiles_update_own_name" on public.profiles
  for update to authenticated
  using (id = auth.uid())
  with check (
    id = auth.uid()
    and role = (select role from public.profiles where id = auth.uid())
    and is_active = (select is_active from public.profiles where id = auth.uid())
  );

-- Premier administrateur : après avoir créé votre compte dans
-- Supabase > Authentication > Users, exécutez (en remplaçant l'email) :
--   update public.profiles set role = 'ADMIN' where email = 'votre@email.com';
