-- PHASE 10 : administration des utilisateurs, matrice de permissions et paramètres
--
--  * admin_update_user : seul moyen de changer rôle / statut d'un profil (ADMIN), avec garde-fous :
--      - on ne modifie pas son propre rôle ni son propre statut ;
--      - il doit toujours rester au moins un ADMIN actif.
--  * la matrice users_roles de l'ADMIN n'est pas modifiable (pas de verrouillage accidentel) ;
--  * les paramètres de numérotation sont validés (préfixes A-Z / 0-9, 2 à 8 caractères).

create function public.admin_update_user(
  p_user      uuid,
  p_full_name text,
  p_role      public.user_role,
  p_active    boolean
) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_old  public.profiles;
  v_name text := nullif(btrim(coalesce(p_full_name, '')), '');
begin
  perform private.require_role('ADMIN');
  select * into v_old from public.profiles where id = p_user for update;
  if not found then
    raise exception 'Utilisateur introuvable';
  end if;
  if v_name is not null and char_length(v_name) > 120 then
    raise exception 'Nom trop long (120 caractères maximum)';
  end if;
  if p_user = auth.uid() and (p_role is distinct from v_old.role or p_active is distinct from v_old.is_active) then
    raise exception 'Vous ne pouvez pas modifier votre propre rôle ni désactiver votre propre compte';
  end if;
  if v_old.role = 'ADMIN' and v_old.is_active and (p_role <> 'ADMIN' or not p_active)
     and not exists (select 1 from public.profiles where role = 'ADMIN' and is_active and id <> p_user) then
    raise exception 'Il doit rester au moins un administrateur actif';
  end if;
  update public.profiles
     set full_name = coalesce(v_name, full_name), role = p_role, is_active = p_active, updated_at = now()
   where id = p_user;
end $$;

revoke all on function public.admin_update_user(uuid, text, public.user_role, boolean) from public, anon;
grant execute on function public.admin_update_user(uuid, text, public.user_role, boolean) to authenticated;

-- Lignes manquantes de la matrice (même plafond que lib/permissions.ts)
insert into public.users_roles (role, module, can_view, can_create, can_edit, can_delete)
select r.role::public.user_role, m.module, true, true, true, false
from (values
  ('CAISSIER',     array['dashboard','caisse','ventes','paiements','clients','services','rapports']),
  ('SECRETAIRE',   array['dashboard','eleves','formations','inscriptions','rapports']),
  ('GESTIONNAIRE', array['dashboard','produits','stock','fournisseurs','rapports']),
  ('FORMATEUR',    array['dashboard','formations','eleves','rapports'])
) as r(role, modules)
cross join lateral unnest(r.modules) as m(module)
on conflict (role, module) do nothing;

-- Matrice : pas de modification des droits ADMIN, ni de ligne hors plafond d'un rôle
create function private.guard_users_roles()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin
  if auth.uid() is not null and (coalesce(new.role, old.role) = 'ADMIN') then
    raise exception 'Les droits de l''administrateur ne sont pas modifiables';
  end if;
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end $$;

create trigger users_roles_guard before insert or update or delete on public.users_roles
  for each row execute function private.guard_users_roles();

-- Paramètres : traçabilité de l'auteur + validation des préfixes de numérotation
create function private.guard_settings()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin
  if new.key in ('receipt_prefix', 'invoice_prefix') and (new.value #>> '{}') !~ '^[A-Z0-9]{2,8}$' then
    raise exception 'Préfixe invalide : 2 à 8 caractères (majuscules et chiffres)';
  end if;
  new.updated_by := auth.uid();
  new.updated_at := now();
  return new;
end $$;

create trigger settings_guard before insert or update on public.settings
  for each row execute function private.guard_settings();
