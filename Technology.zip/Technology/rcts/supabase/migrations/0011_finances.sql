-- PHASE 8 : finances (vue globale, créances, dettes) et justificatifs de dépenses

-- Vue financière sur une période (dates en heure d'Haïti ; null = toute la période).
--   Recettes  = entrées de caisse valides (formations, ventes, services, autres), tous modes de paiement
--   Dépenses  = sorties de caisse valides (dépenses, achats fournisseurs)
--   Solde     = recettes − dépenses
--   Créances  = soldes dus par les élèves / clients (inscriptions, ventes, services non annulés)
--   Dettes    = soldes dus aux fournisseurs (achats valides)
-- Réservée à l'ADMIN (security invoker : la RLS s'applique en plus).
create function public.finance_summary(p_from date default null, p_to date default null)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_from timestamptz := case when p_from is null then null else private.day_start(p_from) end;
  v_to   timestamptz := case when p_to   is null then null else private.day_start(p_to + 1) end;
  v_in   numeric;
  v_out  numeric;
begin
  if not private.has_role('ADMIN') then
    raise exception 'Accès refusé : permission insuffisante' using errcode = '42501';
  end if;
  if p_from is not null and p_to is not null and p_to < p_from then
    raise exception 'La date de fin précède la date de début';
  end if;

  select coalesce(sum(amount) filter (where direction = 'IN'), 0),
         coalesce(sum(amount) filter (where direction = 'OUT'), 0)
    into v_in, v_out
    from public.cash_transactions t
   where t.status = 'VALIDE'
     and (v_from is null or t.occurred_at >= v_from)
     and (v_to   is null or t.occurred_at <  v_to);

  return jsonb_build_object(
    'income',  v_in,
    'expenses', v_out,
    'balance', v_in - v_out,
    'cash_on_hand', (select cash_on_hand from public.v_cash_balance),
    'income_by_category', coalesce((
      select jsonb_agg(jsonb_build_object('category', category, 'total', total) order by total desc)
        from (select category, sum(amount) as total from public.cash_transactions t
               where t.status = 'VALIDE' and t.direction = 'IN'
                 and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
               group by category) x), '[]'::jsonb),
    'income_by_method', coalesce((
      select jsonb_agg(jsonb_build_object('method', method, 'total', total) order by total desc)
        from (select method, sum(amount) as total from public.cash_transactions t
               where t.status = 'VALIDE' and t.direction = 'IN'
                 and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
               group by method) x), '[]'::jsonb),
    'expenses_by_category', coalesce((
      select jsonb_agg(jsonb_build_object('category', category, 'total', total) order by total desc)
        from (select coalesce(ec.name, case t.category when 'ACHAT_FOURNISSEUR' then 'Achats fournisseurs' else 'Autres' end) as category,
                     sum(t.amount) as total
                from public.cash_transactions t
                left join public.expenses e on t.source_type = 'EXPENSE' and e.id = t.source_id
                left join public.expense_categories ec on ec.id = e.category_id
               where t.status = 'VALIDE' and t.direction = 'OUT'
                 and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
               group by 1) x), '[]'::jsonb),
    'monthly', coalesce((
      select jsonb_agg(jsonb_build_object('month', month, 'income', inc, 'expenses', exp) order by month)
        from (select to_char(t.occurred_at at time zone 'America/Port-au-Prince', 'YYYY-MM') as month,
                     sum(t.amount) filter (where t.direction = 'IN')  as inc,
                     sum(t.amount) filter (where t.direction = 'OUT') as exp
                from public.cash_transactions t
               where t.status = 'VALIDE'
                 and (v_from is null or t.occurred_at >= v_from) and (v_to is null or t.occurred_at < v_to)
               group by 1 order by 1 desc limit 24) m), '[]'::jsonb),
    'receivables', jsonb_build_object(
      'formations', (select coalesce(sum(balance), 0) from public.enrollments where status <> 'ANNULEE'),
      'ventes',     (select coalesce(sum(balance), 0) from public.sales where status = 'VALIDE'),
      'services',   (select coalesce(sum(balance), 0) from public.service_orders where status <> 'ANNULE'),
      'total', (select coalesce(sum(balance), 0) from public.enrollments where status <> 'ANNULEE')
             + (select coalesce(sum(balance), 0) from public.sales where status = 'VALIDE')
             + (select coalesce(sum(balance), 0) from public.service_orders where status <> 'ANNULE'),
      'count', (select count(*) from public.enrollments where status <> 'ANNULEE' and balance > 0)
             + (select count(*) from public.sales where status = 'VALIDE' and balance > 0)
             + (select count(*) from public.service_orders where status <> 'ANNULE' and balance > 0)),
    'payables', jsonb_build_object(
      'total', (select coalesce(sum(balance), 0) from public.purchases where status = 'VALIDE'),
      'count', (select count(*) from public.purchases where status = 'VALIDE' and balance > 0))
  );
end $$;

revoke all on function public.finance_summary(date, date) from public, anon;
grant execute on function public.finance_summary(date, date) to authenticated;

-- Justificatifs de dépenses : bucket privé, ADMIN uniquement
do $$
begin
  if to_regnamespace('storage') is null then
    raise notice 'Schéma storage absent : bucket expense-receipts non créé (environnement hors Supabase)';
    return;
  end if;

  insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('expense-receipts', 'expense-receipts', false, 5242880,
          array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'])
  on conflict (id) do update
    set public = false, file_size_limit = 5242880,
        allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];

  drop policy if exists expense_receipts_select on storage.objects;
  drop policy if exists expense_receipts_insert on storage.objects;
  drop policy if exists expense_receipts_delete on storage.objects;
  create policy expense_receipts_select on storage.objects for select to authenticated
    using (bucket_id = 'expense-receipts' and private.has_role('ADMIN'));
  create policy expense_receipts_insert on storage.objects for insert to authenticated
    with check (bucket_id = 'expense-receipts' and private.has_role('ADMIN'));
  create policy expense_receipts_delete on storage.objects for delete to authenticated
    using (bucket_id = 'expense-receipts' and private.has_role('ADMIN'));
end $$;
