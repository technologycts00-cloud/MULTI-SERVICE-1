-- PHASE 4 — Élèves, formations, inscriptions : règles métier côté base

-- ---------------------------------------------------------------------------
-- 1. Inscriptions : transitions de statut et réduction
-- ---------------------------------------------------------------------------
create function private.guard_enrollment_change()
returns trigger language plpgsql as $$
begin
  -- Une inscription annulée est définitive
  if old.status = 'ANNULEE' and new.status <> 'ANNULEE' then
    raise exception 'Une inscription annulée ne peut pas être réactivée : créez une nouvelle inscription';
  end if;

  -- Un certificat délivré verrouille le statut « terminée »
  if old.status = 'TERMINEE' and new.status <> 'TERMINEE'
     and exists (select 1 from public.certificates where enrollment_id = old.id) then
    raise exception 'Un certificat a été délivré pour cette inscription : son statut ne peut plus changer';
  end if;

  -- Seul l'ADMIN modifie la réduction (impact direct sur le solde)
  if new.discount is distinct from old.discount and not private.has_role('ADMIN') then
    raise exception 'Seul un administrateur peut modifier la réduction' using errcode = '42501';
  end if;
  return new;
end $$;

create trigger enrollments_guard_change before update on public.enrollments
  for each row execute function private.guard_enrollment_change();

-- Un formateur ne voit plus un élève dont l'inscription à sa formation est annulée
create or replace function private.is_trainer_of_student(p_student_id uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1
                   from public.enrollments e
                   join public.trainings t on t.id = e.training_id
                  where e.student_id = p_student_id
                    and e.status <> 'ANNULEE'
                    and t.trainer_id = auth.uid())
$$;

-- ---------------------------------------------------------------------------
-- 2. Certificats : uniquement via la fonction (règles vérifiées côté serveur)
-- ---------------------------------------------------------------------------
revoke insert, update on public.certificates from authenticated;

create function public.issue_certificate(p_enrollment_id uuid, p_notes text default null)
returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_e    public.enrollments;
  v_cert public.certificates;
begin
  perform private.require_role('ADMIN', 'SECRETAIRE');

  select * into v_e from public.enrollments where id = p_enrollment_id for update;
  if not found then raise exception 'Inscription introuvable'; end if;
  if v_e.status <> 'TERMINEE' then
    raise exception 'Le certificat ne peut être délivré que pour une formation terminée';
  end if;
  if v_e.balance > 0 then
    raise exception 'Le certificat ne peut pas être délivré : il reste un solde de % HTG à payer', v_e.balance;
  end if;
  if exists (select 1 from public.certificates where enrollment_id = p_enrollment_id) then
    raise exception 'Un certificat existe déjà pour cette inscription';
  end if;

  insert into public.certificates (enrollment_id, student_id, training_id, notes)
  values (v_e.id, v_e.student_id, v_e.training_id, p_notes)
  returning * into v_cert;

  return jsonb_build_object('certificate_id', v_cert.id, 'certificate_number', v_cert.certificate_number);
end $$;

revoke all on function public.issue_certificate(uuid, text) from public, anon;
grant execute on function public.issue_certificate(uuid, text) to authenticated;

-- ---------------------------------------------------------------------------
-- 3. Recherche rapide (ILIKE '%…%') : index trigramme par colonne
-- ---------------------------------------------------------------------------
do $$
declare
  s text;
  c text;
begin
  select n.nspname into s
    from pg_extension e join pg_namespace n on n.oid = e.extnamespace
   where e.extname = 'pg_trgm';

  drop index if exists public.students_search_idx;   -- remplacé par des index par colonne
  foreach c in array array['first_name', 'last_name', 'student_code', 'phone'] loop
    execute format('create index students_%s_trgm on public.students using gin (%I %I.gin_trgm_ops)', c, c, s);
  end loop;
  execute format('create index trainings_name_trgm on public.trainings using gin (name %I.gin_trgm_ops)', s);
end $$;

create index enrollments_status_idx on public.enrollments (status);

-- ---------------------------------------------------------------------------
-- 4. Photos des élèves : bucket privé Supabase Storage (ignoré hors Supabase)
--    Le chemin du fichier est stocké dans students.photo_url ; l'affichage
--    passe par une URL signée à durée limitée générée côté serveur.
-- ---------------------------------------------------------------------------
do $$
begin
  if to_regnamespace('storage') is null then
    raise notice 'Schéma storage absent : bucket student-photos non créé (environnement hors Supabase)';
    return;
  end if;

  insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('student-photos', 'student-photos', false, 2097152,
          array['image/jpeg', 'image/png', 'image/webp'])
  on conflict (id) do update
    set public = false, file_size_limit = 2097152,
        allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];

  drop policy if exists student_photos_select on storage.objects;
  drop policy if exists student_photos_insert on storage.objects;
  drop policy if exists student_photos_delete on storage.objects;

  -- Lecture : seulement si l'utilisateur peut lire l'élève (RLS de students appliquée)
  create policy student_photos_select on storage.objects for select to authenticated
    using (bucket_id = 'student-photos'
           and exists (select 1 from public.students s where s.photo_url = storage.objects.name));

  create policy student_photos_insert on storage.objects for insert to authenticated
    with check (bucket_id = 'student-photos' and private.has_role('ADMIN', 'SECRETAIRE'));

  create policy student_photos_delete on storage.objects for delete to authenticated
    using (bucket_id = 'student-photos' and private.has_role('ADMIN', 'SECRETAIRE'));
end $$;

