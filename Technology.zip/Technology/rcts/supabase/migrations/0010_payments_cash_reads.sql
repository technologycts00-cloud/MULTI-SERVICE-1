-- PHASE 5 — Paiements, reçus, factures, caisse : lectures + correctif de sécurité du stock
-- Toutes les fonctions de lecture sont SECURITY INVOKER : la RLS de l'utilisateur s'applique
-- (un secrétaire ne voit que les paiements d'inscription, un formateur rien, etc.).

-- ---------------------------------------------------------------------------
-- 1. CORRECTIF : le stock ne se modifie que par les mouvements de stock
--    (avant : un gestionnaire pouvait faire UPDATE products SET current_stock = …)
-- ---------------------------------------------------------------------------
revoke update on public.products from authenticated;
grant update (name, category_id, description, purchase_price, sale_price, min_stock, supplier_id, status)
  on public.products to authenticated;

-- ---------------------------------------------------------------------------
-- 2. Outils internes
-- ---------------------------------------------------------------------------
-- Motif ILIKE sûr : « % » et « _ » saisis par l'utilisateur sont traités comme du texte
create function private.like_pattern(p text)
returns text language sql immutable as $$
  select '%' || replace(replace(replace(trim(coalesce(p, '')), '\', '\\'), '%', '\%'), '_', '\_') || '%'
$$;
grant execute on function private.like_pattern(text) to authenticated;

-- Début de journée en Haïti (borne inclusive) ; day_start(to + 1) = borne supérieure exclusive
create function private.day_start(p date)
returns timestamptz language sql stable as $$
  select p::timestamp at time zone 'America/Port-au-Prince'
$$;
grant execute on function private.day_start(date) to authenticated;

create function private.clamp_limit(p int, p_default int default 20)
returns int language sql immutable as $$
  select least(greatest(coalesce(p, p_default), 1), 100)
$$;
grant execute on function private.clamp_limit(int, int) to authenticated;

-- Informations de l'entreprise pour les en-têtes de documents (lisibles par tout utilisateur connecté)
create function private.org_info()
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
    from public.settings
   where key in ('org_name', 'org_legal_name', 'phone', 'email', 'address', 'logo_url',
                 'currency', 'invoice_footer', 'receipt_prefix', 'invoice_prefix')
$$;
grant execute on function private.org_info() to authenticated;

-- ---------------------------------------------------------------------------
-- 3. Historique des paiements (filtres, recherche, pagination)
-- ---------------------------------------------------------------------------
create function public.list_payments(
  p_q      text default null,
  p_kind   public.payment_kind default null,
  p_method public.payment_method default null,
  p_status public.record_status default null,
  p_from   date default null,
  p_to     date default null,
  p_limit  int default 20,
  p_offset int default 0
) returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_pat   text := case when nullif(trim(coalesce(p_q, '')), '') is null then null else private.like_pattern(p_q) end;
  v_lim   int := private.clamp_limit(p_limit);
  v_off   int := greatest(coalesce(p_offset, 0), 0);
  v_rows  jsonb;
  v_total bigint;
begin
  select coalesce(jsonb_agg(to_jsonb(r) - 'full_count' order by r.paid_at desc, r.id), '[]'::jsonb),
         coalesce(max(r.full_count), 0)
    into v_rows, v_total
    from (
      select p.id, p.payment_number, p.kind, p.amount, p.method, p.reference, p.description,
             p.paid_at, p.status, p.void_reason, p.enrollment_id, p.sale_id, p.service_order_id,
             coalesce(nullif(trim(s.first_name || ' ' || s.last_name), ''), c.name, 'Client comptoir') as payer_name,
             coalesce(e.enrollment_number, sa.sale_number, so.order_number) as target_number,
             rc.id as receipt_id, rc.receipt_number,
             st.full_name as user_name,
             count(*) over () as full_count
        from public.payments p
        left join public.students s        on s.id = p.student_id
        left join public.customers c       on c.id = p.customer_id
        left join public.enrollments e     on e.id = p.enrollment_id
        left join public.sales sa          on sa.id = p.sale_id
        left join public.service_orders so on so.id = p.service_order_id
        left join public.receipts rc       on rc.payment_id = p.id
        left join public.v_staff st        on st.id = p.created_by
       where (p_kind   is null or p.kind = p_kind)
         and (p_method is null or p.method = p_method)
         and (p_status is null or p.status = p_status)
         and (p_from   is null or p.paid_at >= private.day_start(p_from))
         and (p_to     is null or p.paid_at <  private.day_start(p_to + 1))
         and (v_pat is null
              or trim(s.first_name || ' ' || s.last_name) ilike v_pat escape '\'
              or c.name ilike v_pat escape '\'
              or p.payment_number ilike v_pat escape '\'
              or rc.receipt_number ilike v_pat escape '\'
              or p.reference ilike v_pat escape '\'
              or coalesce(e.enrollment_number, sa.sale_number, so.order_number) ilike v_pat escape '\')
       order by p.paid_at desc, p.id
       limit v_lim offset v_off
    ) r;

  return jsonb_build_object('rows', v_rows, 'total', v_total);
end $$;

-- ---------------------------------------------------------------------------
-- 4. Données d'un reçu (page imprimable + PDF)
-- ---------------------------------------------------------------------------
create function public.receipt_data(p_receipt_id uuid)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  r public.receipts;
  p public.payments;
  v_ctx jsonb;
begin
  select * into r from public.receipts where id = p_receipt_id;
  if not found then return null; end if;                 -- inexistant ou invisible pour ce rôle
  select * into p from public.payments where id = r.payment_id;
  if not found then return null; end if;

  if p.kind = 'INSCRIPTION' then
    select jsonb_build_object(
             'reference_number', e.enrollment_number,
             'label', 'Formation : ' || t.name,
             'student_code', s.student_code,
             'training_price', e.training_price,
             'registration_fee', e.registration_fee,
             'discount', e.discount)
      into v_ctx
      from public.enrollments e
      join public.trainings t on t.id = e.training_id
      join public.students s on s.id = e.student_id
     where e.id = p.enrollment_id;

  elsif p.kind = 'VENTE' then
    select jsonb_build_object(
             'reference_number', sa.sale_number,
             'label', 'Vente ' || sa.sale_number,
             'subtotal', sa.subtotal,
             'discount', sa.discount,
             'items', coalesce((select jsonb_agg(jsonb_build_object(
                                  'description', i.description, 'quantity', i.quantity,
                                  'unit_price', i.unit_price, 'line_total', i.line_total) order by i.created_at, i.id)
                                  from public.sale_items i where i.sale_id = sa.id), '[]'::jsonb))
      into v_ctx
      from public.sales sa where sa.id = p.sale_id;

  else
    select jsonb_build_object(
             'reference_number', so.order_number,
             'label', 'Service : ' || sv.name,
             'quantity', so.quantity,
             'unit_price', so.unit_price)
      into v_ctx
      from public.service_orders so
      join public.services sv on sv.id = so.service_id
     where so.id = p.service_order_id;
  end if;

  return jsonb_build_object(
    'org',     private.org_info(),
    'receipt', to_jsonb(r),
    'payment', jsonb_build_object('payment_number', p.payment_number, 'kind', p.kind,
                                  'reference', p.reference, 'paid_at', p.paid_at,
                                  'status', p.status, 'void_reason', p.void_reason),
    'issuer',  (select full_name from public.v_staff where id = r.issued_by),
    'context', coalesce(v_ctx, '{}'::jsonb));
end $$;

-- ---------------------------------------------------------------------------
-- 5. Données d'une facture (page imprimable + PDF)
-- ---------------------------------------------------------------------------
create function public.invoice_data(p_invoice_id uuid)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v public.invoices;
  v_lines    jsonb;
  v_client   jsonb;
  v_discount numeric := 0;
  v_paid     numeric := 0;
  v_total    numeric := 0;
  v_pay      jsonb;
begin
  select * into v from public.invoices where id = p_invoice_id;
  if not found then return null; end if;

  if v.kind = 'INSCRIPTION' then
    select jsonb_build_array(
             jsonb_build_object('description', 'Formation : ' || t.name, 'quantity', 1,
                                'unit_price', e.training_price, 'line_total', e.training_price),
             jsonb_build_object('description', 'Frais d''inscription', 'quantity', 1,
                                'unit_price', e.registration_fee, 'line_total', e.registration_fee)),
           e.discount, e.amount_paid, e.total_due,
           jsonb_build_object('name', trim(s.first_name || ' ' || s.last_name), 'phone', s.phone,
                              'address', s.address, 'code', s.student_code)
      into v_lines, v_discount, v_paid, v_total, v_client
      from public.enrollments e
      join public.trainings t on t.id = e.training_id
      join public.students s on s.id = e.student_id
     where e.id = v.enrollment_id;

  elsif v.kind = 'VENTE' then
    select coalesce((select jsonb_agg(jsonb_build_object(
                       'description', i.description, 'quantity', i.quantity,
                       'unit_price', i.unit_price, 'line_total', i.line_total) order by i.created_at, i.id)
                       from public.sale_items i where i.sale_id = sa.id), '[]'::jsonb),
           sa.discount, sa.amount_paid, sa.total,
           jsonb_build_object('name', coalesce(c.name, 'Client comptoir'), 'phone', c.phone, 'address', c.address)
      into v_lines, v_discount, v_paid, v_total, v_client
      from public.sales sa
      left join public.customers c on c.id = sa.customer_id
     where sa.id = v.sale_id;

  else
    select jsonb_build_array(jsonb_build_object(
             'description', 'Service : ' || sv.name, 'quantity', so.quantity,
             'unit_price', so.unit_price, 'line_total', so.total)),
           0, so.amount_paid, so.total,
           jsonb_build_object('name', c.name, 'phone', c.phone, 'address', c.address)
      into v_lines, v_discount, v_paid, v_total, v_client
      from public.service_orders so
      join public.services sv on sv.id = so.service_id
      join public.customers c on c.id = so.customer_id
     where so.id = v.service_order_id;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object('payment_number', p.payment_number, 'paid_at', p.paid_at,
                                               'method', p.method, 'amount', p.amount) order by p.paid_at), '[]'::jsonb)
    into v_pay
    from public.payments p
   where p.status = 'VALIDE'
     and coalesce(p.enrollment_id, p.sale_id, p.service_order_id) = coalesce(v.enrollment_id, v.sale_id, v.service_order_id);

  return jsonb_build_object(
    'org',      private.org_info(),
    'invoice',  to_jsonb(v),
    'client',   coalesce(v_client, '{}'::jsonb),
    'lines',    coalesce(v_lines, '[]'::jsonb),
    'payments', v_pay,
    'issuer',   (select full_name from public.v_staff where id = v.issued_by),
    'totals',   jsonb_build_object('discount', v_discount, 'total', v_total, 'paid', v_paid,
                                   'balance', greatest(v_total - v_paid, 0)));
end $$;

-- ---------------------------------------------------------------------------
-- 6. Sommes à encaisser (inscriptions, ventes à crédit, commandes de service)
-- ---------------------------------------------------------------------------
create function public.list_receivables(p_q text default null, p_limit int default 30)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_pat text := case when nullif(trim(coalesce(p_q, '')), '') is null then null else private.like_pattern(p_q) end;
  v_lim int := private.clamp_limit(p_limit, 30);
  v_rows jsonb;
begin
  select coalesce(jsonb_agg(to_jsonb(x) order by x.created_at desc, x.id), '[]'::jsonb)
    into v_rows
    from (
      select * from (
        select 'INSCRIPTION'::text as kind, e.id, e.enrollment_number as number,
               trim(s.first_name || ' ' || s.last_name) as payer_name,
               'Formation : ' || t.name as description,
               e.total_due as total, e.amount_paid, e.balance, e.created_at
          from public.enrollments e
          join public.students s on s.id = e.student_id
          join public.trainings t on t.id = e.training_id
         where e.status <> 'ANNULEE' and e.balance > 0
        union all
        select 'VENTE', sa.id, sa.sale_number, coalesce(c.name, 'Client comptoir'),
               'Vente ' || sa.sale_number, sa.total, sa.amount_paid, sa.balance, sa.created_at
          from public.sales sa
          left join public.customers c on c.id = sa.customer_id
         where sa.status = 'VALIDE' and sa.balance > 0
        union all
        select 'SERVICE', so.id, so.order_number, c.name,
               'Service : ' || sv.name, so.total, so.amount_paid, so.balance, so.created_at
          from public.service_orders so
          join public.customers c on c.id = so.customer_id
          join public.services sv on sv.id = so.service_id
         where so.status <> 'ANNULE' and so.balance > 0
      ) u
       where v_pat is null
          or u.payer_name ilike v_pat escape '\'
          or u.number ilike v_pat escape '\'
          or u.description ilike v_pat escape '\'
       order by u.created_at desc, u.id
       limit v_lim
    ) x;
  return v_rows;
end $$;

-- ---------------------------------------------------------------------------
-- 7. Caisse : catalogue (produits + services), clients, vue d'ensemble, journal
-- ---------------------------------------------------------------------------
create function public.pos_catalog(p_q text default null, p_limit int default 60)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_pat text := case when nullif(trim(coalesce(p_q, '')), '') is null then null else private.like_pattern(p_q) end;
  v_lim int := private.clamp_limit(p_limit, 60);
  v_rows jsonb;
begin
  select coalesce(jsonb_agg(to_jsonb(x) order by x.name, x.id), '[]'::jsonb)
    into v_rows
    from (
      select * from (
        select 'product'::text as type, p.id, p.name, p.code, pc.name as category,
               p.sale_price as price, p.current_stock as stock, p.stock_state, p.min_stock
          from public.products p
          left join public.product_categories pc on pc.id = p.category_id
         where p.status = 'ACTIF'
           and (v_pat is null or p.name ilike v_pat escape '\' or p.code ilike v_pat escape '\'
                or pc.name ilike v_pat escape '\')
        union all
        select 'service', sv.id, sv.name, null, sv.category, sv.unit_price, null, null, null
          from public.services sv
         where sv.is_active
           and (v_pat is null or sv.name ilike v_pat escape '\' or sv.category ilike v_pat escape '\')
      ) u
       order by u.name, u.id
       limit v_lim
    ) x;
  return v_rows;
end $$;

create function public.search_customers(p_q text default null, p_limit int default 8)
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_pat text := case when nullif(trim(coalesce(p_q, '')), '') is null then null else private.like_pattern(p_q) end;
  v_lim int := private.clamp_limit(p_limit, 8);
begin
  return coalesce((
    select jsonb_agg(to_jsonb(x) order by x.name, x.id)
      from (
        select c.id, c.name, c.phone, c.customer_type,
               coalesce(b.balance, 0) as balance
          from public.customers c
          left join public.v_customer_balances b on b.customer_id = c.id
         where not c.is_archived
           and (v_pat is null or c.name ilike v_pat escape '\' or c.phone ilike v_pat escape '\')
         order by c.name, c.id
         limit v_lim
      ) x), '[]'::jsonb);
end $$;

create function public.cash_overview()
returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_start timestamptz := private.day_start((now() at time zone 'America/Port-au-Prince')::date);
begin
  return jsonb_build_object(
    'cash_on_hand', (select cash_on_hand from public.v_cash_balance),
    'today_in',  (select coalesce(sum(amount), 0) from public.cash_transactions
                   where status = 'VALIDE' and direction = 'IN'  and occurred_at >= v_start),
    'today_out', (select coalesce(sum(amount), 0) from public.cash_transactions
                   where status = 'VALIDE' and direction = 'OUT' and occurred_at >= v_start),
    'today_sales', (select count(*) from public.sales where status = 'VALIDE' and sale_date >= v_start),
    'by_method', coalesce((select jsonb_agg(jsonb_build_object('method', method, 'total', total) order by total desc)
                             from (select method, sum(amount) as total from public.cash_transactions
                                    where status = 'VALIDE' and direction = 'IN' and occurred_at >= v_start
                                    group by method) m), '[]'::jsonb));
end $$;

-- Journal de caisse / journal financier : toutes méthodes, filtres, totaux de la sélection
create function public.list_cash_transactions(
  p_q         text default null,
  p_direction public.cash_direction default null,
  p_category  public.cash_category default null,
  p_method    public.payment_method default null,
  p_from      date default null,
  p_to        date default null,
  p_include_void boolean default true,
  p_limit     int default 20,
  p_offset    int default 0
) returns jsonb
language plpgsql stable security invoker set search_path = public, pg_temp as $$
declare
  v_pat  text := case when nullif(trim(coalesce(p_q, '')), '') is null then null else private.like_pattern(p_q) end;
  v_lim  int := private.clamp_limit(p_limit);
  v_off  int := greatest(coalesce(p_offset, 0), 0);
  v_rows jsonb;
  v_total bigint;
  v_in   numeric;
  v_out  numeric;
begin
  select coalesce(jsonb_agg(to_jsonb(r) - 'full_count' order by r.occurred_at desc, r.id), '[]'::jsonb),
         coalesce(max(r.full_count), 0)
    into v_rows, v_total
    from (
      select t.id, t.occurred_at, t.direction, t.category, t.amount, t.method, t.description,
             t.status, t.source_type, t.source_id, st.full_name as user_name,
             count(*) over () as full_count
        from public.cash_transactions t
        left join public.v_staff st on st.id = t.created_by
       where (p_direction is null or t.direction = p_direction)
         and (p_category  is null or t.category = p_category)
         and (p_method    is null or t.method = p_method)
         and (p_include_void or t.status = 'VALIDE')
         and (p_from is null or t.occurred_at >= private.day_start(p_from))
         and (p_to   is null or t.occurred_at <  private.day_start(p_to + 1))
         and (v_pat is null or t.description ilike v_pat escape '\')
       order by t.occurred_at desc, t.id
       limit v_lim offset v_off
    ) r;

  -- Totaux de toute la sélection (transactions valides uniquement)
  select coalesce(sum(case when direction = 'IN'  then amount end), 0),
         coalesce(sum(case when direction = 'OUT' then amount end), 0)
    into v_in, v_out
    from public.cash_transactions t
   where t.status = 'VALIDE'
     and (p_direction is null or t.direction = p_direction)
     and (p_category  is null or t.category = p_category)
     and (p_method    is null or t.method = p_method)
     and (p_from is null or t.occurred_at >= private.day_start(p_from))
     and (p_to   is null or t.occurred_at <  private.day_start(p_to + 1))
     and (v_pat is null or t.description ilike v_pat escape '\');

  return jsonb_build_object('rows', v_rows, 'total', v_total, 'sum_in', v_in, 'sum_out', v_out);
end $$;

-- ---------------------------------------------------------------------------
-- 8. Droits d'exécution : utilisateurs connectés uniquement
-- ---------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = any (array['list_payments','receipt_data','invoice_data','list_receivables',
                                  'pos_catalog','search_customers','cash_overview','list_cash_transactions'])
  loop
    execute format('revoke all on function %s from public, anon', r.sig);
    execute format('grant execute on function %s to authenticated', r.sig);
  end loop;
end $$;
