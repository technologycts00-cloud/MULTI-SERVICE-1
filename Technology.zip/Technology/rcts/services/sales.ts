import type { SupabaseClient } from "@supabase/supabase-js";
import { PAGE_SIZE, sanitizeSearch } from "@/lib/search";
import { haitiDayStartISO, nextDay } from "@/lib/utils";

export interface SaleRow {
  id: string;
  sale_number: string;
  sale_date: string;
  subtotal: number;
  discount: number;
  total: number;
  amount_paid: number;
  balance: number;
  payment_status: string;
  payment_method: string;
  status: "VALIDE" | "ANNULE";
  customers: { name: string } | null;
}

export interface SaleFilters {
  q?: string;
  status?: string;
  payment?: string;
  from?: string;
  to?: string;
  page: number;
}

export async function listSales(db: SupabaseClient, f: SaleFilters) {
  const from = (f.page - 1) * PAGE_SIZE;
  let query = db
    .from("sales")
    .select("id, sale_number, sale_date, subtotal, discount, total, amount_paid, balance, payment_status, payment_method, status, customers(name)", { count: "exact" });
  const q = sanitizeSearch(f.q);
  if (q) query = query.ilike("sale_number", `%${q}%`);
  if (f.status) query = query.eq("status", f.status);
  if (f.payment) query = query.eq("payment_status", f.payment);
  if (f.from) query = query.gte("sale_date", haitiDayStartISO(f.from));
  if (f.to) query = query.lt("sale_date", haitiDayStartISO(nextDay(f.to)));
  const { data, count, error } = await query.order("sale_date", { ascending: false }).order("id").range(from, from + PAGE_SIZE - 1);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const rows = ((data ?? []) as unknown as SaleRow[]).map((s) => ({
    ...s,
    subtotal: Number(s.subtotal), discount: Number(s.discount), total: Number(s.total), amount_paid: Number(s.amount_paid), balance: Number(s.balance),
  }));
  return { rows, total: count ?? 0 };
}

export interface SaleDetail {
  sale: SaleRow & { notes: string | null; void_reason: string | null; seller_name: string | null; customer_id: string | null };
  items: { id: string; description: string; quantity: number; unit_price: number; line_total: number }[];
  payments: { id: string; payment_number: string; amount: number; method: string; paid_at: string; status: string; receipt_id: string | null; receipt_number: string | null }[];
}

export async function getSaleDetail(db: SupabaseClient, id: string): Promise<SaleDetail | null> {
  const { data: s, error } = await db.from("sales").select("*, customers(name)").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!s) return null;
  const [items, pays, seller] = await Promise.all([
    db.from("sale_items").select("id, description, quantity, unit_price, line_total").eq("sale_id", id).order("created_at"),
    db.from("payments").select("id, payment_number, amount, method, paid_at, status, receipts(id, receipt_number)").eq("sale_id", id).order("paid_at", { ascending: false }),
    s.seller_id ? db.from("v_staff").select("full_name").eq("id", s.seller_id).maybeSingle() : Promise.resolve({ data: null }),
  ]);
  if (items.error) throw new Error(items.error.message);
  if (pays.error) throw new Error(pays.error.message);
  const num = (v: unknown) => Number(v);
  return {
    sale: {
      ...(s as SaleDetail["sale"]),
      subtotal: num(s.subtotal), discount: num(s.discount), total: num(s.total), amount_paid: num(s.amount_paid), balance: num(s.balance),
      seller_name: (seller.data as { full_name: string } | null)?.full_name ?? null,
    },
    items: (items.data ?? []).map((i) => ({ ...i, unit_price: num(i.unit_price), line_total: num(i.line_total) })),
    payments: ((pays.data ?? []) as unknown as (Omit<SaleDetail["payments"][number], "receipt_id" | "receipt_number"> & { receipts: { id: string; receipt_number: string }[] | { id: string; receipt_number: string } | null })[]).map((p) => {
      const r = Array.isArray(p.receipts) ? p.receipts[0] : p.receipts;
      return { id: p.id, payment_number: p.payment_number, amount: num(p.amount), method: p.method, paid_at: p.paid_at, status: p.status, receipt_id: r?.id ?? null, receipt_number: r?.receipt_number ?? null };
    }),
  };
}
