import type { SupabaseClient } from "@supabase/supabase-js";
import { pageRange, searchTerms } from "@/lib/search";


export interface ExpenseRow {
  id: string;
  expense_number: string;
  expense_date: string;
  description: string;
  amount: number;
  method: string;
  status: "VALIDE" | "ANNULE";
  receipt_url: string | null;
  expense_categories: { name: string } | null;
}

export async function listExpenseCategories(db: SupabaseClient, includeInactive = false) {
  let q = db.from("expense_categories").select("id, name, is_active");
  if (!includeInactive) q = q.eq("is_active", true);
  const { data, error } = await q.order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; name: string; is_active: boolean }[];
}

export async function listExpenses(db: SupabaseClient, f: { q?: string; category?: string; method?: string; status?: string; from?: string; to?: string; page: number }) {
  const { from, to } = pageRange(f.page);
  let query = db.from("expenses").select("id, expense_number, expense_date, description, amount, method, status, receipt_url, expense_categories(name)", { count: "exact" });
  for (const t of searchTerms(f.q)) query = query.or(`description.ilike.%${t}%,expense_number.ilike.%${t}%`);
  if (f.category) query = query.eq("category_id", f.category);
  if (f.method) query = query.eq("method", f.method);
  if (f.status) query = query.eq("status", f.status);
  if (f.from) query = query.gte("expense_date", f.from);
  if (f.to) query = query.lte("expense_date", f.to);
  const { data, count, error } = await query.order("expense_date", { ascending: false }).order("created_at", { ascending: false }).range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const rows = ((data ?? []) as unknown as ExpenseRow[]).map((e) => ({ ...e, amount: Number(e.amount) }));

  // Total de la sélection (dépenses valides)
  let sumQ = db.from("expenses").select("amount").eq("status", "VALIDE").limit(10000);
  for (const t of searchTerms(f.q)) sumQ = sumQ.or(`description.ilike.%${t}%,expense_number.ilike.%${t}%`);
  if (f.category) sumQ = sumQ.eq("category_id", f.category);
  if (f.method) sumQ = sumQ.eq("method", f.method);
  if (f.from) sumQ = sumQ.gte("expense_date", f.from);
  if (f.to) sumQ = sumQ.lte("expense_date", f.to);
  const { data: sums } = f.status === "ANNULE" ? { data: [] } : await sumQ;
  const sum = (sums ?? []).reduce((a, x) => a + Number(x.amount), 0);
  return { rows, total: count ?? 0, sum };
}

export async function getExpense(db: SupabaseClient, id: string) {
  const { data: e, error } = await db.from("expenses").select("*, expense_categories(name)").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!e) return null;
  const ids = [e.responsible_id, e.created_by, e.voided_by].filter((x): x is string => !!x);
  const names: Record<string, string> = {};
  if (ids.length) {
    const { data: st } = await db.from("v_staff").select("id, full_name").in("id", ids);
    for (const s of st ?? []) names[s.id as string] = (s.full_name as string) ?? "—";
  }
  return {
    expense: { ...(e as Record<string, unknown>), amount: Number(e.amount) } as unknown as ExpenseRow & {
      responsible_id: string | null; void_reason: string | null; voided_at: string | null; voided_by: string | null; created_at: string; created_by: string | null;
      expense_categories: { name: string } | null;
    },
    responsible: e.responsible_id ? (names[e.responsible_id] ?? null) : null,
    voidedBy: e.voided_by ? (names[e.voided_by] ?? null) : null,
  };
}

