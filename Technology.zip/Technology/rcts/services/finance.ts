import type { SupabaseClient } from "@supabase/supabase-js";

export interface FinanceSummary {
  income: number;
  expenses: number;
  balance: number;
  cash_on_hand: number;
  income_by_category: { category: string; total: number }[];
  income_by_method: { method: string; total: number }[];
  expenses_by_category: { category: string; total: number }[];
  monthly: { month: string; income: number; expenses: number }[];
  receivables: { formations: number; ventes: number; services: number; total: number; count: number };
  payables: { total: number; count: number };
}

const n = (v: unknown) => Number(v ?? 0);

export async function financeSummary(db: SupabaseClient, from?: string, to?: string): Promise<FinanceSummary> {
  const { data, error } = await db.rpc("finance_summary", { p_from: from ?? null, p_to: to ?? null });
  if (error) throw new Error(error.message);
  const d = data as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
  return {
    income: n(d.income), expenses: n(d.expenses), balance: n(d.balance), cash_on_hand: n(d.cash_on_hand),
    income_by_category: d.income_by_category.map((x: { category: string; total: number }) => ({ ...x, total: n(x.total) })),
    income_by_method: d.income_by_method.map((x: { method: string; total: number }) => ({ ...x, total: n(x.total) })),
    expenses_by_category: d.expenses_by_category.map((x: { category: string; total: number }) => ({ ...x, total: n(x.total) })),
    monthly: d.monthly.map((x: { month: string; income: number; expenses: number }) => ({ month: x.month, income: n(x.income), expenses: n(x.expenses) })),
    receivables: { formations: n(d.receivables.formations), ventes: n(d.receivables.ventes), services: n(d.receivables.services), total: n(d.receivables.total), count: n(d.receivables.count) },
    payables: { total: n(d.payables.total), count: n(d.payables.count) },
  };
}
