import type { SupabaseClient } from "@supabase/supabase-js";
import { ilikeOr, pageRange, searchTerms } from "@/lib/search";
import type { CertificatesRow, EnrollmentsRow, PaymentsRow, ReceiptsRow, StudentsRow, TrainingsRow } from "@/types/db";

const LIST_COLUMNS =
  "id, enrollment_number, enrolled_on, training_price, registration_fee, discount, amount_paid, total_due, balance, payment_status, status, " +
  "students!inner(id, first_name, last_name, student_code), trainings!inner(id, name)";

export interface EnrollmentListRow {
  id: string;
  enrollment_number: string;
  enrolled_on: string;
  discount: number;
  amount_paid: number;
  total_due: number | null;
  balance: number | null;
  payment_status: string | null;
  status: string;
  students: { id: string; first_name: string; last_name: string; student_code: string };
  trainings: { id: string; name: string };
}

export interface EnrollmentFilters {
  q?: string;
  status?: string;
  training?: string;
  /** "impaye" = solde restant à payer */
  payment?: string;
  page: number;
}

export async function listEnrollments(db: SupabaseClient, f: EnrollmentFilters) {
  const { from, to } = pageRange(f.page);
  let query = db.from("enrollments").select(LIST_COLUMNS, { count: "exact" });

  const q = (f.q ?? "").trim();
  if (/^ins-/i.test(q)) {
    query = query.ilike("enrollment_number", `%${q.replace(/[^\w-]/g, "")}%`);
  } else {
    for (const term of searchTerms(q)) {
      query = query.or(ilikeOr(["first_name", "last_name", "student_code"], term)!, { referencedTable: "students" });
    }
  }
  if (f.status) query = query.eq("status", f.status);
  if (f.training) query = query.eq("training_id", f.training);
  if (f.payment === "impaye") query = query.gt("balance", 0).neq("status", "ANNULEE");

  const { data, count, error } = await query.order("created_at", { ascending: false }).order("id").range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  return { rows: (data ?? []) as unknown as EnrollmentListRow[], total: count ?? 0 };
}

export interface EnrollmentDetail {
  enrollment: EnrollmentsRow;
  student: StudentsRow | null;
  training: TrainingsRow | null;
  /** null = rôle sans accès aux paiements */
  payments: PaymentsRow[] | null;
  receipts: Record<string, ReceiptsRow>;
  certificate: CertificatesRow | null;
}

export async function getEnrollmentDetail(
  db: SupabaseClient,
  id: string,
  withPayments: boolean,
): Promise<EnrollmentDetail | null> {
  const { data: e, error } = await db
    .from("enrollments")
    .select("*, students(*), trainings(*)")
    .eq("id", id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!e) return null;

  const { students, trainings, ...enrollment } = e as EnrollmentsRow & {
    students: StudentsRow | null;
    trainings: TrainingsRow | null;
  };

  const [pay, cert] = await Promise.all([
    withPayments
      ? db.from("payments").select("*").eq("enrollment_id", id).order("paid_at", { ascending: false })
      : Promise.resolve(null),
    db.from("certificates").select("*").eq("enrollment_id", id).maybeSingle(),
  ]);
  if (pay?.error) throw new Error(pay.error.message);

  const payments = withPayments ? ((pay?.data ?? []) as PaymentsRow[]) : null;
  const receipts: Record<string, ReceiptsRow> = {};
  if (payments && payments.length > 0) {
    const { data, error: re } = await db.from("receipts").select("*").in("payment_id", payments.map((p) => p.id));
    if (re) throw new Error(re.message);
    for (const r of (data ?? []) as ReceiptsRow[]) receipts[r.payment_id] = r;
  }

  return {
    enrollment: enrollment as EnrollmentsRow,
    student: students,
    training: trainings,
    payments,
    receipts,
    certificate: (cert.data as CertificatesRow | null) ?? null,
  };
}

