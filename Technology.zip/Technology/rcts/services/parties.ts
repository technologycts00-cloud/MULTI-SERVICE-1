import type { SupabaseClient } from "@supabase/supabase-js";
import { ilikeOr, pageRange, searchTerms } from "@/lib/search";

const num = (v: unknown) => Number(v ?? 0);

// ───────────── Clients ─────────────
export interface CustomerRow {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  customer_type: string;
  is_archived: boolean;
  total: number;
  balance: number;
}

export async function listCustomers(db: SupabaseClient, f: { q?: string; type?: string; archived: boolean; debt: boolean; page: number }) {
  const { from, to } = pageRange(f.page);
  let query = db.from("customers").select("id, name, phone, email, customer_type, is_archived", { count: "exact" }).eq("is_archived", f.archived);
  for (const t of searchTerms(f.q)) query = query.or(ilikeOr(["name", "phone", "email"], t)!);
  if (f.type) query = query.eq("customer_type", f.type);
  if (f.debt) {
    const { data: d } = await db.from("v_customer_balances").select("customer_id").gt("balance", 0);
    const ids = (d ?? []).map((x) => x.customer_id as string);
    query = query.in("id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
  }
  const { data, count, error } = await query.order("name").order("id").range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const ids = (data ?? []).map((c) => c.id as string);
  const bal: Record<string, { total: number; balance: number }> = {};
  if (ids.length) {
    const { data: b } = await db.from("v_customer_balances").select("customer_id, total, balance").in("customer_id", ids);
    for (const x of b ?? []) bal[x.customer_id as string] = { total: num(x.total), balance: num(x.balance) };
  }
  const rows: CustomerRow[] = (data ?? []).map((c) => ({ ...(c as Omit<CustomerRow, "total" | "balance">), total: bal[c.id as string]?.total ?? 0, balance: bal[c.id as string]?.balance ?? 0 }));
  return { rows, total: count ?? 0 };
}

export async function getCustomer(db: SupabaseClient, id: string) {
  const { data, error } = await db.from("customers").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return null;
  const [bal, sales, orders] = await Promise.all([
    db.from("v_customer_balances").select("total, total_paid, balance").eq("customer_id", id).maybeSingle(),
    db.from("sales").select("id, sale_number, sale_date, total, balance, status").eq("customer_id", id).order("sale_date", { ascending: false }).limit(30),
    db.from("service_orders").select("id, order_number, order_date, total, balance, status, services(name)").eq("customer_id", id).order("order_date", { ascending: false }).limit(30),
  ]);
  return {
    customer: data as Record<string, unknown> & { id: string; name: string; phone: string | null; email: string | null; address: string | null; customer_type: string; notes: string | null; is_archived: boolean; created_at: string },
    totals: { total: num(bal.data?.total), paid: num(bal.data?.total_paid), balance: num(bal.data?.balance) },
    sales: (sales.data ?? []).map((s) => ({ ...s, total: num(s.total), balance: num(s.balance) })) as { id: string; sale_number: string; sale_date: string; total: number; balance: number; status: string }[],
    orders: (orders.data ?? []).map((o) => ({ ...o, total: num(o.total), balance: num(o.balance) })) as unknown as { id: string; order_number: string; order_date: string; total: number; balance: number; status: string; services: { name: string } | null }[],
  };
}

export async function customerOptions(db: SupabaseClient) {
  const { data, error } = await db.from("customers").select("id, name, phone").eq("is_archived", false).order("name").limit(500);
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; name: string; phone: string | null }[];
}

// ───────────── Services ─────────────
export interface ServiceRow { id: string; name: string; category: string | null; description: string | null; unit_price: number; unit: string; is_active: boolean }

export async function listServices(db: SupabaseClient, opts: { q?: string; inactive: boolean }) {
  let query = db.from("services").select("id, name, category, description, unit_price, unit, is_active").eq("is_active", !opts.inactive);
  for (const t of searchTerms(opts.q)) query = query.or(ilikeOr(["name", "category"], t)!);
  const { data, error } = await query.order("name").limit(300);
  if (error) throw new Error(error.message);
  return (data ?? []).map((s) => ({ ...s, unit_price: num(s.unit_price) })) as ServiceRow[];
}

export async function getService(db: SupabaseClient, id: string) {
  const { data, error } = await db.from("services").select("id, name, category, description, unit_price, unit, is_active").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return data ? ({ ...data, unit_price: num(data.unit_price) } as ServiceRow) : null;
}

export interface OrderRow {
  id: string; order_number: string; order_date: string; due_date: string | null; quantity: number; unit_price: number;
  total: number; amount_paid: number; balance: number; status: string;
  customers: { name: string } | null; services: { name: string } | null;
}

export async function listOrders(db: SupabaseClient, f: { q?: string; status?: string; unpaid: boolean; page: number }) {
  const { from, to } = pageRange(f.page);
  let query = db.from("service_orders").select("id, order_number, order_date, due_date, quantity, unit_price, total, amount_paid, balance, status, customers(name), services(name)", { count: "exact" });
  const t = searchTerms(f.q)[0];
  if (t) query = query.ilike("order_number", `%${t}%`);
  if (f.status) query = query.eq("status", f.status);
  if (f.unpaid) query = query.gt("balance", 0).neq("status", "ANNULE");
  const { data, count, error } = await query.order("order_date", { ascending: false }).order("created_at", { ascending: false }).range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const rows = ((data ?? []) as unknown as OrderRow[]).map((o) => ({ ...o, unit_price: num(o.unit_price), total: num(o.total), amount_paid: num(o.amount_paid), balance: num(o.balance) }));
  return { rows, total: count ?? 0 };
}

export async function getOrder(db: SupabaseClient, id: string) {
  const { data: o, error } = await db.from("service_orders").select("*, customers(id, name, phone), services(name, unit)").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!o) return null;
  const [pays, resp] = await Promise.all([
    db.from("payments").select("id, payment_number, amount, method, paid_at, status, receipts(id, receipt_number)").eq("service_order_id", id).order("paid_at", { ascending: false }),
    o.responsible_id ? db.from("v_staff").select("full_name").eq("id", o.responsible_id).maybeSingle() : Promise.resolve({ data: null }),
  ]);
  const payments = ((pays.data ?? []) as unknown as { id: string; payment_number: string; amount: number; method: string; paid_at: string; status: string; receipts: { id: string; receipt_number: string }[] | { id: string; receipt_number: string } | null }[]).map((p) => {
    const r = Array.isArray(p.receipts) ? p.receipts[0] : p.receipts;
    return { id: p.id, payment_number: p.payment_number, amount: num(p.amount), method: p.method, paid_at: p.paid_at, status: p.status, receipt_id: r?.id ?? null, receipt_number: r?.receipt_number ?? null };
  });
  return {
    order: { ...(o as Record<string, unknown>), unit_price: num(o.unit_price), total: num(o.total), amount_paid: num(o.amount_paid), balance: num(o.balance) } as unknown as OrderRow & {
      comment: string | null; responsible_id: string | null; customer_id: string; customers: { id: string; name: string; phone: string | null } | null; services: { name: string; unit: string } | null;
    },
    responsible: (resp.data as { full_name: string } | null)?.full_name ?? null,
    payments,
  };
}

export async function staffOptions(db: SupabaseClient) {
  const { data } = await db.from("v_staff").select("id, full_name").order("full_name");
  return (data ?? []) as { id: string; full_name: string }[];
}

// ───────────── Fournisseurs ─────────────
export interface SupplierRow { id: string; name: string; company: string | null; phone: string | null; email: string | null; is_archived: boolean; total_purchased: number; amount_due: number }

export async function listSuppliers(db: SupabaseClient, f: { q?: string; archived: boolean; debt: boolean; page: number }) {
  const { from, to } = pageRange(f.page);
  let query = db.from("suppliers").select("id, name, company, phone, email, is_archived", { count: "exact" }).eq("is_archived", f.archived);
  for (const t of searchTerms(f.q)) query = query.or(ilikeOr(["name", "company", "phone", "products_supplied"], t)!);
  if (f.debt) {
    const { data: d } = await db.from("v_supplier_balances").select("supplier_id").gt("amount_due", 0);
    const ids = (d ?? []).map((x) => x.supplier_id as string);
    query = query.in("id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
  }
  const { data, count, error } = await query.order("name").order("id").range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const ids = (data ?? []).map((s) => s.id as string);
  const bal: Record<string, { p: number; d: number }> = {};
  if (ids.length) {
    const { data: b } = await db.from("v_supplier_balances").select("supplier_id, total_purchased, amount_due").in("supplier_id", ids);
    for (const x of b ?? []) bal[x.supplier_id as string] = { p: num(x.total_purchased), d: num(x.amount_due) };
  }
  const rows: SupplierRow[] = (data ?? []).map((s) => ({ ...(s as Omit<SupplierRow, "total_purchased" | "amount_due">), total_purchased: bal[s.id as string]?.p ?? 0, amount_due: bal[s.id as string]?.d ?? 0 }));
  return { rows, total: count ?? 0 };
}

export interface PurchaseRow { id: string; purchase_number: string; purchase_date: string; total_amount: number; amount_paid: number; balance: number; status: string }

export async function getSupplier(db: SupabaseClient, id: string) {
  const { data, error } = await db.from("suppliers").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return null;
  const [bal, purchases] = await Promise.all([
    db.from("v_supplier_balances").select("total_purchased, total_paid, amount_due").eq("supplier_id", id).maybeSingle(),
    db.from("purchases").select("id, purchase_number, purchase_date, total_amount, amount_paid, balance, status").eq("supplier_id", id).order("purchase_date", { ascending: false }).order("created_at", { ascending: false }).limit(50),
  ]);
  return {
    supplier: data as Record<string, unknown> & { id: string; name: string; company: string | null; phone: string | null; email: string | null; address: string | null; products_supplied: string | null; notes: string | null; is_archived: boolean },
    totals: { purchased: num(bal.data?.total_purchased), paid: num(bal.data?.total_paid), due: num(bal.data?.amount_due) },
    purchases: (purchases.data ?? []).map((p) => ({ ...p, total_amount: num(p.total_amount), amount_paid: num(p.amount_paid), balance: num(p.balance) })) as PurchaseRow[],
  };
}

export async function getPurchase(db: SupabaseClient, id: string) {
  const { data: p, error } = await db.from("purchases").select("*, suppliers(id, name, company)").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!p) return null;
  const [items, pays] = await Promise.all([
    db.from("purchase_items").select("id, quantity, unit_cost, line_total, products(name, code)").eq("purchase_id", id),
    db.from("supplier_payments").select("id, payment_number, amount, method, reference, paid_at, status").eq("purchase_id", id).order("paid_at", { ascending: false }),
  ]);
  return {
    purchase: { ...(p as Record<string, unknown>), total_amount: num(p.total_amount), amount_paid: num(p.amount_paid), balance: num(p.balance) } as unknown as PurchaseRow & { notes: string | null; suppliers: { id: string; name: string; company: string | null } | null },
    items: ((items.data ?? []) as unknown as { id: string; quantity: number; unit_cost: number; line_total: number; products: { name: string; code: string } | null }[]).map((i) => ({ ...i, unit_cost: num(i.unit_cost), line_total: num(i.line_total) })),
    payments: (pays.data ?? []).map((x) => ({ ...x, amount: num(x.amount) })) as { id: string; payment_number: string; amount: number; method: string; reference: string | null; paid_at: string; status: string }[],
  };
}

export async function productCostOptions(db: SupabaseClient) {
  const { data, error } = await db.from("products").select("id, code, name, purchase_price").eq("status", "ACTIF").order("name").limit(1000);
  if (error) throw new Error(error.message);
  return (data ?? []).map((p) => ({ id: p.id as string, code: p.code as string, name: p.name as string, purchase_price: num(p.purchase_price) }));
}
