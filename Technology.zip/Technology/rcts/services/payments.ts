import type { SupabaseClient } from "@supabase/supabase-js";

export interface PaymentRow {
  id: string;
  payment_number: string;
  kind: "INSCRIPTION" | "VENTE" | "SERVICE";
  amount: number;
  method: string;
  reference: string | null;
  description: string | null;
  paid_at: string;
  status: "VALIDE" | "ANNULE";
  void_reason: string | null;
  enrollment_id: string | null;
  sale_id: string | null;
  service_order_id: string | null;
  payer_name: string;
  target_number: string | null;
  receipt_id: string | null;
  receipt_number: string | null;
  user_name: string | null;
}

export interface PaymentFilters {
  q?: string;
  kind?: string;
  method?: string;
  status?: string;
  from?: string;
  to?: string;
  page: number;
}

import { PAGE_SIZE } from "@/lib/search";

export async function listPayments(db: SupabaseClient, f: PaymentFilters) {
  const { data, error } = await db.rpc("list_payments", {
    p_q: f.q ?? null,
    p_kind: f.kind ?? null,
    p_method: f.method ?? null,
    p_status: f.status ?? null,
    p_from: f.from ?? null,
    p_to: f.to ?? null,
    p_limit: PAGE_SIZE,
    p_offset: (f.page - 1) * PAGE_SIZE,
  });
  if (error) throw new Error(error.message);
  const r = data as { rows: PaymentRow[]; total: number };
  return { rows: r.rows.map((x) => ({ ...x, amount: Number(x.amount) })), total: Number(r.total) };
}

export interface Receivable {
  kind: "INSCRIPTION" | "VENTE" | "SERVICE";
  id: string;
  number: string;
  payer_name: string;
  description: string;
  total: number;
  amount_paid: number;
  balance: number;
}

export async function listReceivables(db: SupabaseClient, q?: string, limit = 30): Promise<Receivable[]> {
  const { data, error } = await db.rpc("list_receivables", { p_q: q ?? null, p_limit: limit });
  if (error) throw new Error(error.message);
  return (data as Receivable[]).map((r) => ({ ...r, total: Number(r.total), amount_paid: Number(r.amount_paid), balance: Number(r.balance) }));
}

export interface CatalogItem {
  type: "product" | "service";
  id: string;
  name: string;
  code: string | null;
  category: string | null;
  price: number;
  stock: number | null;
  stock_state: string | null;
  min_stock: number | null;
}

export async function posCatalog(db: SupabaseClient, q?: string): Promise<CatalogItem[]> {
  const { data, error } = await db.rpc("pos_catalog", { p_q: q ?? null, p_limit: 60 });
  if (error) throw new Error(error.message);
  return (data as CatalogItem[]).map((i) => ({
    ...i,
    price: Number(i.price),
    stock: i.stock === null ? null : Number(i.stock),
  }));
}

export interface CustomerOption {
  id: string;
  name: string;
  phone: string | null;
  customer_type: string;
  balance: number;
}

export async function searchCustomers(db: SupabaseClient, q: string): Promise<CustomerOption[]> {
  const { data, error } = await db.rpc("search_customers", { p_q: q, p_limit: 8 });
  if (error) throw new Error(error.message);
  return (data as CustomerOption[]).map((c) => ({ ...c, balance: Number(c.balance) }));
}

export interface CashOverview {
  cash_on_hand: number;
  today_in: number;
  today_out: number;
  today_sales: number;
  by_method: { method: string; total: number }[];
}

export async function cashOverview(db: SupabaseClient): Promise<CashOverview> {
  const { data, error } = await db.rpc("cash_overview");
  if (error) throw new Error(error.message);
  const d = data as CashOverview;
  return {
    cash_on_hand: Number(d.cash_on_hand),
    today_in: Number(d.today_in),
    today_out: Number(d.today_out),
    today_sales: Number(d.today_sales),
    by_method: d.by_method.map((m) => ({ method: m.method, total: Number(m.total) })),
  };
}

export interface CashTx {
  id: string;
  occurred_at: string;
  direction: "IN" | "OUT";
  category: string;
  amount: number;
  method: string;
  description: string | null;
  status: "VALIDE" | "ANNULE";
  source_type: string | null;
  source_id: string | null;
  user_name: string | null;
}

export interface CashFilters {
  q?: string;
  direction?: string;
  category?: string;
  method?: string;
  from?: string;
  to?: string;
  page: number;
}

export async function listCash(db: SupabaseClient, f: CashFilters) {
  const { data, error } = await db.rpc("list_cash_transactions", {
    p_q: f.q ?? null,
    p_direction: f.direction ?? null,
    p_category: f.category ?? null,
    p_method: f.method ?? null,
    p_from: f.from ?? null,
    p_to: f.to ?? null,
    p_include_void: true,
    p_limit: PAGE_SIZE,
    p_offset: (f.page - 1) * PAGE_SIZE,
  });
  if (error) throw new Error(error.message);
  const r = data as { rows: CashTx[]; total: number; sum_in: number; sum_out: number };
  return {
    rows: r.rows.map((x) => ({ ...x, amount: Number(x.amount) })),
    total: Number(r.total),
    sumIn: Number(r.sum_in),
    sumOut: Number(r.sum_out),
  };
}
