import type { SupabaseClient } from "@supabase/supabase-js";

export interface OrgInfo {
  org_name?: string;
  org_legal_name?: string;
  phone?: string;
  email?: string;
  address?: string;
  logo_url?: string;
  currency?: string;
  invoice_footer?: string;
}

export interface DocLine {
  description: string;
  quantity: number;
  unit_price: number;
  line_total: number;
}

export interface ReceiptData {
  org: OrgInfo;
  receipt: {
    id: string;
    receipt_number: string;
    issued_at: string;
    payer_name: string;
    description: string | null;
    amount: number;
    method: string;
    total_due: number;
    balance_after: number;
    status: "VALIDE" | "ANNULE";
  };
  payment: {
    payment_number: string;
    kind: "INSCRIPTION" | "VENTE" | "SERVICE";
    reference: string | null;
    paid_at: string;
    status: "VALIDE" | "ANNULE";
    void_reason: string | null;
  };
  issuer: string | null;
  context: {
    reference_number?: string;
    label?: string;
    student_code?: string;
    items?: DocLine[];
    discount?: number;
    subtotal?: number;
  };
}

export interface InvoiceData {
  org: OrgInfo;
  invoice: {
    id: string;
    invoice_number: string;
    kind: "INSCRIPTION" | "VENTE" | "SERVICE";
    client_name: string;
    description: string | null;
    total: number;
    issued_at: string;
    due_date: string | null;
    notes: string | null;
    status: "VALIDE" | "ANNULE";
  };
  client: { name?: string; phone?: string | null; address?: string | null; code?: string };
  lines: DocLine[];
  payments: { payment_number: string; paid_at: string; method: string; amount: number }[];
  issuer: string | null;
  totals: { discount: number; total: number; paid: number; balance: number };
}

export async function getReceipt(db: SupabaseClient, id: string): Promise<ReceiptData | null> {
  const { data, error } = await db.rpc("receipt_data", { p_receipt_id: id });
  if (error) throw new Error(error.message);
  return (data as ReceiptData | null) ?? null;
}

export async function getInvoice(db: SupabaseClient, id: string): Promise<InvoiceData | null> {
  const { data, error } = await db.rpc("invoice_data", { p_invoice_id: id });
  if (error) throw new Error(error.message);
  return (data as InvoiceData | null) ?? null;
}
