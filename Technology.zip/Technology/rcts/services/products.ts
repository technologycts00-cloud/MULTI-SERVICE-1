import type { SupabaseClient } from "@supabase/supabase-js";
import { ilikeOr, pageRange, searchTerms } from "@/lib/search";
import type { ProductsRow, StockMovementsRow } from "@/types/db";

export interface ProductListRow {
  id: string;
  code: string;
  name: string;
  sale_price: number;
  purchase_price: number;
  current_stock: number;
  min_stock: number;
  stock_state: string | null;
  status: string;
  product_categories: { name: string } | null;
}

export interface ProductFilters {
  q?: string;
  category?: string;
  state?: string;
  status?: string;
  page: number;
}

const COLS = "id, code, name, sale_price, purchase_price, current_stock, min_stock, stock_state, status, product_categories(name)";

export async function listProducts(db: SupabaseClient, f: ProductFilters) {
  const { from, to } = pageRange(f.page);
  let query = db.from("products").select(COLS, { count: "exact" });
  for (const t of searchTerms(f.q)) query = query.or(ilikeOr(["name", "code"], t)!);
  if (f.category) query = query.eq("category_id", f.category);
  if (f.state) query = query.eq("stock_state", f.state);
  query = query.eq("status", f.status ?? "ACTIF");
  const { data, count, error } = await query.order("name").order("id").range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const rows = ((data ?? []) as unknown as ProductListRow[]).map((p) => ({
    ...p,
    sale_price: Number(p.sale_price),
    purchase_price: Number(p.purchase_price),
  }));
  return { rows, total: count ?? 0 };
}

export async function listCategories(db: SupabaseClient) {
  const { data, error } = await db.from("product_categories").select("id, name").order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; name: string }[];
}

export async function listSupplierOptions(db: SupabaseClient) {
  const { data, error } = await db.from("suppliers").select("id, name").eq("is_archived", false).order("name");
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; name: string }[];
}

export interface MovementRow extends Pick<StockMovementsRow, "id" | "movement_type" | "quantity_change" | "stock_before" | "stock_after" | "reason" | "reference" | "created_at"> {
  products?: { name: string; code: string } | null;
  user_name: string | null;
}

export async function listMovements(db: SupabaseClient, opts: { productId?: string; type?: string; page: number; limit?: number }) {
  const limit = opts.limit ?? 20;
  const from = (opts.page - 1) * limit;
  let query = db
    .from("stock_movements")
    .select("id, movement_type, quantity_change, stock_before, stock_after, reason, reference, created_at, created_by, products(name, code)", { count: "exact" });
  if (opts.productId) query = query.eq("product_id", opts.productId);
  if (opts.type) query = query.eq("movement_type", opts.type);
  const { data, count, error } = await query.order("created_at", { ascending: false }).order("id").range(from, from + limit - 1);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  const raw = (data ?? []) as unknown as (MovementRow & { created_by: string | null })[];
  const ids = [...new Set(raw.map((m) => m.created_by).filter((x): x is string => !!x))];
  const names: Record<string, string> = {};
  if (ids.length) {
    const { data: st } = await db.from("v_staff").select("id, full_name").in("id", ids);
    for (const s of st ?? []) names[s.id as string] = (s.full_name as string) ?? "—";
  }
  return { rows: raw.map((m) => ({ ...m, user_name: m.created_by ? (names[m.created_by] ?? null) : null })), total: count ?? 0 };
}

export async function getProduct(db: SupabaseClient, id: string): Promise<(ProductsRow & { product_categories: { name: string } | null; suppliers: { name: string } | null }) | null> {
  const { data, error } = await db.from("products").select("*, product_categories(name), suppliers(name)").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return data as never;
}

export async function stockSummary(db: SupabaseClient) {
  const { data, error } = await db.from("products").select("stock_state, current_stock, purchase_price, sale_price").eq("status", "ACTIF");
  if (error) throw new Error(error.message);
  let ok = 0, low = 0, out = 0, valueCost = 0, valueSale = 0;
  for (const p of data ?? []) {
    if (p.stock_state === "RUPTURE") out++;
    else if (p.stock_state === "FAIBLE") low++;
    else ok++;
    valueCost += Number(p.current_stock) * Number(p.purchase_price);
    valueSale += Number(p.current_stock) * Number(p.sale_price);
  }
  return { ok, low, out, valueCost, valueSale };
}

export async function searchProductOptions(db: SupabaseClient, q: string) {
  let query = db.from("products").select("id, code, name, current_stock").eq("status", "ACTIF");
  for (const t of searchTerms(q)) query = query.or(ilikeOr(["name", "code"], t)!);
  const { data, error } = await query.order("name").limit(10);
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; code: string; name: string; current_stock: number }[];
}
