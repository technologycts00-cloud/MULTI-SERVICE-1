import type { SupabaseClient } from "@supabase/supabase-js";
import { pageRange, searchTerms, ilikeOr } from "@/lib/search";
import type { TrainingsRow } from "@/types/db";

/** Inscriptions qui occupent une place (une annulée ou abandonnée libère la place). */
export const SEAT_STATUSES = ["ACTIVE", "TERMINEE"];

const COLUMNS =
  "id, name, description, duration_value, duration_unit, price, registration_fee, max_students, start_date, end_date, schedule, trainer_id, status, is_archived";

export type TrainingListRow = Pick<
  TrainingsRow,
  | "id" | "name" | "description" | "duration_value" | "duration_unit" | "price" | "registration_fee"
  | "max_students" | "start_date" | "end_date" | "schedule" | "trainer_id" | "status" | "is_archived"
> & { enrolled: number; trainer_name: string | null };

type RawTraining = Omit<TrainingListRow, "enrolled" | "trainer_name"> & { enrollments: { count: number }[] | null };

async function trainerNames(db: SupabaseClient, ids: (string | null)[]): Promise<Record<string, string>> {
  const uniq = [...new Set(ids.filter((x): x is string => !!x))];
  if (uniq.length === 0) return {};
  const { data } = await db.from("v_staff").select("id, full_name").in("id", uniq);
  return Object.fromEntries((data ?? []).map((s) => [s.id as string, (s.full_name as string) ?? "—"]));
}

async function withExtras(db: SupabaseClient, raw: RawTraining[]): Promise<TrainingListRow[]> {
  const names = await trainerNames(db, raw.map((t) => t.trainer_id));
  return raw.map(({ enrollments, ...t }) => ({
    ...t,
    enrolled: enrollments?.[0]?.count ?? 0,
    trainer_name: t.trainer_id ? (names[t.trainer_id] ?? null) : null,
  }));
}

export interface TrainingFilters {
  q?: string;
  status?: string;
  archived: boolean;
  page: number;
}

export async function listTrainings(db: SupabaseClient, f: TrainingFilters) {
  const { from, to } = pageRange(f.page);
  let query = db
    .from("trainings")
    .select(`${COLUMNS}, enrollments(count)`, { count: "exact" })
    .in("enrollments.status", SEAT_STATUSES)
    .eq("is_archived", f.archived);
  for (const term of searchTerms(f.q)) query = query.or(ilikeOr(["name"], term)!);
  if (f.status) query = query.eq("status", f.status);

  const { data, count, error } = await query.order("name").order("id").range(from, to);
  if (error && error.code !== "PGRST103") throw new Error(error.message);
  return { rows: await withExtras(db, (data ?? []) as unknown as RawTraining[]), total: count ?? 0 };
}

export interface RosterRow {
  id: string;
  enrollment_number: string;
  status: string;
  enrolled_on: string;
  total_due: number | null;
  amount_paid: number;
  balance: number | null;
  students: { id: string; student_code: string; first_name: string; last_name: string; phone: string | null; status: string } | null;
}

export interface TrainingDetail {
  training: TrainingsRow;
  trainerName: string | null;
  roster: RosterRow[];
  enrolled: number;
}

export async function getTrainingDetail(db: SupabaseClient, id: string): Promise<TrainingDetail | null> {
  const { data: training, error } = await db.from("trainings").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!training) return null;

  const { data: roster, error: re } = await db
    .from("enrollments")
    .select(
      "id, enrollment_number, status, enrolled_on, total_due, amount_paid, balance, students(id, student_code, first_name, last_name, phone, status)",
    )
    .eq("training_id", id)
    .order("created_at");
  if (re) throw new Error(re.message);

  const rows = (roster ?? []) as unknown as RosterRow[];
  const names = await trainerNames(db, [training.trainer_id]);
  return {
    training: training as TrainingsRow,
    trainerName: training.trainer_id ? (names[training.trainer_id] ?? null) : null,
    roster: rows,
    enrolled: rows.filter((r) => SEAT_STATUSES.includes(r.status)).length,
  };
}

export interface TrainerOption {
  id: string;
  full_name: string | null;
  role: string;
}

export async function listTrainers(db: SupabaseClient): Promise<TrainerOption[]> {
  const { data, error } = await db
    .from("v_staff")
    .select("id, full_name, role")
    .in("role", ["FORMATEUR", "ADMIN"])
    .order("full_name");
  if (error) throw new Error(error.message);
  return (data ?? []) as TrainerOption[];
}

export interface OpenTraining {
  id: string;
  name: string;
  price: number;
  registration_fee: number;
  max_students: number | null;
  enrolled: number;
  /** null = places illimitées */
  places_left: number | null;
}

/** Formations qui acceptent des inscriptions (planifiées ou en cours, non archivées). */
export async function listOpenTrainings(db: SupabaseClient): Promise<OpenTraining[]> {
  const { data, error } = await db
    .from("trainings")
    .select("id, name, price, registration_fee, max_students, enrollments(count)")
    .in("enrollments.status", SEAT_STATUSES)
    .eq("is_archived", false)
    .in("status", ["PLANIFIEE", "EN_COURS"])
    .order("name");
  if (error) throw new Error(error.message);

  return ((data ?? []) as unknown as (Omit<OpenTraining, "enrolled" | "places_left"> & { enrollments: { count: number }[] | null })[]).map(
    ({ enrollments, ...t }) => {
      const enrolled = enrollments?.[0]?.count ?? 0;
      return {
        ...t,
        price: Number(t.price),
        registration_fee: Number(t.registration_fee),
        enrolled,
        places_left: t.max_students === null ? null : Math.max(0, t.max_students - enrolled),
      };
    },
  );
}

/** Nombre d'inscriptions qui occupent une place (contrôle de capacité à la modification). */
export async function countSeats(db: SupabaseClient, trainingId: string): Promise<number> {
  const { count, error } = await db
    .from("enrollments")
    .select("id", { count: "exact", head: true })
    .eq("training_id", trainingId)
    .in("status", SEAT_STATUSES);
  if (error) throw new Error(error.message);
  return count ?? 0;
}

