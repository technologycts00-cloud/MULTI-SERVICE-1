import type { SupabaseClient } from "@supabase/supabase-js";
import type { StudentListRow } from "@/components/eleves/students-table";
import type { CertificateWithTraining, EnrollmentWithTraining } from "@/components/eleves/student-profile";
import { ilikeOr, pageRange, searchTerms } from "@/lib/search";
import type { PaymentsRow, ReceiptsRow, StudentsRow } from "@/types/db";

// Les fonctions reçoivent le client Supabase de l'utilisateur : la RLS s'applique toujours.
// Elles lèvent une Error si la base répond par une erreur (page d'erreur Next.js).

const SEARCH_COLUMNS = ["first_name", "last_name", "student_code", "phone"];
const LIST_COLUMNS = "id, student_code, first_name, last_name, phone, status, enrolled_on, is_archived";

export interface StudentFilters {
  q?: string;
  status?: string;
  archived: boolean;
  page: number;
}

export async function listStudents(db: SupabaseClient, f: StudentFilters, withBalances: boolean) {
  const { from, to } = pageRange(f.page);
  let query = db.from("students").select(LIST_COLUMNS, { count: "exact" }).eq("is_archived", f.archived);
  for (const term of searchTerms(f.q)) query = query.or(ilikeOr(SEARCH_COLUMNS, term)!);
  if (f.status) query = query.eq("status", f.status);

  const { data, count, error } = await query
    .order("last_name")
    .order("first_name")
    .order("id")
    .range(from, to);
  // PGRST103 : page demandée au-delà du dernier résultat
  if (error && error.code !== "PGRST103") throw new Error(error.message);

  const rows = (data ?? []) as StudentListRow[];
  let balances: Record<string, number> | undefined;
  if (withBalances) {
    balances = {};
    if (rows.length > 0) {
      const { data: b, error: be } = await db
        .from("v_student_balances")
        .select("student_id, balance")
        .in("student_id", rows.map((r) => r.id));
      if (be) throw new Error(be.message);
      for (const x of b ?? []) balances[x.student_id as string] = Number(x.balance);
    }
  }
  return { rows, total: count ?? 0, balances };
}

export interface StudentDetail {
  student: StudentsRow;
  enrollments: EnrollmentWithTraining[];
  certificates: CertificateWithTraining[];
  /** null = rôle sans accès aux informations financières */
  payments: PaymentsRow[] | null;
  receipts: Record<string, ReceiptsRow>;
}

/** Tout ce qu'il faut pour la fiche d'un élève, ou null s'il n'existe pas / n'est pas visible. */
export async function getStudentDetail(
  db: SupabaseClient,
  id: string,
  withFinance: boolean,
): Promise<StudentDetail | null> {
  const { data: student, error } = await db.from("students").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!student) return null;

  const [enr, cert, pay] = await Promise.all([
    db.from("enrollments").select("*, trainings(name)").eq("student_id", id).order("created_at", { ascending: false }),
    db.from("certificates").select("*, trainings(name)").eq("student_id", id).order("created_at", { ascending: false }),
    withFinance
      ? db.from("payments").select("*").eq("student_id", id).order("paid_at", { ascending: false })
      : Promise.resolve(null),
  ]);
  for (const r of [enr, cert, pay]) if (r?.error) throw new Error(r.error.message);

  const payments = withFinance ? ((pay?.data ?? []) as PaymentsRow[]) : null;
  const receipts: Record<string, ReceiptsRow> = {};
  if (payments && payments.length > 0) {
    const { data, error: re } = await db.from("receipts").select("*").in("payment_id", payments.map((p) => p.id));
    if (re) throw new Error(re.message);
    for (const r of (data ?? []) as ReceiptsRow[]) receipts[r.payment_id] = r;
  }

  return {
    student: student as StudentsRow,
    enrollments: (enr.data ?? []) as EnrollmentWithTraining[],
    certificates: (cert.data ?? []) as CertificateWithTraining[],
    payments,
    receipts,
  };
}

/** URL signée (1 h) d'une photo du bucket privé ; null si absente ou indisponible. */
export async function signedPhotoUrl(db: SupabaseClient, path: string | null): Promise<string | null> {
  if (!path) return null;
  const { data } = await db.storage.from("student-photos").createSignedUrl(path, 3600);
  return data?.signedUrl ?? null;
}

export interface StudentOption {
  id: string;
  student_code: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  status: string;
}

/** Élèves inscriptibles (ni archivés ni suspendus) pour la recherche de la nouvelle inscription. */
export async function searchEnrollableStudents(db: SupabaseClient, q: string, limit = 8): Promise<StudentOption[]> {
  let query = db
    .from("students")
    .select("id, student_code, first_name, last_name, phone, status")
    .eq("is_archived", false)
    .neq("status", "SUSPENDU");
  for (const term of searchTerms(q)) query = query.or(ilikeOr(SEARCH_COLUMNS, term)!);
  const { data, error } = await query.order("last_name").order("first_name").limit(limit);
  if (error) throw new Error(error.message);
  return (data ?? []) as StudentOption[];
}

export async function getStudentOption(db: SupabaseClient, id: string): Promise<StudentOption | null> {
  const { data } = await db
    .from("students")
    .select("id, student_code, first_name, last_name, phone, status")
    .eq("id", id)
    .eq("is_archived", false)
    .neq("status", "SUSPENDU")
    .maybeSingle();
  return (data as StudentOption | null) ?? null;
}

